## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-002-case-study-programs-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("data.table")

# optional code to control data.table printing
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# subset rows of the CIP data matching conditions
pass01 <- filter_search(cip, "engineering")

# Examine the result
pass01

## -----------------------------------------------------------------------------
cols_we_want <- c("cip2", "cip2name")
unique(pass01[, ..cols_we_want])

## -----------------------------------------------------------------------------
pass02 <- filter_search(pass01, "^14")

# Examine the result
pass02

## -----------------------------------------------------------------------------
# optional code to control data.table printing
options(datatable.print.topn = 13)

pass03 <- filter_search(pass02, c("civil", "electrical", "industrial", "mechanical"))

# Examine the result
pass03[, .(cip6, cip6name)]

## -----------------------------------------------------------------------------
pass04 <- filter_search(pass03, drop_text = "electromechanical")

# Examine the result
pass04

## -----------------------------------------------------------------------------
cols_we_want <- c("cip6", "cip4name")
case_cip <- pass04[, ..cols_we_want]

# Examine the result
case_cip

## -----------------------------------------------------------------------------
# Create a new memory location to avoid updating by reference
case_program <- copy(case_cip)

# Add a new column for custom program labels
case_program[, program := fcase(
  cip4name %ilike% "civil", "Civil",
  cip4name %ilike% "electrical", "Electrical",
  cip4name %ilike% "mechanical", "Mechanical",
  cip4name %ilike% "industrial", "Industrial"
)]

# Examine the result
case_program

## -----------------------------------------------------------------------------
# Drop an unnecessary column
case_program[, cip4name := NULL]

# Examine the result
case_program

## -----------------------------------------------------------------------------
study_program

## -----------------------------------------------------------------------------
all.equal(case_program, study_program)

## ----eval = FALSE-------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("midfielddata")
#  library("data.table")
#  
#  # identify program codes
#  pass01 <- filter_search(cip, "engineering")
#  pass02 <- filter_search(pass01, "^14")
#  pass03 <- filter_search(
#    pass02,
#    c("civil", "electrical", "industrial", "mechanical")
#  )
#  pass04 <- filter_search(pass03, drop_text = "electromechanical")
#  cols_we_want <- c("cip6", "cip4name")
#  case_cip <- pass04[, ..cols_we_want]
#  
#  # assign program names
#  case_program <- copy(case_cip)
#  case_program[, program := cip4name]
#  dframe <- copy(case_program)
#  case_program[, program := fcase(
#    cip4name %ilike% "civil", "Civil",
#    cip4name %ilike% "electrical", "Electrical",
#    cip4name %ilike% "mechanical", "Mechanical",
#    cip4name %ilike% "industrial", "Industrial"
#  )]
#  case_program[, cip4name := NULL]
#  
#  # save results
#  fwrite(case_program, file = "results/case_program.csv")

