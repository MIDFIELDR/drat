## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 7,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-070-")

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load practice data
data(student, term)

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(baseline_mcid)

## -----------------------------------------------------------------------------
# Term into DT left join
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT

## -----------------------------------------------------------------------------
# Remove undecided/unspecified
DT <- DT[!cip6 %like% "999999"]
DT

## -----------------------------------------------------------------------------
# Retain observations of the earliest remaining terms by ID
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = "mcid"]
DT

## -----------------------------------------------------------------------------
# Unique combinations of ID and CIP
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
#  # Not run
#  DT <- DT[, .(mcid, start = cip6)]

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye_proxy[DT, on = c("mcid")]
DT

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]
DT

## -----------------------------------------------------------------------------
#  # Searching through the proxies for closer look cases
#  x <- DT[!is.na(proxy)]
#  
#  for (jj in x$mcid) {
#    y <- term[mcid == jj]
#    y <- y[cip6 != "140102"]
#  
#    # y <- y[!cip6 %like% "^14"]
#    #
#    # if (nrow(y) != 0 ){
#    #     print(y)
#    #     profvis::pause(1)
#    # }
#  
#    if (nrow(y) == 0) {
#      print(term[mcid == jj])
#      profvis::pause(1)
#    }
#  }
#  DT[mcid == "MCID3111303095"]
#  term[mcid == "MCID3111303095"]

## -----------------------------------------------------------------------------
# Omit unnecessary columns.
DT[, .(mcid, start)]
DT

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MCID3111150194"]

## -----------------------------------------------------------------------------
# Sequence of term records
term[mcid == "MCID3111150194"]

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MCID3111161837"]

## ---- echo=c(4, 5)------------------------------------------------------------
op <- options()
options(datatable.print.nrows = 11)

# Sequence of term records
term[mcid == "MCID3111161837"]

options(op)

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MCID3111303095"]

## -----------------------------------------------------------------------------
term[mcid == "MCID3111303095"]

## -----------------------------------------------------------------------------
# Rename cip6 as start
join_labels <- copy(study_programs)
join_labels <- join_labels[, .(program, start = cip6)]

# Filter by program
DT <- join_labels[DT, on = c("start"), nomatch = NULL]
DT

## -----------------------------------------------------------------------------
DT <- DT[, .(mcid, program)]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
DT <- copy(baseline_mcid)

## -----------------------------------------------------------------------------
# Isolate starting term
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT <- DT[!cip6 %like% "999999"]
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = "mcid"]
# Alternatively
# DT <- DT[, .SD[which.min(term)], by = "mcid"]
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
#  # Not run
#  DT <- DT[, .(mcid, start = cip6)]

## -----------------------------------------------------------------------------
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]
DT <- DT[, .(mcid, start)]

# Filter by program on start
join_labels <- copy(study_programs)
join_labels <- join_labels[, .(program, start = cip6)]
DT <- join_labels[DT, on = c("start"), nomatch = NULL]
DT <- DT[, .(mcid, program)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

