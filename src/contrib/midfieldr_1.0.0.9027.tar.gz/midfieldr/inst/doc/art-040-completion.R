## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-040-completion-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# Completion status
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 55,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Display prepared data
study_programs

## -----------------------------------------------------------------------------
# Optional. Set aside the source files in case they are needed
source_student <- copy(student)
source_term    <- copy(term)
source_degree  <- copy(degree)

# Work with required midfieldr variables only
student <- select_required(source_student)
term    <- select_required(source_term)
degree  <- select_required(source_degree)

# View top few rows of the result
head(student, n = 3L)

head(term, n = 3L)

head(degree, n = 3L)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

## -----------------------------------------------------------------------------
# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- DT[student, .(mcid), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Timely term required before completion status
w <- add_timely_term(DT, term)

# Required arguments in order and explicitly named
x <- add_completion_status(dframe = w, midfield_degree = degree)

# Required arguments in order, but not named
y <- add_completion_status(w, degree)

# Using the implicit default for the midfield_degree argument
z <- add_completion_status(w)

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Timely term required before completion status
DT <- add_timely_term(DT, term)

# Drop unnecessary columns
DT[, c("term_i", "level_i", "adj_span") := NULL]

# Add completion status and supporting variables
DT <- add_completion_status(DT, degree)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Student F
DT[mcid == "MID25783162"]

## -----------------------------------------------------------------------------
# Student G
DT[mcid == "MID26696871"]

## -----------------------------------------------------------------------------
# Student H
DT[mcid == "MID26697615"]

## -----------------------------------------------------------------------------
DT[, .N, by = c("completion_status")]

## -----------------------------------------------------------------------------
# Inner join 
x <- student[DT, on = c("mcid"), nomatch = NULL]
setkeyv(x, c("completion_status", "sex"))

# Display the result
x[, .N, by = c("completion_status", "sex")]

## -----------------------------------------------------------------------------
# Add CIP of degree earned with left-outer join
DT <- degree[DT, .(mcid, cip6, completion_status), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Extracting timely graduates only
DT[completion_status == "timely"]

## -----------------------------------------------------------------------------
# Add program names and retain matching rows
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 55,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Load data sets from midfielddata
#  data(student, term, degree, package = "midfielddata")
#  
#  # Filter for data sufficiency
#  DT <- copy(term)
#  DT <- add_timely_term(DT, term)
#  DT <- add_data_sufficiency(DT, term)
#  DT <- DT[data_sufficiency == "include"]
#  
#  # Filter for degree seeking
#  DT <- DT[, .(mcid)]
#  DT <- unique(DT)
#  DT <- DT[student, .(mcid), on = c("mcid"), nomatch = NULL]
#  
#  # Add completion status
#  DT <- add_timely_term(DT, term)
#  DT <- add_completion_status(DT, degree)
#  DT[, c("term_i", "level_i", "adj_span") := NULL]
#  
#  # Closer look
#  DT[mcid == "MID25783162"]
#  DT[mcid == "MID26696871"]
#  DT[mcid == "MID26697615"]
#  
#  # Equivalent statements
#  x <- add_completion_status(dframe = DT, midfield_degree = degree)
#  y <- add_completion_status(DT, degree)
#  z <- add_completion_status(DT)
#  all.equal(x, y)
#  all.equal(x, z)
#  
#  # Using degree data named something else
#  toy_DT <- toy_student[, .(mcid)]
#  toy_DT <- add_timely_term(toy_DT, toy_term)
#  toy_DT <- add_completion_status(toy_DT, toy_degree)
#  toy_DT[, c("term_i", "level_i", "adj_span") := NULL]
#  
#  # Caution. Overwriting.
#  toy_DT <- toy_DT[, c("term_degree", "completion_status") := NULL]
#  toy_DT <- add_completion_status(toy_DT, toy_degree)
#  
#  # Completion summaries
#  DT[, .N, by = c("completion_status")]
#  x <- student[DT, on = c("mcid"), nomatch = NULL]
#  setkeyv(x, c("completion_status", "sex"))
#  x[, .N, by = c("completion_status", "sex")]
#  
#  # Degrees earned
#  DT <- degree[DT, .(mcid, cip6, completion_status), on = c("mcid")]
#  DT[completion_status == "timely"]
#  
#  # Filter by program
#  DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
#  DT[, .N, by = c("completion_status", "program")]

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

