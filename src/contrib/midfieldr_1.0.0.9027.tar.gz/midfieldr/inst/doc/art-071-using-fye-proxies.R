## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-071-using-fye-proxies-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
study_mcid

## -----------------------------------------------------------------------------
study_programs

## -----------------------------------------------------------------------------
fye_proxy

## -----------------------------------------------------------------------------
# Load data from midfielddata
data(term)

# Display selected columns
term[, .(mcid, term, cip6)]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_mcid
#  ? study_programs
#  ? fye_proxy
#  ? term

## -----------------------------------------------------------------------------
# Create working data frame
DT <- copy(study_mcid)

# Left-outer join, term into IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Retain initial term
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# New memory location for labels
join_labels <- copy(study_programs)

# Left-outer join, match by the CIPs in start
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, on = c("start")]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Keep the programs in the study
DT <- DT[!is.na(program)]
setcolorder(DT, c("mcid", "cip6", "proxy", "start"))

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Direct matriculants
direct_start <- DT[is.na(proxy), .(mcid, start, program)]

# Display the result
direct_start[order(start)]

## -----------------------------------------------------------------------------
# Retain required columns
DT <- DT[, .(mcid, start, program)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run manually if necessary for reproducibility
#  # Writing external file study_starters
#  
#  study_starters <- copy(DT)
#  usethis::use_data(study_starters, overwrite = TRUE)

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_starters

## -----------------------------------------------------------------------------
# Verify results
all.equal(DT, study_starters)

## -----------------------------------------------------------------------------
# Display the data set
direct_start[]

## -----------------------------------------------------------------------------
# Count by program
direct <- direct_start[, .(direct_start = .N), by = "program"]

# Display the result
direct[]

## -----------------------------------------------------------------------------
# Display the data set
study_starters[]

## -----------------------------------------------------------------------------
# Count by program
estimated <- study_starters[, .(all_start = .N), by = "program"]

# Display the result
estimated[]

## -----------------------------------------------------------------------------
# Join
starter_subsets <- merge(direct, estimated, by = "program", all.x = TRUE)

# Display the result
starter_subsets[]

## -----------------------------------------------------------------------------
# FYE percentage of all starters
starter_subsets[, FYE_pct := round(100 * (all_start - direct_start) / all_start, 1)]

# Display the result
starter_subsets[]

## -----------------------------------------------------------------------------
# Identify unique CIP codes in the proxy data
proxy_cips <- sort(unique(fye_proxy$proxy))

# Display the results
proxy_cips

## -----------------------------------------------------------------------------
# Obtain the 4-digit program names corresponding to these codes
proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
proxy_program_names[]

## -----------------------------------------------------------------------------
# Join these program names to the proxy data
proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]

# Count by program and order rows in descending magnitude
proxy_programs <- proxy_programs[, .N, by = c("program")]
setorderv(proxy_programs, order = -1, cols = c("N"))

# Display the result
proxy_programs[]

## -----------------------------------------------------------------------------
# Combine Electrical and Computer Engineering
new_row <- data.table(
  program = "Electrical/Computer Engineering",
  N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
)

# New location in memory
rev_proxy <- copy(proxy_programs)

# Drop the separate Electrical and Computer rows
rev_proxy <- rev_proxy[!program %ilike% "Electrical|Computer"]

# Bind the new row and order
rev_proxy <- rbindlist(list(rev_proxy, new_row))
setorderv(rev_proxy, c("N"), -1)

# Display the top 7 rows
rev_proxy[1:7]

## -----------------------------------------------------------------------------
#  # Obtain first-term records
#  DT <- copy(study_mcid)
#  DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
#  setorderv(DT, cols = c("mcid", "term"))
#  DT <- DT[, .SD[1], by = c("mcid")]
#  
#  # Merge proxies
#  DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
#  
#  # Create start variable
#  DT[, start := fcase(
#    cip6 == "140102", proxy,
#    cip6 != "140102", cip6
#  )]
#  
#  # Filter desired programs
#  join_labels <- copy(study_programs)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, on = c("start")]
#  DT <- DT[!is.na(program)]
#  setcolorder(DT, c("mcid", "cip6", "proxy", "start"))
#  
#  # Data set-aside
#  direct_start <- DT[is.na(proxy), .(mcid, start, program)]
#  
#  # Confirm results
#  DT <- DT[, .(mcid, start, program)]
#  all.equal(DT, study_starters)
#  
#  # Assessing FYE proxies
#  direct <- direct_start[, .(direct_start = .N), by = "program"]
#  estimated <- study_starters[, .(all_start = .N), by = "program"]
#  starter_subsets <- merge(direct, estimated, by = "program", all.x = TRUE)
#  starter_subsets[, FYE_pct := round(100 * (all_start - direct_start) / all_start, 1)]
#  
#  # Credibility
#  proxy_cips <- sort(unique(fye_proxy$proxy))
#  proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
#  proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
#  proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]
#  proxy_programs <- proxy_programs[, .N, by = c("program")]
#  setorderv(proxy_programs, order = -1, cols = c("N"))
#  
#  # Combine Electrical and Computer Engineering
#  new_row <- data.table(
#    program = "Electrical/Computer Engineering",
#    N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
#  )
#  rev_proxy <- copy(proxy_programs)
#  rev_proxy <- rev_proxy[!program %ilike% "Electrical|Computer"]
#  rev_proxy <- rbindlist(list(rev_proxy, new_row))
#  setorderv(rev_proxy, c("N"), -1)
#  rev_proxy[1:7]

## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

