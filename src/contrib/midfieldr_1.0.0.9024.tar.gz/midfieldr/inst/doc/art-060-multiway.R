## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-060-multiway-charts-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Printing options for data.table
options(
  datatable.print.nrows = 18,
  datatable.print.topn = 8,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# View the case study results
DT <- copy(study_results)
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_results

## -----------------------------------------------------------------------------
# Protecting privacy of small populations
DT <- DT[ever >= 10]

## -----------------------------------------------------------------------------
# Optional filter
DT <- DT[!race %chin% c("Native American")]

## -----------------------------------------------------------------------------
# Ambiguous race/ethnicity values
DT <- DT[!race %chin% c("International", "Other/Unknown")]
DT[]

## -----------------------------------------------------------------------------
# Recode for panel and row labels
DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]

## -----------------------------------------------------------------------------
# Create a new category
DT[, people := paste(race, sex)]
setcolorder(DT, c("program", "people", "race", "sex"))
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? condition_multiway

## -----------------------------------------------------------------------------
# Select multiway variables when quantity is count
DT_count <- copy(DT)
DT_count <- DT_count[, .(program, people, grad)]
DT_count[]

## -----------------------------------------------------------------------------
# Convert categories to factors ordered by median
DT_count <- condition_multiway(DT_count,
  x = "grad",
  yy = c("program", "people"),
  order_by = "median"
)
DT_count[]

## -----------------------------------------------------------------------------
# Verify condition_multiway() output
temp <- DT_count[, lapply(.SD, median), .SDcols = c("grad"), by = c("program")]
temp[]

## -----------------------------------------------------------------------------
# Verify condition_multiway() output
temp <- DT_count[, lapply(.SD, median), .SDcols = c("grad"), by = c("people")]
temp[]

## -----------------------------------------------------------------------------
# Verify first category is a factor
levels(DT_count$program)

# Verify second category is a factor
levels(DT_count$people)

## -----------------------------------------------------------------------------
# Using explicit order_by median
p <- condition_multiway(DT_count,
  x = "grad",
  yy = c("program", "people"),
  order_by = "median"
)

# Using implicit order_by median
q <- condition_multiway(DT_count,
  x = "grad",
  yy = c("program", "people")
)

# Verify results identical
all.equal(p, q)

## -----------------------------------------------------------------------------
# Common x-scale and axis labels for median-ordered charts
common_scale_x_log10 <- scale_x_log10(
  limits = c(3, 1000),
  breaks = c(3, 10, 30, 100, 300, 1000),
  minor_breaks = c(seq(3, 10, 1), seq(20, 100, 10), seq(200, 1000, 100))
)
common_labs <- labs(
  x = "Number of graduates (log base 10 scale)",
  y = "",
  title = "Engineering graduates"
)

# Draw vertical lines in panels
common_geom_vline <- function(x) {
  geom_vline(aes(xintercept = x),
    linetype = 2,
    color = "gray70"
  )
}

## ----fig.asp = 0.8------------------------------------------------------------
# Two columns of panels
ggplot(DT_count, aes(x = grad, y = program)) +
  facet_wrap(vars(people), ncol = 2, as.table = FALSE) +
  common_geom_vline(DT_count$people_median) +
  common_scale_x_log10 +
  common_labs +
  geom_point()

## ----fig.asp = 1.6------------------------------------------------------------
# Programs encoded by rows
ggplot(DT_count, aes(x = grad, y = program)) +
  facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_count$people_median) +
  common_scale_x_log10 +
  common_labs +
  geom_point()

## ----fig.asp = 1.3------------------------------------------------------------
# People encoded by rows
ggplot(DT_count, aes(x = grad, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_count$program_median) +
  common_scale_x_log10 +
  common_labs +
  geom_point()

## ----fig.asp = 1.3------------------------------------------------------------
# Create alphabetical odering
DT_alpha <- copy(DT)
DT_alpha[, people := factor(people, levels = sort(unique(people), decreasing = TRUE))]

# People encoded by rows, alphabetically
ggplot(DT_alpha, aes(x = grad, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = TRUE) +
  common_scale_x_log10 +
  common_labs +
  geom_point()

## -----------------------------------------------------------------------------
# Select multiway variables with a superposed category
DT_count <- copy(DT)
DT_count <- DT_count[, .(program, race, sex, grad)]
DT_count[]

## -----------------------------------------------------------------------------
# Convert categories to factors ordered by median
DT_count <- condition_multiway(DT_count,
  x = "grad",
  yy = c("program", "race")
)
DT_count[]

## -----------------------------------------------------------------------------
# Race/ethnicity encoded by rows, sex superposed
ggplot(DT_count, aes(x = grad, y = race, color = sex)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_count$program_median) +
  common_scale_x_log10 +
  common_labs +
  geom_point() +
  scale_color_manual(values = c("#762A83", "#1B7837"))

## -----------------------------------------------------------------------------
# Program encoded by rows, sex superposed
ggplot(DT_count, aes(x = grad, y = program, color = sex)) +
  facet_wrap(vars(race), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_count$race_median) +
  common_scale_x_log10 +
  common_labs +
  geom_point() +
  scale_color_manual(values = c("#762A83", "#1B7837"))

## -----------------------------------------------------------------------------
# Select multiway variables when quantity is a percentage
options(datatable.print.topn = 3)
DT_ratio <- copy(DT)
DT_ratio[, c("race", "sex") := NULL]
DT_ratio[]

## -----------------------------------------------------------------------------
# Convert categories to factors ordered by group percentages
DT_ratio <- condition_multiway(DT_ratio,
  x = "stick",
  yy = c("program", "people"),
  order_by = "percent",
  param_col = c("grad", "ever")
)
DT_ratio[]

## -----------------------------------------------------------------------------
# Verify condition_multiway() output
temp <- DT[, lapply(.SD, sum), .SDcols = c("ever", "grad"), by = c("program")]
temp[, stick := round(100 * grad / ever, 1)]
temp[]

## -----------------------------------------------------------------------------
# Verify condition_multiway() output
temp <- DT[, lapply(.SD, sum), .SDcols = c("ever", "grad"), by = c("people")]
temp[, stick := round(100 * grad / ever, 1)]
temp[]

## ----fig.asp = 1.6------------------------------------------------------------
# Programs encoded by rows
ggplot(DT_ratio, aes(x = stick, y = program)) +
  facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_ratio$people_stick) +
  labs(x = "Stickiness", y = "", title = "Engineering stickiness") +
  geom_point()

## ----fig.asp = 1.3------------------------------------------------------------
# People encoded by rows
ggplot(DT_ratio, aes(x = stick, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  common_geom_vline(DT_ratio$program_stick) +
  labs(x = "Stickiness", y = "", title = "Engineering stickiness") +
  geom_point()

## -----------------------------------------------------------------------------
# Select the desired variables
tbl <- copy(DT)
tbl <- tbl[, .(program, people, grad)]
tbl[]

## -----------------------------------------------------------------------------
# Transform shape to row-record form
tbl <- dcast(tbl, people ~ program, value.var = "grad")
tbl[]

## -----------------------------------------------------------------------------
# Edit column header
setnames(tbl, old = "people", new = "Group", skip_absent = TRUE)

## -----------------------------------------------------------------------------
tbl |>
  kableExtra::kbl(
    align = "lrrrr",
    caption = "Table 1: Number of engineering graduates"
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:5, color = "black", background = "white")

## -----------------------------------------------------------------------------
# Select the desired variables
tbl <- copy(DT)
tbl <- tbl[, .(program, people, grad, ever, stick)]
tbl[]

## -----------------------------------------------------------------------------
# Construct new cell values
tbl[, results := paste0("(", grad, "/", ever, ") ", format(stick, nsmall = 1))]
tbl[]

## -----------------------------------------------------------------------------
# Transform shape to row-record form
tbl <- dcast(tbl, people ~ program, value.var = "results")
tbl[]

## -----------------------------------------------------------------------------
# Edit column header
setnames(tbl, old = "people", new = "Group", skip_absent = TRUE)

## -----------------------------------------------------------------------------
tbl |>
  kableExtra::kbl(
    align = "lrrrr",
    caption = "Table 2: Percent stickiness of four engineering programs"
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:5, color = "black", background = "white") |>
  kableExtra::footnote(general = "Integers in parentheses give the ratio of students graduating to those ever enrolled that produces the percentage shown.")

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  suppressPackageStartupMessages(library("data.table"))
#  suppressPackageStartupMessages(library("ggplot2"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 18,
#    datatable.print.topn = 8,
#    datatable.print.class = TRUE
#  )
#  
#  # Summarized data
#  DT <- copy(study_results)
#  
#  # Filtering before dissemination
#  DT <- DT[ever >= 10]
#  DT <- DT[!race %chin% c("Native American")]
#  DT <- DT[!race %chin% c("International", "Other/Unknown")]
#  
#  # Preparing the categorical variables
#  DT[, program := fcase(
#    program %like% "CE", "Civil",
#    program %like% "EE", "Electrical",
#    program %like% "ME", "Mechanical",
#    program %like% "ISE", "Industrial/Systems"
#  )]
#  DT[, people := paste(race, sex)]
#  setcolorder(DT, c("program", "people", "race", "sex"))
#  
#  # Median-ordered data
#  DT_count <- copy(DT)
#  DT_count <- DT_count[, .(program, people, grad)]
#  DT_count <- condition_multiway(DT_count,
#    x = "grad",
#    yy = c("program", "people"),
#    order_by = "median"
#  )
#  
#  # Median-ordered charts
#  common_scale_x_log10 <- scale_x_log10(
#    limits = c(3, 1000),
#    breaks = c(3, 10, 30, 100, 300, 1000),
#    minor_breaks = c(seq(3, 10, 1), seq(20, 100, 10), seq(200, 1000, 100))
#  )
#  common_labs <- labs(
#    x = "Number of graduates (log base 10 scale)",
#    y = "",
#    title = "Engineering graduates"
#  )
#  common_geom_vline <- function(x) {
#    geom_vline(aes(xintercept = x),
#      linetype = 2,
#      color = "gray70"
#    )
#  }
#  
#  # Two-column layout
#  ggplot(DT_count, aes(x = grad, y = program)) +
#    facet_wrap(vars(people), ncol = 2, as.table = FALSE) +
#    common_geom_vline(DT_count$people_median) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point()
#  
#  # Programs encoded by rows
#  ggplot(DT_count, aes(x = grad, y = program)) +
#    facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_count$people_median) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point()
#  
#  # People encoded by rows
#  ggplot(DT_count, aes(x = grad, y = people)) +
#    facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_count$program_median) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point()
#  
#  # Avoid alphabetical order
#  DT_alpha <- copy(DT)
#  DT_alpha[, people := factor(people, levels = sort(unique(people), decreasing = TRUE))]
#  ggplot(DT_alpha, aes(x = grad, y = people)) +
#    facet_wrap(vars(program), ncol = 1, as.table = TRUE) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point()
#  
#  # Multiway superposition
#  DT_count <- copy(DT)
#  DT_count <- DT_count[, .(program, race, sex, grad)]
#  DT_count <- condition_multiway(DT_count,
#    x = "grad",
#    yy = c("program", "race")
#  )
#  
#  # Race/ethnicity encoded by rows
#  ggplot(DT_count, aes(x = grad, y = race, color = sex)) +
#    facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_count$program_median) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point() +
#    scale_color_manual(values = c("#762A83", "#1B7837"))
#  
#  # Program encoded by rows
#  ggplot(DT_count, aes(x = grad, y = program, color = sex)) +
#    facet_wrap(vars(race), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_count$race_median) +
#    common_scale_x_log10 +
#    common_labs +
#    geom_point() +
#    scale_color_manual(values = c("#762A83", "#1B7837"))
#  
#  # Percentage-ordered data
#  DT_ratio <- copy(DT)
#  DT_ratio[, c("race", "sex") := NULL]
#  DT_ratio <- condition_multiway(DT_ratio,
#    x = "stick",
#    yy = c("program", "people"),
#    order_by = "percent",
#    param_col = c("grad", "ever")
#  )
#  
#  # Percentage-ordered charts
#  # Programs encoded by rows
#  ggplot(DT_ratio, aes(x = stick, y = program)) +
#    facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_ratio$people_stick) +
#    labs(x = "Stickiness", y = "", title = "Engineering stickiness") +
#    geom_point()
#  
#  # People encoded by rows
#  ggplot(DT_ratio, aes(x = stick, y = people)) +
#    facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
#    common_geom_vline(DT_ratio$program_stick) +
#    labs(x = "Stickiness", y = "", title = "Engineering stickiness") +
#    geom_point()
#  
#  # Tabulating counts
#  tbl <- copy(DT)
#  tbl <- tbl[, .(program, people, grad)]
#  tbl <- dcast(tbl, people ~ program, value.var = "grad")
#  setnames(tbl, old = "people", new = "Group", skip_absent = TRUE)
#  
#  # Tabulating percentages
#  tbl <- copy(DT)
#  tbl <- tbl[, .(program, people, grad, ever, stick)]
#  tbl[, results := paste0("(", grad, "/", ever, ") ", format(stick, nsmall = 1))]
#  tbl <- dcast(tbl, people ~ program, value.var = "results")
#  setnames(tbl, old = "people", new = "Group", skip_absent = TRUE)

## ----echo = FALSE-------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

