## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-060-tabulating-data-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}
asp_ratio_mw <- function(data, categories) {
  cat1 <- categories[1] # panels
  cat2 <- categories[2] # rows
  nlevel1 <- nlevels(data[, get(cat1)])
  nlevel2 <- nlevels(data[, get(cat2)])
  r <- nlevel1 * nlevel2
  q <- 32
  asp_ratio1 <- (r + 2 * nlevel1) / q
  asp_ratio2 <- (r + 2 * nlevel2) / q
  ratios <- c(asp_ratio1, asp_ratio2)
}

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("midfielddata")

library("ggplot2")
library("janitor")
library("data.table")

## -----------------------------------------------------------------------------
# optional code to control data.table printing
options(
  datatable.print.nrows = 10,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## ----echo = FALSE-------------------------------------------------------------
DT <- wrapr::build_frame(
  "program", "race_sex", "stick", "med_program", "med_race_sex" |
    "Civil", "Asian Female", 70.6, 58.9, 70.85 |
    "Civil", "Black Female", 51.9, 58.9, 56.95 |
    "Civil", "White Female", 70.5, 58.9, 65.1 |
    "Civil", "Asian Male", 64.9, 58.9, 63.9 |
    "Civil", "Black Male", 43.9, 58.9, 45.9 |
    "Civil", "Hispanic/Latinx Male", 58.9, 58.9, 60.35 |
    "Civil", "International Male", 42.9, 58.9, 52.95 |
    "Civil", "Other/Unknown Male", 31.2, 58.9, 50 |
    "Civil", "White Male", 68.3, 58.9, 65.1 |
    "Electrical", "Asian Female", 71.1, 62.45, 70.85 |
    "Electrical", "Black Female", 61.7, 62.45, 56.95 |
    "Electrical", "Hispanic/Latinx Female", 71.4, 62.45, 72.05 |
    "Electrical", "White Female", 63.2, 62.45, 65.1 |
    "Electrical", "Asian Male", 64.5, 62.45, 63.9 |
    "Electrical", "Black Male", 45.1, 62.45, 45.9 |
    "Electrical", "Hispanic/Latinx Male", 55.2, 62.45, 60.35 |
    "Electrical", "International Male", 59.2, 62.45, 52.95 |
    "Electrical", "Other/Unknown Male", 50, 62.45, 50 |
    "Electrical", "White Male", 63.7, 62.45, 65.1 |
    "Industrial", "Asian Female", 50, 59.6, 70.85 |
    "Industrial", "Black Female", 58.5, 59.6, 56.95 |
    "Industrial", "White Female", 60.7, 59.6, 65.1 |
    "Industrial", "Asian Male", 63.3, 59.6, 63.9 |
    "Industrial", "Black Male", 53.8, 59.6, 45.9 |
    "Industrial", "Hispanic/Latinx Male", 88, 59.6, 60.35 |
    "Industrial", "International Male", 54.5, 59.6, 52.95 |
    "Industrial", "White Male", 65, 59.6, 65.1 |
    "Mechanical", "Asian Female", 82.6, 61.8, 70.85 |
    "Mechanical", "Black Female", 55.4, 61.8, 56.95 |
    "Mechanical", "Hispanic/Latinx Female", 72.7, 61.8, 72.05 |
    "Mechanical", "White Female", 67, 61.8, 65.1 |
    "Mechanical", "Asian Male", 63.1, 61.8, 63.9 |
    "Mechanical", "Black Male", 46.7, 61.8, 45.9 |
    "Mechanical", "Hispanic/Latinx Male", 61.8, 61.8, 60.35 |
    "Mechanical", "International Male", 51.4, 61.8, 52.95 |
    "Mechanical", "Native American Male", 57.1, 61.8, 57.1 |
    "Mechanical", "Other/Unknown Male", 58.3, 61.8, 50 |
    "Mechanical", "White Male", 65.2, 61.8, 65.1
)
setDT(DT)

## ----echo = FALSE-------------------------------------------------------------
temp <- copy(DT)
kable2html(temp, caption = "Table 1: Stickiness (block records)")

## ----echo = FALSE-------------------------------------------------------------
temp[, race_sex := as.character(race_sex)]
temp[, program := as.character(program)]
temp <- dcast(temp, race_sex ~ program, value.var = "stick")
kable2html(temp, caption = "Table 2: Stickiness (row records)")

## -----------------------------------------------------------------------------
# create a new memory location
block_form <- copy(DT)

# limit significant digits
block_form[, stick := round(stick, 2)]

## -----------------------------------------------------------------------------
# create a new memory location
row_form <- copy(block_form)

# convert factors to characters
row_form[, race_sex := as.character(race_sex)]
row_form[, program := as.character(program)]

## -----------------------------------------------------------------------------
# reshape
row_form <- dcast(row_form, race_sex ~ program, value.var = "stick")

# examine the result
row_form

## ----echo = FALSE-------------------------------------------------------------
kable2html(temp, caption = "Table 2: Stickiness (row records)")

## -----------------------------------------------------------------------------
study_student

## -----------------------------------------------------------------------------
# To access the tabyl() and adorn_total() functions
library("janitor")

# Create a new memory location
DT <- copy(study_student)

## -----------------------------------------------------------------------------
# Merge the groups as usual
DT[, race_sex := paste(race, sex)]

# Examine the result
DT

## -----------------------------------------------------------------------------
# Create the two-way frequency table
DT <- tabyl(DT, race_sex, program)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Add row and column totals
DT <- adorn_totals(DT, where = c("row", "col"))

# Examine the result
DT

## ----eval = FALSE-------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("data.table")
#  library("ggplot2")
#  
#  # optional code to control data.table printing
#  options(
#    datatable.print.nrows = 10,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )

## ----echo = FALSE-------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

