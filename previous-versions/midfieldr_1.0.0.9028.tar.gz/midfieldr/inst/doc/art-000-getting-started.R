## ----setup, include = FALSE---------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  cache = FALSE # speeds up repeats
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-000-getting-started-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# data.table printout
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# accented text
# accent <- function (text_string){
#     kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
# }

## -----------------------------------------------------------------------------
library("midfieldr")

wrapr::build_frame(
  "Practice data table", "Each row is", "No. of rows", "No. of columns", "Memory" |
    "course", "a student in a course", "3,439,936", "12", "340 Mb" |
    "term", "a student in a term", "710,841", "13", "80 Mb" |
    "student", "a degree-seeking student", "97,640", "13", "19 Mb" |
    "degree", "a student who graduates", "47,499", "5", "10.2 Mb"
) |>
  kableExtra::kbl(
    align = "llrrr",
    caption = "Table 1: Attributes of the practice data tables in midfielddata"
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1, monospace = TRUE) |>
  kableExtra::column_spec(1:4, color = "black", background = "white")

## -----------------------------------------------------------------------------
# Type in the Console
library("midfieldr")

## -----------------------------------------------------------------------------
#  # Type in the Console
#  help("add_timely_term")
#  ? add_timely_term

## -----------------------------------------------------------------------------
#  # Type in the Console
#  ? cip

## -----------------------------------------------------------------------------
#  # Type in the Console
#  data(package = "midfieldr")
#  #> Data sets in package 'midfieldr':
#  #>
#  #> cip
#  #> fye_proxy
#  #> study_ever
#  #> ...

## -----------------------------------------------------------------------------
# Type in the Console
lsf.str("package:midfieldr")

## -----------------------------------------------------------------------------
#  # Type in the Console
#  example("add_timely_term")

## -----------------------------------------------------------------------------
# Getting started
# midfieldr vignette

# Packages used
library("midfieldr")
library("midfielddata")
library("data.table")

## -----------------------------------------------------------------------------
# Names of objects in the environment
ls()

## -----------------------------------------------------------------------------
if (!exists("student")) data(student, package = "midfielddata")

## -----------------------------------------------------------------------------
#  # Load practice data
#  data(student, package = "midfielddata")

## -----------------------------------------------------------------------------
# Names of objects in the environment
ls()

## -----------------------------------------------------------------------------
if (!exists("course")) data(course, package = "midfielddata")
if (!exists("term")) data(term, package = "midfielddata")
if (!exists("degree")) data(degree, package = "midfielddata")

## -----------------------------------------------------------------------------
#  # Load remaining practice data
#  data(course, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Names of objects in the environment
ls()

## -----------------------------------------------------------------------------
# cip
n_cip <- nrow(unique(cip))

# student
obs_students <- nrow(student)
var_students <- ncol(student)
size_students <- "19 MB"

# degree
n_id_degrees <- nrow(unique(degree[, .(mcid)]))
n_graduates <- nrow(unique(degree[!is.na(degree), .(mcid)]))
n_term <- nrow(unique(degree[, .(term)]))
obs_degrees <- nrow(degree)
var_degrees <- ncol(degree)
size_degrees <- "10 MB"

# term
n_id_terms <- nrow(unique(term[, .(mcid)]))
obs_terms <- nrow(term)
var_terms <- ncol(term)
n_institutions <- nrow(unique(term[, .(institution)]))
n_programs_terms <- nrow(unique(term[, .(institution, cip6)]))
n_terms <- nrow(unique(term[, .(term)]))
year_span <- c(substr(min(term[, term]), 1, 4), substr(max(term[, term]), 1, 4))
size_terms <- "82 MB"

# course
n_id_courses <- nrow(unique(course[, .(mcid)]))
n_courses <- nrow(unique(course[, .(institution, abbrev, number)]))
n_term_course <- nrow(unique(course[, .(term)]))
obs_courses <- nrow(course)
var_courses <- ncol(course)
size_courses <- "349 MB"

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? student

## -----------------------------------------------------------------------------
# View the structure of the data set
str(student)

## -----------------------------------------------------------------------------
nrow(student)

length(unique(student$mcid))

## -----------------------------------------------------------------------------
summary(student$sat_math)

summary(student$age)

## -----------------------------------------------------------------------------
sort(unique(student$sex))

sort(unique(student$race))

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? course

## -----------------------------------------------------------------------------
# View the structure of the data set
str(course)

## -----------------------------------------------------------------------------
length(unique(course$mcid))

## -----------------------------------------------------------------------------
summary(course$hours_course)

## -----------------------------------------------------------------------------
sort(unique(course$type))

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? term

## -----------------------------------------------------------------------------
str(term)

## -----------------------------------------------------------------------------
length(unique(term$mcid))

## -----------------------------------------------------------------------------
summary(term$hours_term)

summary(term$gpa_term)

## -----------------------------------------------------------------------------
sort(unique(term$level))

sort(unique(term$standing))

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? degree

## -----------------------------------------------------------------------------
str(degree)

## -----------------------------------------------------------------------------
nrow(degree)

length(unique(degree$mcid))

## -----------------------------------------------------------------------------
# Isolate IDs
degree_mcid <- unique(degree$mcid)
student_mcid <- unique(student$mcid)

# Sum of logical results, 1 for every TRUE, 0 for every FALSE
sum(degree_mcid %chin% student_mcid)

## -----------------------------------------------------------------------------
sort(unique(degree$institution))

sort(unique(degree$degree))

## -----------------------------------------------------------------------------
degree[is.na(degree)]

## -----------------------------------------------------------------------------
#  library(skimr)
#  skim(student)
#  skim(degree)

## -----------------------------------------------------------------------------
wrapr::build_frame(
  "Function", "Action" |
    "add_completion_status()", "Determine degree completion status for every student" |
    "add_data_sufficiency()", "Determine data sufficiency for every student" |
    "add_timely_term()", "Determine a timely completion term for every student" |
    "filter_cip()", "Subset rows of CIP data to match search strings" |
    "order_multiway()", "Order the categories of multiway data for graphing" |
    "prep_fye_mice()", "Construct and format FYE data for multiple imputation" |
    "same_content()", "Test for equal content in two data tables" |
    "select_required()", "Reduce number of columns of a MIDFIELD source data table"
) |>
  kableExtra::kbl(
    align = "ll",
    caption = "Table 2: Functions provided in midfieldr."
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::column_spec(1, monospace = TRUE) |>
  kableExtra::column_spec(1:2, color = "black", background = "white") |>
  kableExtra::row_spec(c(0), background = "#c7eae5")

## -----------------------------------------------------------------------------
# Create a copy of the source file
source_term <- copy(term)
source_term[]

## -----------------------------------------------------------------------------
# Select variables required by midfieldr functions
term <- select_required(source_term)
term[]

## -----------------------------------------------------------------------------
# Required argument explicitly named
x <- select_required(midfield_x = term)

# Required argument not named
y <- select_required(term)

# Optional argument, if used, must be named. NULL yields the default columns.
z <- select_required(term, select_add = NULL)

## -----------------------------------------------------------------------------
# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Two columns from student, use key to order rows
x <- student[, .(mcid, institution)]
setkey(x, mcid)
x[]

# Same information with different row order, column order, and key
y <- student[, .(institution, mcid)]
setkey(y, institution)
y[]

# Demonstrate equivalence
same_content(x, y)

## -----------------------------------------------------------------------------
# Demonstrate non-equivalence
same_content(student, degree)

## -----------------------------------------------------------------------------
#  # Load source data
#  data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# to change the CSS file per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

