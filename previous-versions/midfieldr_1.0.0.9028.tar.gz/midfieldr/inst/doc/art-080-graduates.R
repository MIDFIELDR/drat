## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-080-graduates-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# data.table printout
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# accented text
accent <- function(text_string) {
  kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# midfieldr: Graduates

# Packages
library("midfieldr")
library("midfielddata")
library("data.table")

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency, output unique IDs
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include", .(mcid)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Filter for degree seeking, output unique IDs
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
baseline <- copy(DT)

## -----------------------------------------------------------------------------
# Timely term required before completion status
DT <- add_timely_term(DT, term)

# Drop unnecessary columns
DT[, c("term_i", "level_i", "adj_span") := NULL]

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- add_completion_status(dframe = DT, midfield_degree = degree)

# Required arguments in order, but not named
y <- add_completion_status(DT, degree)

# Using the implicit default for the midfield_degree argument
z <- add_completion_status(DT)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Add completion status and supporting variables
DT <- add_completion_status(DT, degree)
DT[]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID25783162"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID26696871"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID26697615"]

## -----------------------------------------------------------------------------
# Graduates
DT <- DT[completion_status == "timely"]

# Filter for unique IDs
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Add degree CIP codes
cols_we_want <- degree[, .(mcid, cip6)]
DT <- cols_we_want[DT, on = c("mcid")]
DT[]

## -----------------------------------------------------------------------------
# Verify no NAs in CIP column
sum(!complete.cases(DT))

## -----------------------------------------------------------------------------
# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Gather graduates and their degree CIPs
DT <- add_timely_term(DT, term)
DT <- add_completion_status(DT, degree)
DT <- DT[completion_status == "timely"]
DT <- degree[DT, .(mcid, cip6), on = c("mcid")]

# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

