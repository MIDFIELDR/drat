## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-080-graduation-rate-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
suppressPackageStartupMessages(library("data.table"))
wrapr::build_frame(
    "Item", "IPEDS", "MIDFIELD", "MIDFIELD notes" |
        "completion span:", "4, 6, or 8 years", "4, 6, or 8 years", "Typical usage is 6 years" |
        "students admitted in:", "Summer/Fall only", "any term", "" |
        "part-time students are:", "excluded", "included", "Timely completion same as full-time students" |
        "transfer students are:", "excluded", "included", "Timely completion span adjusted for level at entry" 
) |>
    kableExtra::kbl(align = "llll", caption = "Table 1: Comparing graduation rate definitions") |>
    kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
    kableExtra::column_spec(1:2, color = "black", background = "white") |>
    kableExtra::row_spec(c(0), background = "#c7eae5")

## -----------------------------------------------------------------------------
# Graduation rate
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Printing options for data.table
options(
  datatable.print.nrows = 21,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Select required midfieldr variables
student <- select_required(student)
term    <- select_required(term)
degree  <- select_required(degree)

# View top few rows of the result
head(student, n = 3L)
head(term, n = 3L)
head(degree, n = 3L)

## -----------------------------------------------------------------------------
# Display prepared data
study_programs

## -----------------------------------------------------------------------------
# Display prepared data
fye_proxy

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

## -----------------------------------------------------------------------------
# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter for initial term
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT <- DT[!cip6 %like% "999999"]
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = c("mcid")]

# Create start variable
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter by program
join_labels <- copy(study_programs)
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, on = c("start")]
DT <- DT[!is.na(program)]
setcolorder(DT, c("mcid", "start"))

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Set aside for later use
starters <- copy(DT)

## -----------------------------------------------------------------------------
# Prepare the graduates
starters <- DT[, .(mcid, program)]
starters[, group := "start"]
starters <- unique(starters)

# Display the result
starters[]

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(starters)

## -----------------------------------------------------------------------------
# Isolate IDs
DT <- DT[, .(mcid)]
DT <- unique(DT)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Add degree information
DT <- degree[DT, on = "mcid"]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter by program
DT <- study_programs[DT, on = c("cip6")]
DT <- DT[!is.na(program)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Add completion status
DT <- add_timely_term(DT, term)
DT <- add_completion_status(DT, degree)
DT[, c("term_i", "level_i", "adj_span") := NULL]
DT <- DT[completion_status == "timely"]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Rename to distinguish graduates from starters before merging
graduates <- copy(DT)

## -----------------------------------------------------------------------------
# Rename program variable before merging
starters  <- starters[, .(mcid, program_start = program)]
graduates <- graduates[, .(mcid, program_grad = program)]

# Combine using a left outer join 
DT <- graduates[starters, on = "mcid"]
DT[]

## -----------------------------------------------------------------------------
# Script

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

