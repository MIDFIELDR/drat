## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-070-starters-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# data.table printout
options(
  datatable.print.nrows = 15,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# accented text
accent <- function(text_string) {
  kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# midfieldr: Starters

# Packages
library("midfieldr")
library("midfielddata")
library("data.table")

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency, output unique IDs
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include", .(mcid)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Filter for degree seeking, output unique IDs
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
DT <- unique(DT)

## -----------------------------------------------------------------------------
baseline <- copy(DT)

## -----------------------------------------------------------------------------
# Term into DT left join
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT[]

## -----------------------------------------------------------------------------
# Remove undecided/unspecified
DT <- DT[!cip6 %like% "999999"]

## -----------------------------------------------------------------------------
# Retain observations of the earliest remaining terms by ID
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[which.min(term)], by = "mcid"]

## -----------------------------------------------------------------------------
# Unique combinations of ID and CIP
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye_proxy[DT, on = c("mcid")]
DT[]

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]
DT[]

## -----------------------------------------------------------------------------
# Omit unnecessary columns.
DT[, `:=`(cip6 = NULL, proxy = NULL)]
DT[]

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MID25816220"]

## -----------------------------------------------------------------------------
# Order rows of source table
setkeyv(term, c("mcid", "term"))

# Sequence of term records
term[mcid == "MID25816220", .(mcid, term, cip6)][1:5]

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MID25783178"]

## -----------------------------------------------------------------------------
# Sequence of term records
term[mcid == "MID25783178", .(mcid, term, cip6)][1:7]

## -----------------------------------------------------------------------------
# Analysis result
DT[mcid == "MID25783162"]

## -----------------------------------------------------------------------------
# Sequence of term records
term[mcid == "MID25783162", .(mcid, term, cip6)][1:4]

## -----------------------------------------------------------------------------
# Rename cip6 as start
join_labels <- copy(study_programs)
join_labels <- join_labels[, .(program, start = cip6)]

# Filter by program
DT <- join_labels[DT, on = c("start"), nomatch = NULL]
DT[, start := NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
#  # Run manually
#  # Writing external files
#  setkey(DT, mcid)
#  setkey(DT, NULL)
#  study_starters <- copy(DT)
#  usethis::use_data(study_starters, overwrite = TRUE)

## -----------------------------------------------------------------------------
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Isolate starting term
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT <- DT[!cip6 %like% "999999"]
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[which.min(term)], by = "mcid"]
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)

# For starters without FYE, rename cip6 as start, omit the proxy steps

# Continue for starters with FYE
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]
DT <- DT[, .(mcid, start)]

# Filter by program on start
join_labels <- copy(study_programs)
join_labels <- join_labels[, .(program, start = cip6)]
DT <- join_labels[DT, on = c("start"), nomatch = NULL]
DT[, start := NULL]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Demonstrate equivalence
same_content(DT, study_starters)

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

