## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 8,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-000-")

## -----------------------------------------------------------------------------
wrapr::build_frame(
  "Dataset", "Each row is", "Students", "Rows", "Columns", "Memory" |
    "course", "one student per course", "97,555", "3,289,532", 12L, "324.3 MB" |
    "term", "one student per term", "97,555", "639,915", 13L, "72.8 MB" |
    "student", "one student", "97,555", "97,555", 13L, "17.3 MB" |
    "degree", "one student per degree", "49,543", "49,665", 5L, "5.2 MB"
) |>
  kableExtra::kbl(align = "llrrrr", caption = "Table 1. Practice datasets in midfielddata.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = FALSE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1, monospace = TRUE) |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load one table as needed
data(student)

# Or load multiple tables
data(course, term, degree)

## -----------------------------------------------------------------------------
student

## -----------------------------------------------------------------------------
# Anonymized IDs
sample(student$mcid, 8)

# Anonymized institutions
sort(unique(student$institution))

## -----------------------------------------------------------------------------
# Possible values
sort(unique(student$race))

# Possible values
sort(unique(student$sex))

## -----------------------------------------------------------------------------
# N by institution
student[order(institution), .N, by = "institution"]

# N by race
student[order(race), .N, by = "race"]

# N by sex
student[order(sex), .N, by = "sex"]

## -----------------------------------------------------------------------------
course

## -----------------------------------------------------------------------------
# Many NA values in this column
sum(is.na(course$course))

# No NA values in these columns.
sum(is.na(course$abbrev))
sum(is.na(course$number))
sum(is.na(course$discipline_midfield))

## -----------------------------------------------------------------------------
term

## -----------------------------------------------------------------------------
# Range of data by institution
term[, .(min_term = min(term), max_term = max(term)), by = "institution"]

## -----------------------------------------------------------------------------
# A sample of cip6 values
sort(unique(sample(term$cip6, 8)))

## -----------------------------------------------------------------------------
# Possible values
sort(unique(term$level))

## -----------------------------------------------------------------------------
degree

## -----------------------------------------------------------------------------
# Count students by number of degrees
by_id <- degree[, .(degree_count = .N), by = "mcid"]
by_id[, .(N_students = .N), by = "degree_count"]

## -----------------------------------------------------------------------------
# One student ID
id_we_want <- "MCID3112192438"

## -----------------------------------------------------------------------------
# Observations for a selected ID
student[mcid == id_we_want]

## -----------------------------------------------------------------------------
# Observations for a selected ID
course[mcid == id_we_want]

## -----------------------------------------------------------------------------
# Observations for a selected ID
term[mcid == id_we_want]

## -----------------------------------------------------------------------------
# Observations for a selected ID
degree[mcid == id_we_want]

## -----------------------------------------------------------------------------
# Observations for a different ID
degree[mcid == "MCID3111315508"]

## -----------------------------------------------------------------------------
# Select variables required by midfieldr functions
select_required(term)

## -----------------------------------------------------------------------------
# Select additional columns
select_required(term, select_add = c("gpa_term"))

## -----------------------------------------------------------------------------
# Required argument explicitly named
x <- select_required(midfield_x = term)

# Required argument not named
y <- select_required(term)

# Optional argument, if used, must be named. NULL yields the default columns.
z <- select_required(term, select_add = NULL)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Two columns from student, use key to order rows
x <- student[, .(mcid, institution)]
setkey(x, mcid)
x

# Same information with different row order, column order, and key
y <- student[, .(institution, mcid)]
setkey(y, institution)
y

# Demonstrate equivalence
same_content(x, y)

## -----------------------------------------------------------------------------
# Demonstrate non-equivalence
same_content(student, degree)

## -----------------------------------------------------------------------------
#  # Load source data
#  data(student, term, degree)

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

