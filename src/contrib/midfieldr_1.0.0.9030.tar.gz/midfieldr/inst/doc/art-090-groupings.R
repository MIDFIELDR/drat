## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 8,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-090-")

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, degree)

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(baseline_mcid)

## -----------------------------------------------------------------------------
# Reusable starting state with CIP
baseline_cip <- term[DT, .(mcid, cip6), on = c("mcid")]
baseline_cip <- unique(baseline_cip)
baseline_cip

## -----------------------------------------------------------------------------
# Reusable starting state
DT <- copy(baseline_cip)

## -----------------------------------------------------------------------------
# Join program labels via inner join
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT

## -----------------------------------------------------------------------------
# Verify program labels
sort(unique(DT$program))

# Verify program CIP codes
sort(unique(DT$cip6))

## -----------------------------------------------------------------------------
# Prepare to filter
DT[, cip6 := NULL]
DT

## -----------------------------------------------------------------------------
# Case study ever enrolled
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# find student ID with two CIPs in ISE
# x <- study_programs[term, on = "cip6", nomatch = NULL]
# x <- x[program == "ISE"]
# x <- x[, .(mcid, cip6, program)]
# x <- unique(x)
# x[duplicated(x$mcid)]
# x[mcid == "MCID3111251565"]

## -----------------------------------------------------------------------------
# All terms, one ID
x <- term[mcid == "MCID3111251565", .(mcid, cip6)]

# Join case study program labels
x <- study_programs[x, on = c("cip6"), nomatch = NULL]

# Unique CIPs for this student
unique(x)

## -----------------------------------------------------------------------------
# Reusable starting state
DT <- copy(baseline_mcid)
DT

## -----------------------------------------------------------------------------
# Extract desired columns
cols_we_want <- student[, .(mcid, race, sex)]
cols_we_want

## -----------------------------------------------------------------------------
# Add demographics
DT <- cols_we_want[DT, on = c("mcid")]
DT

## -----------------------------------------------------------------------------
# Display values
unique(DT$race)
unique(DT$sex)

## -----------------------------------------------------------------------------
# Remove records with unknown sex, if any
x <- copy(DT)
x <- x[!sex %ilike% "unknown"]
x

## -----------------------------------------------------------------------------
# Remove records with unknown sex, if any
x <- x[!race %ilike% "unknown"]
x

## -----------------------------------------------------------------------------
# Remove unknowns in either of two columns
DT <- DT[!(sex %ilike% "unknown" | race %ilike% "unknown")]

# Verify equivalence
same_content(x, DT)

## -----------------------------------------------------------------------------
sort(unique(DT$race))
sort(unique(DT$sex))

## -----------------------------------------------------------------------------
# Two values for origin
x <- copy(DT)
x <- x[, origin := fifelse(race == "International", "International", "Domestic")]
x[]

## -----------------------------------------------------------------------------
sort(unique(x$origin))

## -----------------------------------------------------------------------------
x <- copy(DT)
x <- x[, people := paste(race, sex)]
x

## -----------------------------------------------------------------------------
sort(unique(x$people))

## -----------------------------------------------------------------------------
# Two values for origin
x <- copy(DT)
x <- x[, origin := fifelse(race == "International", "International", "Domestic")]

# Combine with sex
x[, people := paste(origin, sex)]

# Omit unnecessary variables
x <- x[, .(mcid, people)]
x

## -----------------------------------------------------------------------------
sort(unique(x$people))

## -----------------------------------------------------------------------------
# Reusable starting state
DT <- copy(baseline_mcid)
DT

## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_student)

## -----------------------------------------------------------------------------
# Extract desired columns
cols_we_want <- source_student[, .(mcid, transfer, hours_transfer)]

## -----------------------------------------------------------------------------
# Add desired columns
cols_we_want[DT, on = c("mcid")]

## -----------------------------------------------------------------------------
# Reusable starting state
DT <- copy(baseline_mcid)

## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_term)

## -----------------------------------------------------------------------------
# Extract desired columns
cols_we_want <- source_term[, .(mcid, term, hours_term, gpa_term)]

## -----------------------------------------------------------------------------
# Add desired columns
cols_we_want[DT, on = c("mcid")]

## -----------------------------------------------------------------------------
x <- cols_we_want[DT, on = c("mcid")]
y <- nrow(x)
z <- length(unique(x$mcid))

## -----------------------------------------------------------------------------
# Reusable starting state
DT <- copy(baseline_mcid)
DT

## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_degree)

## -----------------------------------------------------------------------------
# Extract desired columns
cols_we_want <- source_degree[, .(mcid, cip6, degree)]

## -----------------------------------------------------------------------------
# Add desired columns
cols_we_want[DT, on = c("mcid")]

## -----------------------------------------------------------------------------
x <- cols_we_want[DT, on = c("mcid")]
y <- length(unique(x$mcid))
z <- x[!is.na(cip6)]
z <- z[, .(mcid)]
z <- length(unique(z$mcid))

## -----------------------------------------------------------------------------
DT <- copy(baseline_cip)

## -----------------------------------------------------------------------------
# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)

## -----------------------------------------------------------------------------
DT <- copy(baseline_mcid)

## -----------------------------------------------------------------------------
# Join race/ethnicity and sex
cols_we_want <- student[, .(mcid, race, sex)]
DT <- cols_we_want[DT, on = c("mcid")]

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

