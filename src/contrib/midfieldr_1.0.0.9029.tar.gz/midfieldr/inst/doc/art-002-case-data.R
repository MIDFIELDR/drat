## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 7,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-002-")

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, degree)

## -----------------------------------------------------------------------------
# Work with required midfieldr variables only
student <- select_required(student)
term <- select_required(term)
degree <- select_required(degree)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)
DT

## -----------------------------------------------------------------------------
# Determine a timely completion term for every student
DT <- add_timely_term(DT, term)
DT

## -----------------------------------------------------------------------------
# Determine data sufficiency for every student
DT <- add_data_sufficiency(DT, term)
DT

## -----------------------------------------------------------------------------
# Retain observations having sufficient data
DT <- DT[data_sufficiency == "include"]
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Filter for degree seeking, output unique IDs
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
baseline <- copy(DT)

## -----------------------------------------------------------------------------
# Four engineering programs using 4-digit CIP codes
selected_programs <- filter_cip(c("^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"))
selected_programs

## -----------------------------------------------------------------------------
# Recode program labels. Edit as required.
selected_programs[, program := fcase(
  cip6 %like% "^1408", "CE",
  cip6 %like% "^1410", "EE",
  cip6 %like% "^1419", "ME",
  cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE"
)]

## -----------------------------------------------------------------------------
# Preserve settings
op <- options()
# Edit number of rows to print
options(datatable.print.nrows = 15)

# Confirm that abbreviations match the longer program names
selected_programs[, .(cip4name, program)]

## -----------------------------------------------------------------------------
selected_programs <- selected_programs[, .(cip6, program)]
selected_programs

# Restore original settings
options(op)

## -----------------------------------------------------------------------------
# IDs of data-sufficient, degree-seeking students
DT <- copy(baseline)
DT

## -----------------------------------------------------------------------------
# Left-outer join from term to DT
DT <- term[DT, .(mcid, cip6), on = c("mcid")]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Join program names and retain desired programs only
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT

## -----------------------------------------------------------------------------
# Filter for unique ID-program combinations
DT[, cip6 := NULL]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid", "program"))
ever_enrolled <- copy(DT)
ever_enrolled

## -----------------------------------------------------------------------------
# IDs of data-sufficient, degree-seeking students
DT <- copy(baseline)
DT

## -----------------------------------------------------------------------------
# Add timely completion term
DT <- add_timely_term(DT, term)
DT

## -----------------------------------------------------------------------------
# Add completion status
DT <- add_completion_status(DT, degree)
DT

## -----------------------------------------------------------------------------
# Retain timely completers
DT <- DT[completion_status == "timely"]
DT <- DT[, .(mcid)]
DT

## -----------------------------------------------------------------------------
DT <- degree[DT, .(mcid, term_degree, cip6), on = c("mcid")]
DT

## -----------------------------------------------------------------------------
# Join programs
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT

## -----------------------------------------------------------------------------
DT <- DT[, .SD[which.min(term_degree)], by = "mcid"]
DT

## -----------------------------------------------------------------------------
# Filter for unique ID-program combinations
DT[, c("cip6", "term_degree") := NULL]
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid", "program"))
graduates <- copy(DT)
graduates

## -----------------------------------------------------------------------------
ever_enrolled[, bloc := "ever_enrolled"]
graduates[, bloc := "graduates"]

## -----------------------------------------------------------------------------
# Combine two data frames
DT <- rbindlist(list(ever_enrolled, graduates), use.names = TRUE)
DT

## -----------------------------------------------------------------------------
# Join race/ethnicity and sex
cols_we_want <- student[, .(mcid, race, sex)]
DT <- cols_we_want[DT, on = c("mcid")]
DT

## -----------------------------------------------------------------------------
# Demonstrate equivalence
same_content(DT, study_observations)

## -----------------------------------------------------------------------------
#  # Find example IDs
#  
#  x <- graduates[ever_enrolled, on = "mcid"]
#  y <- x[is.na(program)]
#  y$mcid[duplicated(y$mcid)]
#  
#  y <- x[!is.na(program)]
#  y$mcid[duplicated(y$mcid)]
#  
#  x[program == i.program]
#  
#  mcid_we_want <- "MCID3112470255"
#  DT[mcid == mcid_we_want]
#  term[mcid == mcid_we_want]
#  degree[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Preserve settings
op <- options()

# Edit number of rows to print
options(datatable.print.nrows = 15)

## -----------------------------------------------------------------------------
# Display one student by ID
mcid_we_want <- "MCID3111171519"
DT[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Closer look at term
term[mcid == mcid_we_want]

# Closer look at degree
degree[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Display one student by ID
mcid_we_want <- "MCID3111150194"
DT[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Closer look at terms
term[mcid == mcid_we_want]

# Closer look at degree
degree[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Display one student by ID
mcid_we_want <- "MCID3111264877"
DT[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Closer look at term
term[mcid == mcid_we_want]

# Closer look at degree
degree[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Display one student by ID
mcid_we_want <- "MCID3112470255"
DT[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Closer look at term
term[mcid == mcid_we_want]

# Closer look at degree
degree[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Restore original settings
options(op)

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

