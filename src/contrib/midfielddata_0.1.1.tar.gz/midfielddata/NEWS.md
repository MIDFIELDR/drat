



## midfielddata 0.1.1 (2020-07-23)

  - reformatted data frames as data.tables

## midfielddata 0.1.0 (2018-06-20)

  - made public on GitHub



<!-- ### New features -->

<!-- ### Minor improvements -->

<!-- ### Bug fixes -->

<!-- ### Deprecated -->

<!-- ### Defunct -->
