## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 8,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-020-")
library(ggplot2)

## -----------------------------------------------------------------------------
# upper limit chart

# parameters
callout_color <- "gray60"
callout_line_size <- 0.3
anno_size <- 3.5 # 3.5 approx 10 point
vert_baseline <- 1.07
del <- 0.15 # delta y for dimension lines

# vertical dim lines
vert_dim_lines <- function(dt, cols) {
  data <- copy(dt)
  data[, .SD, .SDcols = cols]
  geom_segment(
    data = data,
    na.rm = TRUE,
    aes(
      x = get(cols[1]),
      xend = get(cols[1]),
      y = get(cols[2]) - del,
      yend = get(cols[2]) + del
    ),
    color = callout_color,
    linewidth = callout_line_size,
    linetype = 1
  )
}

# construct coordinates
coord <- wrapr::build_frame(
  "id", "row", "dash1", "dash2", "arrow1", "arrow2", "arrowlabel", "labelx" |
    "range", 3, NA, NA, 1986, 1996, "institution data range", 1989 |
    "A", 2, NA, NA, 1988, 1994, "TC term", 1994 |
    "B", 1, 1996, 1998, 1993, 1996, "TC term", 1998 |
    "limit", 0.2, NA, NA, NA, NA, "upper data limit", 1996
) |> data.table()

# x scale ticks
breaks_x <- sort(unique(coord[, round(c(dash1, dash2, arrow1, arrow2), 0)], na.rm = TRUE))

ggplot() +
  scale_x_continuous(breaks = breaks_x, limits = c(1983.5, 1999)) +
  scale_y_continuous(limits = c(-0.5, 3.5)) +
  labs(x = "Year", y = "") +
  theme_light() +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  ) +
  geom_segment( # arrows
    data = coord[, .(row, arrow1, arrow2)],
    na.rm = TRUE,
    aes(x = arrow1, xend = arrow2, y = row, yend = row),
    color = callout_color,
    linewidth = callout_line_size,
    arrow = arrow(
      type = "closed",
      length = unit(c(2, 2, 0), "mm"),
      ends = c("both", rep("last", nrow(coord) - 1))
    ),
    arrow.fill = callout_color
  ) +
  geom_segment( # dashed lines
    data = coord[, .(row, dash1, dash2)],
    na.rm = TRUE,
    aes(x = dash1, xend = dash2, y = row, yend = row),
    color = callout_color,
    linewidth = 1.5 * callout_line_size,
    linetype = 2
  ) +
  geom_point( # entry dots
    data = coord[id %chin% LETTERS, .(id, row, arrow1)],
    na.rm = TRUE,
    aes(x = arrow1, y = row),
    size = 2,
    color = callout_color
  ) +
  geom_segment(
    aes(
      x = 1996,
      xend = 1996,
      y = min(coord$row) - 2 * del,
      yend = max(coord$row) + 2 * del
    ),
    color = callout_color,
    linewidth = callout_line_size
  ) +
  vert_dim_lines(dt = coord, cols = c("dash2", "row")) +
  vert_dim_lines(dt = coord[id %chin% LETTERS], cols = c("arrow2", "row")) +
  vert_dim_lines(dt = coord[!id %chin% LETTERS], cols = c("arrow1", "row")) +
  geom_text(
    data = coord[, .(row, arrowlabel, labelx)],
    na.rm = TRUE,
    aes(x = labelx, y = row, label = arrowlabel),
    vjust = 1.5,
    hjust = -0.1
  ) +
  geom_text(
    data = coord[id %chin% LETTERS, .(id, row)],
    na.rm = TRUE,
    aes(x = 1986, y = row, label = paste0("student ", id, ":")),
    vjust = 0.5,
    hjust = 1.25
  )

## -----------------------------------------------------------------------------
# lower limit chart

# construct coordinates
coord <- wrapr::build_frame(
  "id", "row", "dash1", "dash2", "arrow1", "arrow2", "arrowlabel", "labelx" |
    "range", 4, NA, NA, 1986, 1996, "institution data range", 1989 |
    "A", 3, NA, NA, 1986.5, 1992.5, "TC term", 1992.5 |
    "C", 2, 1984, 1986, 1986, 1992, "TC term", 1992 |
    "D", 1, 1984, 1985.8, NA, NA, "lower data limit", 1986
) |> data.table()

# x scale ticks
breaks_x <- sort(unique(coord[, round(c(dash1, dash2, arrow1, arrow2), 0)], na.rm = TRUE))

# lower limit graph
ggplot() +
  scale_x_continuous(breaks = breaks_x, limits = c(1981.5, 1997)) +
  scale_y_continuous(limits = c(0.5, 4.5)) +
  labs(x = "Year", y = "") +
  theme_light() +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  ) +
  geom_segment( # arrows
    data = coord[, .(row, arrow1, arrow2)],
    na.rm = TRUE,
    aes(x = arrow1, xend = arrow2, y = row, yend = row),
    color = callout_color,
    linewidth = callout_line_size,
    arrow = arrow(
      type = "closed",
      length = unit(2, "mm"),
      ends = c("both", rep("last", nrow(coord) - 1))
    ),
    arrow.fill = callout_color
  ) +
  geom_segment( # dashed lines
    data = coord[, .(row, dash1, dash2)],
    na.rm = TRUE,
    aes(x = dash1, xend = dash2, y = row, yend = row),
    color = callout_color,
    linewidth = 1.5 * callout_line_size,
    linetype = 2
  ) +
  geom_point( # entry dots
    data = coord[id %chin% LETTERS, .(id, row, arrow1)],
    na.rm = TRUE,
    aes(x = arrow1, y = row),
    size = 2,
    color = callout_color
  ) +
  geom_segment(
    aes(
      x = 1986,
      xend = 1986,
      y = min(coord$row) - 2 * del,
      yend = max(coord$row) + 2 * del
    ),
    color = callout_color,
    linewidth = callout_line_size
  ) +
  vert_dim_lines(dt = coord, cols = c("dash1", "row")) +
  vert_dim_lines(dt = coord, cols = c("dash2", "row")) +
  vert_dim_lines(dt = coord, cols = c("arrow2", "row")) +
  geom_text(
    data = coord[, .(row, arrowlabel, labelx)],
    na.rm = TRUE,
    aes(x = labelx, y = row, label = arrowlabel),
    vjust = 1.5,
    hjust = -0.1
  ) +
  geom_text(
    data = coord[id %chin% LETTERS, .(id, row)],
    na.rm = TRUE,
    aes(x = 1984, y = row, label = paste0("student ", id, ":")),
    vjust = 0.5,
    hjust = 1.25
  )

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load data
data(term)

## -----------------------------------------------------------------------------
# Copy of source files with all variables
source_term <- copy(term)

# Select variables required by midfieldr functions
term <- select_required(source_term)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)
DT

## -----------------------------------------------------------------------------
# Retain the minimum number of columns
DT <- DT[, .(mcid, institution)]

## -----------------------------------------------------------------------------
# Filter for unique IDs
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- add_timely_term(dframe = DT, midfield_term = term)

# Required arguments in order, but not named
y <- add_timely_term(DT, term)

# Using the implicit default for the midfield_term argument
z <- add_timely_term(DT)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Add timely term column and supporting variables
DT <- add_timely_term(DT, term)
DT

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112785480"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3111860641"]

## -----------------------------------------------------------------------------
# A toy set of IDs
toy_mcid <- toy_student[, .(mcid)]

# Source data table names that differ from the defaults
toy_DT <- add_timely_term(dframe = toy_mcid, midfield_term = toy_term)

# Equivalently
toy_DT <- add_timely_term(toy_mcid, toy_term)
toy_DT

## -----------------------------------------------------------------------------
# Drop three columns
toy_DT <- toy_DT[, c("term_i", "level_i", "timely_term") := NULL]
toy_DT

## -----------------------------------------------------------------------------
# Demonstrate overwriting
toy_DT <- add_timely_term(toy_DT, toy_term)
toy_DT

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- add_data_sufficiency(dframe = DT, midfield_term = term)

# Required arguments in order, but not named
y <- add_data_sufficiency(DT, term)

# Using the implicit default for the midfield_term argument
z <- add_data_sufficiency(DT)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Un-clutter the printout
DT <- DT[, .(mcid, institution, timely_term)]

# Add data sufficiency column and supporting variables
DT <- add_data_sufficiency(DT, term)
DT

## -----------------------------------------------------------------------------
# Find the closer look IDs

x <- copy(DT)
x[data_sufficiency == "exclude-lower"]



DT[mcid == "MCID3111142689"]


x <- add_timely_term(x)
x[adj_span == 4]

## -----------------------------------------------------------------------------
# Data range by institution
term[order(institution), .(min_term = min(term), max_term = max(term)), by = "institution"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112785480"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3111170322"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112056754"]

## -----------------------------------------------------------------------------
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency, output unique IDs
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include", .(mcid)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

