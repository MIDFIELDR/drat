## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-020-degree-seeking-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# Degree seeking (inner joins)
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 55,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Set aside the source files in case they are needed
source_student <- copy(student)
source_term <- copy(term)

# Work with required midfieldr variables only
student <- select_required(student)
term <- select_required(term)

# View top few rows of the result
head(student, n = 3L)

head(term, n = 3L)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

# Drop unnecessary variables
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Isolate the IDs of the second data frame
toy_select <- toy_student[, .(mcid)]

# Inner join to filter the observations of the first data frame
merge(DT, toy_select, by = c("mcid"), all = FALSE)

## -----------------------------------------------------------------------------
x <- merge(DT, toy_select, by = c("mcid"), all = FALSE)

## -----------------------------------------------------------------------------
# Isolating the IDs inside the merge function
merge(DT, toy_student[, .(mcid)], by = c("mcid"), all = FALSE)

## -----------------------------------------------------------------------------
# A more computationally efficient approach
DT[toy_student, .(mcid), on = c("mcid"), nomatch = NULL]

## -----------------------------------------------------------------------------
# Swap the roles of the two data frames
toy_student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

## -----------------------------------------------------------------------------
# Three equivalent inner joins
x <- merge(DT, toy_student[, .(mcid)], by = c("mcid"), all = FALSE)
setkey(x, NULL)
y <- DT[toy_student, .(mcid), on = c("mcid"), nomatch = NULL]
z <- toy_student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

# Check equality
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Selecting columns from both data frames using merge()
x <- merge(DT[, .(mcid)], toy_student[, .(mcid, institution)], by = c("mcid"), all = FALSE)
setkey(x, NULL)

# Display the result
x[]

## -----------------------------------------------------------------------------
# Repeat using X[Y, j] syntax
y <- DT[toy_student, .(mcid, institution), on = c("mcid"), nomatch = NULL]

# Check equality
all.equal(x, y)

## -----------------------------------------------------------------------------
# Filter for degree seeking with an inner join 
DT <- DT[student, .(mcid), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 55,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Load data sets from midfielddata
#  data(student, term, package = "midfielddata")
#  
#  # Filter for data sufficiency
#  DT <- copy(term)
#  DT <- add_timely_term(DT, term)
#  DT <- add_data_sufficiency(DT, term)
#  DT <- DT[data_sufficiency == "include"]
#  DT <- DT[, .(mcid, cip6)]
#  DT <- unique(DT)
#  
#  # Three equivalent inner joins
#  x <- merge(DT, toy_student[, .(mcid)], by = c("mcid"), all = FALSE)
#  setkey(x, NULL)
#  y <- DT[toy_student, .(mcid, cip6), on = c("mcid"), nomatch = NULL]
#  z <- toy_student[DT, .(mcid, cip6), on = c("mcid"), nomatch = NULL]
#  all.equal(x, y)
#  all.equal(x, z)
#  
#  # Selecting columns
#  x <- merge(DT[, .(mcid)], toy_student[, .(mcid, institution)], by = c("mcid"), all = FALSE)
#  setkey(x, NULL)
#  y <- DT[toy_student, .(mcid, institution), on = c("mcid"), nomatch = NULL]
#  all.equal(x, y)
#  
#  # Degree seeking
#  DT <- DT[, .(mcid)]
#  DT <- unique(DT)
#  DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

