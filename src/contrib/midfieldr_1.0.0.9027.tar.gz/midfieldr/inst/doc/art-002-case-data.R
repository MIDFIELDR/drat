## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-002-case-data-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 15,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load three data sets from midfielddata
data(student, term, degree)

## -----------------------------------------------------------------------------
# Create a working data frame
DT <- copy(term)
str(DT)

## -----------------------------------------------------------------------------
# Minimize the dimensions of the data
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)

# Display the result
DT[]

# Count unique IDs
length(unique(DT$mcid))

## -----------------------------------------------------------------------------
# Calculate a timely completion term for every student
DT <- add_timely_term(DT, term)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? add_timely_term

## -----------------------------------------------------------------------------
# Determine data sufficiency for every student
DT <- add_data_sufficiency(DT, term)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? add_data_sufficiency

## -----------------------------------------------------------------------------
# Retain observations having sufficient data
DT <- DT[data_sufficiency == "include"]
DT <- DT[, .(mcid, cip6)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Inner join that filters DT
DT <- DT[student, .(mcid, cip6), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Gather program CIP codes
study_program <- filter_search(cip, keep_text = c("^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"))
study_program <- study_program[, .(cip6, cip4name)]

# Display the result
study_program[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? filter_search

## -----------------------------------------------------------------------------
# Assign four program names by CIP code
study_program[, program := fcase(
  cip6 %like% "^1408", "CE",
  cip6 %like% "^1410", "EE",
  cip6 %like% "^1419", "ME",
  cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE"
)]

# Confirm that abbreviations match the longer program names
print(study_program[, .(cip4name, program)])

## -----------------------------------------------------------------------------
# Case study CIPs and program names
study_program[, cip4name := NULL]

# Display the result
study_program[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_programs

## -----------------------------------------------------------------------------
# Left-outer join to DT
DT <- study_program[DT, .(mcid, cip6, program), on = c("cip6")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Retain observations in our four programs
DT <- DT[!is.na(program)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Drop duplicate rows
DT[, cip6 := NULL]
DT <- unique(DT)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Conclude development of the ever-enrolled observations
ever <- copy(DT)
ever[, group := "ever"]

# Display the result
ever[]

## -----------------------------------------------------------------------------
# Unique IDs of students ever enrolled in the study programs
DT <- DT[, .(mcid)]
DT <- unique(DT)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_mcid

## -----------------------------------------------------------------------------
# Inner join that filters DT
DT <- DT[degree, .(mcid, cip6), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Calculate a timely completion term for every student
DT <- add_timely_term(DT, term)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Determine completion status for every student
DT <- add_completion_status(DT, degree)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? add_completion_status

## -----------------------------------------------------------------------------
# Retain timely completers
DT <- DT[completion_status == "timely"]
DT <- DT[, .(mcid, cip6)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Left-outer join to DT
DT <- study_program[DT, .(mcid, program), on = c("cip6")]
DT <- DT[!is.na(program)]

# Unique observations
DT <- unique(DT)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Conclude development of the graduate observations
grad <- copy(DT)
grad[, group := "grad"]

# Display the result
grad[]

## -----------------------------------------------------------------------------
# Combine two data frames
DT <- rbindlist(list(ever, grad), use.names = TRUE)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Selecting columns from student
student_cols <- student[, .(mcid, race, sex)]

# Add them to DT with a left outer join
DT <- student_cols[DT, on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID26694225"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID25786154"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID25868925"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MID26526757"]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_observations

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Import data
#  data(student, term, degree)
#  
#  # Gather ever enrolled
#  DT <- copy(term)
#  DT <- DT[, .(mcid, cip6)]
#  DT <- unique(DT)
#  
#  # Filter for data sufficiency
#  DT <- add_timely_term(DT, term)
#  DT <- add_data_sufficiency(DT, term)
#  DT <- DT[data_sufficiency == "include"]
#  DT <- DT[, .(mcid, cip6)]
#  
#  # Filter for degree-seeking
#  DT <- DT[student, .(mcid, cip6), on = c("mcid"), nomatch = NULL]
#  
#  # Filter by program
#  study_program <- filter_search(cip, keep_text = c("^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"))
#  study_program <- study_program[, .(cip6, cip6name)]
#  study_program[, program := fcase(
#    cip6 %like% "^1408", "CE",
#    cip6 %like% "^1410", "EE",
#    cip6 %like% "^1419", "ME",
#    cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE"
#  )]
#  DT <- study_program[DT, .(mcid, cip6, program), on = c("cip6")]
#  DT <- DT[!is.na(program)]
#  DT[, cip6 := NULL]
#  DT <- unique(DT)
#  ever <- copy(DT)
#  ever[, group := "ever"]
#  
#  # Gather graduate subset
#  DT <- DT[, .(mcid)]
#  DT <- unique(DT)
#  DT <- DT[degree, .(mcid, cip6), on = c("mcid"), nomatch = NULL]
#  
#  # Filter by completion status
#  DT <- add_timely_term(DT, midfield_term = term)
#  DT <- add_completion_status(DT, degree)
#  DT <- DT[completion_status == "positive"]
#  DT <- DT[, .(mcid, cip6)]
#  
#  # Filter by program
#  DT <- study_program[DT, .(mcid, program), on = c("cip6")]
#  DT <- DT[!is.na(program)]
#  DT <- unique(DT)
#  grad <- copy(DT)
#  grad[, group := "grad"]
#  
#  # Combine two data frames and match the column names
#  DT <- rbindlist(list(ever, grad), use.names = TRUE)
#  
#  # Add demographics
#  student_cols <- student[, .(mcid, race, sex)]
#  DT <- student_cols[DT, on = c("mcid")]

## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

