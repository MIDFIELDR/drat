## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-070-creating-fye-proxies-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Only if creating your own FYE proxies
library("mice")

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load data sets from midfielddata
data(student, term)

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? student
#  ? term

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? prep_fye_mice

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- prep_fye_mice(midfield_student = student, midfield_term = term)

# Required arguments in order, but not named
y <- prep_fye_mice(student, term)

# Using the implicit defaults
z <- prep_fye_mice()

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Create the working data frame
fye <- prep_fye_mice(student, term)

# Display the result
fye[]

## -----------------------------------------------------------------------------
N_ever_fye <- length(unique(fye$mcid))
N_to_impute <- sum(is.na(fye$proxy))

## -----------------------------------------------------------------------------
# Number of complete cases on four variables
(N_complete <- sum(complete.cases(fye[, .(mcid, race, sex, institution)])))

## -----------------------------------------------------------------------------
# Number NAs in proxy
(N_impute <- sum(is.na(fye$proxy)))

## -----------------------------------------------------------------------------
pct_missing <- round(100 * N_impute / N_complete, 0)

## -----------------------------------------------------------------------------
# Percent missing proxies
round(100 * N_impute / N_complete, 3)

## -----------------------------------------------------------------------------
# Set aside for the chart
fye_missing_proxy <- copy(fye)

## -----------------------------------------------------------------------------
# Imputation framework
framework <- mice(fye, maxit = 0)

# Display the results
framework

## -----------------------------------------------------------------------------
# Imputation method
method_vector <- framework[["method"]]

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Manually assign the variable(s) being imputed
method_vector[c("proxy")] <- "polyreg"

# Manually assign the variable(s) not being imputed
method_vector[c("mcid", "institution", "race", "sex")] <- ""

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
predictor_matrix <- framework[["predictorMatrix"]]

# Display the results
predictor_matrix

## -----------------------------------------------------------------------------
# Predictor row for this example
predictor_matrix["proxy", ]

## -----------------------------------------------------------------------------
# Manually assign zero columns
predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)

# Manually assign predictor columns
predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)

# Display the result
predictor_matrix

## -----------------------------------------------------------------------------
# Data frame to illustrate optional predictors
opt_fye <- copy(fye)

# Factor to character
cols_to_edit <- c("race", "sex")
opt_fye[, (cols_to_edit) := lapply(.SD, as.character), .SDcols = cols_to_edit]

# Filter unknown race and sex
opt_fye <- opt_fye[sex != "Unknown"]
opt_fye <- opt_fye[race != "Other/Unknown"]

# Create origin variable
opt_fye[, origin := fcase(
    race != "International", "Domestic", 
    race == "International", "International", 
    default = NA_character_
)]
opt_fye <- opt_fye[!is.na(origin)]

# Create people variable
opt_fye[, people := paste(origin, sex)]
opt_fye[, people := as.factor(people)]
opt_fye[, c("race", "sex", "origin") := NULL]

# Display result
setcolorder(opt_fye, c("mcid", "people", "institution", "proxy"))
opt_fye[]

## -----------------------------------------------------------------------------
# Display unique people
sort(unique(opt_fye$people))

## -----------------------------------------------------------------------------
# Add all term variables by ID
cols_to_join <- term[, .(mcid, term)]
opt_fye <- cols_to_join[opt_fye, on = c("mcid")]

# Filter for first term
setkeyv(opt_fye, c("mcid", "term"))
opt_fye <- opt_fye[, .SD[1], by = c("mcid")]

# Create year variable
opt_fye[, year := substr(term, 1, 4)]
opt_fye[, year := as.factor(year)]
opt_fye[, term := NULL]

# Display result
setcolorder(opt_fye, c("mcid", "people", "institution", "year", "proxy"))
opt_fye[]

## -----------------------------------------------------------------------------
# Identify complete cases in predictor variables 
rows_we_want <- complete.cases(opt_fye[, .(mcid, people, institution, year)])

# Filter for complete predictors
opt_fye <- opt_fye[rows_we_want]

# Display the result
opt_fye[]

## -----------------------------------------------------------------------------
# Imputation framework
opt_framework <- mice(opt_fye, maxit = 0)

# Display the results
opt_framework

## -----------------------------------------------------------------------------
# Imputation framework
opt_method_vector <- opt_framework[["method"]]

# Display the results
opt_method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
opt_predictor_matrix <- opt_framework[["predictorMatrix"]]

# Display the results
opt_predictor_matrix

## -----------------------------------------------------------------------------
N_impute <- sum(is.na(opt_fye$proxy))
N_fye <- nrow(opt_fye)

# Percent missing data
round(100 * N_impute / N_fye, 0)

## -----------------------------------------------------------------------------
# load fye_mids, don't have to repeatedly run mice() 
load(here::here("R", "sysdata.rda"))

## -----------------------------------------------------------------------------
#  # Impute missing proxy data
#  fye_mids <- mice(
#    data = fye,
#    m = 38,
#    maxit = 5, # default
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )

## -----------------------------------------------------------------------------
# output in console with printFlag = TRUE
# >  iter imp variable
# >   1   1  proxy
# >   1   2  proxy
# >   1   3  proxy
# >   1   4  proxy
# >   1   5  proxy
# >   ---
# >   5  34  proxy
# >   5  35  proxy
# >   5  36  proxy
# >   5  37  proxy
# >   5  38  proxy

## -----------------------------------------------------------------------------
# Revert to default random number generation
set.seed(NULL)

# Extract data from the mids object
fye <- mice::complete(fye_mids)

# Convert to data.table structure
setDT(fye)

# Display the result
fye <- fye[order(mcid)]
fye[]

## -----------------------------------------------------------------------------
# Subset the data
fye <- fye[, .(mcid, proxy)]

# Display the result
fye

## -----------------------------------------------------------------------------
# Convert factors
fye[, proxy := as.character(proxy)]

# Display the result
fye

## -----------------------------------------------------------------------------
# Obtain first term of all students in term data
all_start <- term[, .(mcid, term, cip6)]
setorderv(all_start, cols = c("mcid", "term"))
all_start <- all_start[, .SD[1], by = c("mcid")]

# Subset for FYE only
fye_start <- all_start[cip6 == "140102", .(mcid)]
fye_start

# Inner join to retain the FYE starters
fye <- fye_start[fye, on = c("mcid"), nomatch = NULL]

# Display the result
fye

## -----------------------------------------------------------------------------
#  # Run manually if necessary for reproducibility
#  # Writing internal file sysdata.rda to save fye_mids
#  # Writing external file fye_proxy
#  
#  # Internal files
#  usethis::use_data(
#    fye_mids,
#    subset_student,
#    subset_course,
#    subset_term,
#    subset_degree,
#    internal  = TRUE,
#    overwrite = TRUE
#  )
#  
#  # External file
#  fye_proxy <- copy(fye)
#  usethis::use_data(fye_proxy, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Verify that result matches the built-in data set
all.equal(fye, fye_proxy)

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  suppressPackageStartupMessages(library("ggplot2"))
#  
#  # Only if creating your own FYE proxies
#  library("mice")
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 17,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Creating FYE proxies
#  data(student, term)
#  fye <- prep_fye_mice(student, term)
#  
#  # Percent missing proxy data
#  N_complete <- sum(complete.cases(fye[, .(mcid, race, sex, institution)]))
#  N_impute <- sum(is.na(fye$proxy))
#  round(100 * N_impute / N_complete, 3)
#  
#  # Set aside for the chart
#  fye_missing_proxy <- copy(fye)
#  
#  # Using mice()
#  framework <- mice(fye, maxit = 0)
#  
#  # Method vector
#  method_vector <- framework[["method"]]
#  method_vector[c("proxy")] <- "polyreg"
#  method_vector[c("mcid", "institution", "race", "sex")] <- ""
#  
#  # Imputation predictor matrix
#  predictor_matrix <- framework[["predictorMatrix"]]
#  predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)
#  predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)
#  
#  # Optional predictors
#  opt_fye <- copy(fye)
#  cols_to_edit <- c("race", "sex")
#  opt_fye[, (cols_to_edit) := lapply(.SD, as.character), .SDcols = cols_to_edit]
#  opt_fye <- opt_fye[sex != "Unknown"]
#  opt_fye <- opt_fye[race != "Other/Unknown"]
#  opt_fye[, origin := fcase(
#      race != "International", "Domestic",
#      race == "International", "International",
#      default = NA_character_
#  )]
#  opt_fye <- opt_fye[!is.na(origin)]
#  opt_fye[, people := paste(origin, sex)]
#  opt_fye[, people := as.factor(people)]
#  opt_fye[, c("race", "sex", "origin") := NULL]
#  
#  # Optional predictors add a variable
#  cols_to_join <- term[, .(mcid, term)]
#  opt_fye <- cols_to_join[opt_fye, on = c("mcid")]
#  setkeyv(opt_fye, c("mcid", "term"))
#  opt_fye <- opt_fye[, .SD[1], by = c("mcid")]
#  opt_fye[, year := substr(term, 1, 4)]
#  opt_fye[, year := as.factor(year)]
#  opt_fye[, term := NULL]
#  setcolorder(opt_fye, c("mcid", "people", "institution", "year", "proxy"))
#  
#  # Optional predictors filter complete cases
#  rows_we_want <- complete.cases(opt_fye[, .(mcid, people, institution, year)])
#  opt_fye <- opt_fye[rows_we_want]
#  
#  # Optional predictors framework and method
#  opt_framework <- mice(opt_fye, maxit = 0)
#  opt_method_vector <- opt_framework[["method"]]
#  opt_predictor_matrix <- opt_framework[["predictorMatrix"]]
#  
#  # Optional predictors percent missing data
#  N_impute <- sum(is.na(opt_fye$proxy))
#  N_fye <- nrow(opt_fye)
#  round(100 * N_impute / N_fye, 0)
#  
#  # Imputing missing values
#  fye_mids <- mice(
#    data = fye,
#    m = 38,
#    maxit = 5, # default
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )
#  
#  # Extract the result
#  set.seed(NULL)
#  fye <- mice::complete(fye_mids)
#  setDT(fye)
#  fye <- fye[order(mcid)]
#  
#  # Post-processing
#  fye <- fye[, .(mcid, proxy)]
#  fye[, proxy := as.character(proxy)]
#  all_start <- term[, .(mcid, term, cip6)]
#  setorderv(all_start, cols = c("mcid", "term"))
#  all_start <- all_start[, .SD[1], by = c("mcid")]
#  fye_start <- all_start[cip6 == "140102", .(mcid)]
#  fye <- fye_start[fye, on = c("mcid"), nomatch = NULL]
#  
#  # Confirming results
#  all.equal(fye, fye_proxy)

## -----------------------------------------------------------------------------
#  # New memory location
#  x <- copy(fye_missing_proxy)
#  
#  # Convert factors to characters
#  x <- x[, lapply(.SD, as.character)]
#  
#  # Overall percentage missing proxies
#  overall_miss <- 100 * round(nrow(x[is.na(proxy)]) / nrow(x), 3)
#  
#  # Determine percent missing proxies by category
#  missing_fraction <- function(DT, cat_level) {
#    DT[, group := fcase(
#        is.na(proxy), "missing",
#        default = "not_missing"
#    )]
#    DT <- DT[, .N, by = c("group", "cat_level")]
#    DT <- dcast(DT, cat_level ~ group, value.var = "N")
#    DT[, pct_miss := 100 * round(missing / (missing + not_missing), 3)]
#    DT <- DT[, .(cat_level, pct_miss)]
#  }
#  
#  
#  y <- x[, .(cat_level = institution, proxy)]
#  inst <- missing_fraction(y, cat_level = "institution")
#  inst[, category := "institution"]
#  
#  y <- x[, .(cat_level = race, proxy)]
#  race <- missing_fraction(y, cat_level = "race")
#  race[, category := "race"]
#  
#  y <- x[, .(cat_level = sex, proxy)]
#  sex <- missing_fraction(y, cat_level = "sex")
#  sex[, category := "sex"]
#  
#  DT <- rbindlist(list(inst, race, sex))
#  
#  p <- ggplot(DT, aes(x = pct_miss, y = reorder(cat_level, pct_miss))) +
#      geom_vline(xintercept = overall_miss, linetype = 2, color = "gray35") +
#      geom_point(size = 2) +
#      facet_grid(rows = vars(reorder(category, pct_miss)),
#                 as.table = TRUE,
#                 scales = "free_y",
#                 space = "free_y") +
#      labs(x = "FYE proxy missing values (%)", y = "") +
#      scale_x_continuous(breaks = seq(0, 100, 5), limits = c(20, 50)) +
#      theme(panel.grid.minor.x = element_blank())

## -----------------------------------------------------------------------------
# Run manually to save figure
# ggsave(
#   filename = "man/figures/art-070-creating-fye-proxies-pct-missing.png",
#   plot = p, 
#   width = 7,
#   height = 0.4 * 7,
#   units = "in"
# )

## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

