## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-060-tabulating-data-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}
asp_ratio_mw <- function(data, categories) {
  cat1 <- categories[1] # panels
  cat2 <- categories[2] # rows
  nlevel1 <- nlevels(data[, get(cat1)])
  nlevel2 <- nlevels(data[, get(cat2)])
  r <- nlevel1 * nlevel2
  q <- 32
  asp_ratio1 <- (r + 2 * nlevel1) / q
  asp_ratio2 <- (r + 2 * nlevel2) / q
  ratios <- c(asp_ratio1, asp_ratio2)
}

## ----echo = FALSE-------------------------------------------------------------
# Simple, short case to illustrate
library("midfieldr")
library("midfielddata")
library("data.table")
DT <- copy(study_stickiness)
DT <- DT[program %chin% c("Civil", "Electrical", "Mechanical")]
DT <- DT[race_sex %chin% c("Asian Female", "Black Female", "White Female")]
DT <- DT[, .(race_sex, program, stick)]
DT <- DT[order(race_sex, program)]

long_data <- copy(DT)
wide_data <- copy(DT)
wide_data <- dcast(wide_data, race_sex ~ program, value.var = "stick")

kable2html(long_data, caption = "Table 1. Block-record form")

## ----echo = FALSE-------------------------------------------------------------
kable2html(wide_data, caption = "Table 2. Row-record form")

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("janitor")

# optional code to control data.table printing
options(
  datatable.print.nrows = 10,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Copy to avoid update by reference
block_form <- copy(study_stickiness)

# Omit before presenting
block_form <- block_form[ever >= 10]
block_form <- block_form[!race_sex %ilike% c("International|Other|Native")]

# Examine the result
block_form

## -----------------------------------------------------------------------------
# Three columns
block_form <- block_form[, .(program, race_sex, stick)]

# examine the result
block_form

## ----echo = FALSE-------------------------------------------------------------
kable2html(block_form, caption = "Table 3. Stickiness in block-record form")

## -----------------------------------------------------------------------------
# create a new memory location
row_form <- copy(block_form)

# convert factors to characters
row_form[, race_sex := as.character(race_sex)]
row_form[, program := as.character(program)]

## -----------------------------------------------------------------------------
# reshape
row_form <- dcast(row_form, race_sex ~ program, value.var = "stick")

# examine the result
row_form

## -----------------------------------------------------------------------------
setnames(row_form,
  old = c("race_sex"),
  new = c("Race/Ethnicity/Sex")
)

## ----echo = FALSE-------------------------------------------------------------
kable2html(row_form, caption = "Table 4. Stickiness in row-record form")

## -----------------------------------------------------------------------------
melt(row_form,
  id.vars = "Race/Ethnicity/Sex",
  measure.vars = c("Civil", "Electrical", "Industrial", "Mechanical"),
  variable.name = "program",
  value.name = "stick"
)

## -----------------------------------------------------------------------------
# Create a new memory location
DT <- copy(study_student)

# View the data
DT

## -----------------------------------------------------------------------------
# Merge the groups as usual
DT[, race_sex := paste(race, sex)]

# Subset the same populations as above
DT <- DT[!race_sex %ilike% c("International|Other|Native")]

## -----------------------------------------------------------------------------
DT <- DT[, .N, by = c("program", "race_sex")]

# omit small populations
DT <- DT[N >= 10]

# Examine the result
DT

## -----------------------------------------------------------------------------
DT <- dcast(DT, race_sex ~ program, value.var = "N")

# Examine the result
DT

## -----------------------------------------------------------------------------
DT <- adorn_totals(DT, where = c("row", "col"), na.rm = TRUE)

DT

## ----echo = FALSE-------------------------------------------------------------
setnames(DT,
  old = c("race_sex"),
  new = c("Race/Ethnicity/Sex")
)
kable2html(DT, caption = "Table 5. Two-way frequency table with totals")

## ----eval = FALSE-------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("janitor")
#  
#  # optional code to control data.table printing
#  options(
#    datatable.print.nrows = 10,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Block-record form
#  block_form <- copy(study_stickiness)
#  block_form <- block_form[ever >= 10]
#  block_form <- block_form[!race_sex %ilike% c("International|Other|Native")]
#  block_form <- block_form[, .(program, race_sex, stick)]
#  
#  # Transform block-records to row-records
#  row_form <- copy(block_form)
#  row_form[, race_sex := as.character(race_sex)]
#  row_form[, program := as.character(program)]
#  row_form <- dcast(row_form, race_sex ~ program, value.var = "stick")
#  setnames(row_form,
#    old = c("race_sex"),
#    new = c("Race/Ethnicity/Sex")
#  )
#  
#  # Transform row-records to block-records
#  melt(row_form,
#    id.vars = "Race/Ethnicity/Sex",
#    measure.vars = c("Civil", "Electrical", "Industrial", "Mechanical"),
#    variable.name = "program",
#    value.name = "stick"
#  )
#  
#  # Tables with totals
#  DT <- copy(study_student)
#  DT[, race_sex := paste(race, sex)]
#  DT <- DT[!race_sex %ilike% c("International|Other|Native")]
#  DT <- DT[, .N, by = c("program", "race_sex")]
#  DT <- DT[N >= 10]
#  DT <- dcast(DT, race_sex ~ program, value.var = "N")
#  DT <- adorn_totals(DT, where = c("row", "col"), na.rm = TRUE)

## ----echo = FALSE-------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

