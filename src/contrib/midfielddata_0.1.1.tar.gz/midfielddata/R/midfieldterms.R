#' Term data for 98,000 undergraduates
#'
#' Data frame of term attributes of 97,064 undergraduates with 727,369
#' observations and 13 academic term variables keyed by student ID and term.
#' Each observation is one term for one student. A stratified sample
#' of the MIDFIELD database.
#'
#' @format \code{data.table} with 729,014 observations and 13 variables,
#' occupying 82.1 MB of memory. Each observation is one term for one student.
#' The variables are:
#' \describe{
#'   \item{id}{character, unique anonymized MIDFIELD student identifier}
#'   \item{institution}{character, anonymized institution name}
#'   \item{cip6}{character, 6-digit CIP code of instructional program
#'       during the term}
#'   \item{term_course}{numeric, academic year and term, format YYYYT}
#'   \item{level}{character, level}
#'   \item{standing}{character, standing}
#'   \item{coop}{character, coop "Y" or "N"}
#'   \item{hours_term_attempt}{numeric, credit hours attempted in the term}
#'   \item{hours_term}{numeric, credit hours earned in the term}
#'   \item{gpa_term}{numeric, term grade point average}
#'   \item{hours_cumul_attempt}{numeric, cumulative credit hours attempted}
#'   \item{hours_cumul}{numeric, cumulative credit hours earned}
#'   \item{gpa_cumul}{numeric, cumulative grade point average}
#' }
#' @source Data provided by the MIDFIELD project:
#' \url{https://engineering.purdue.edu/MIDFIELD}
#' @examples
#' \dontrun{
#' library(data.table)
#' midfieldterms
#' }
#' 
"midfieldterms"
