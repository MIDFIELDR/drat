## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-080-graduation-rate-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## ----echo = FALSE-------------------------------------------------------------
suppressPackageStartupMessages(library("data.table"))
DT <- wrapr::build_frame(
  "Constraints", "IPEDS", "MIDFIELD", "MIDFIELD notes" |
    "completion span:", "4, 6, or 8 years", "4, 6, or 8 years", "Typical usage is 6 years" |
    "students admitted in:", "Summer/Fall only", "any term", "" |
    "part-time students are:", "excluded", "included", "Timely completion same as full-time students" |
    "transfer students are:", "excluded", "included", "Timely completion span adjusted for level at entry" |
    "migrators:", "see below", "see below", "A heuristic could be developed for extending the completion span"
)

DT |>
  kableExtra::kbl(align = "llll") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::column_spec(1:2, color = "black", background = "white") |>
  kableExtra::row_spec(c(0), background = "#c7eae5")

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Printing options for data.table
options(
  datatable.print.nrows = 21,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Case study starters
study_starters

## -----------------------------------------------------------------------------
# Case study graduates
study_observations

## -----------------------------------------------------------------------------
# Load data from midfielddata
data(student)

# Display selected columns
student[, .(mcid, race, sex)]

## -----------------------------------------------------------------------------
# Create a working data frame
DT <- study_starters[, .(mcid, program)]

# Rename the program variable
setnames(DT, old = "program", new = "program_start")

# Create a group variable
DT[, group := "start"]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter for graduates only
grad <- study_observations[group == "grad", .(mcid, program, group)]

# Rename the program variable
setnames(grad, old = "program", new = "program_grad")

# Display the result
grad[]

## -----------------------------------------------------------------------------
join_cols <- DT[, .(mcid, program_start)]
grad <- join_cols[grad, on = "mcid"]

# Display the result
grad[]

## -----------------------------------------------------------------------------
grad <- grad[program_start == program_grad]

# Display the result
grad[]

## -----------------------------------------------------------------------------
# Drop an unnecessary variable 
grad[, program_start := NULL]

# Display the result
grad[]

## -----------------------------------------------------------------------------
# Rename the program variables to match before binding
setnames(DT, old = "program_start", new = "program")
setnames(grad, old = "program_grad", new = "program")

# Combine data tables
DT <- rbindlist(list(DT, grad))

# Display the result
DT[]

## -----------------------------------------------------------------------------
DT <- student[DT, .(mcid, program, group, race, sex), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Count by the grouping variables 
DT <- DT[, .N, by = c("group", "program", "race", "sex")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Transform to row-record form
DT <- dcast(DT, program + sex + race ~ group, value.var = "N", fill = 0)

# Display the result
DT[]

DT[, rate := round(100 * grad / start, 1)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Preserve anonymity
DT <- DT[grad >= 10]

# Display the result
DT[]

# Filter by study design
DT <- DT[!race %chin% c("International", "Other/Unknown")]

# Display the result
DT[]

DT[, people := paste(race, sex)]
DT[, c("race", "sex") := NULL]
setcolorder(DT, c("program", "people"))

# Display the result
DT[]

DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]

# Display the result
DT[]

# Convert categorical variables to factors
DT <- order_multiway(DT,
  quantity = "rate",
  categories = c("program", "people"),
  method = "percent",
  ratio_of = c("grad", "start")
)

# Display the result
DT[]

## ----grad-rate-people---------------------------------------------------------
ggplot(DT, aes(x = rate, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = program_rate), linetype = 2) +
  geom_point() +
  labs(x = "Graduation rate (%)", y = "") 

## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

