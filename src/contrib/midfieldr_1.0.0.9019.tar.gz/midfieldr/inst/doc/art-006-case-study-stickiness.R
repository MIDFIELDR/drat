## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-006-case-study-stickiness-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}
asp_ratio_mw <- function(data, categories) {
  cat1 <- categories[1] # panels
  cat2 <- categories[2] # rows
  nlevel1 <- nlevels(data[, get(cat1)])
  nlevel2 <- nlevels(data[, get(cat2)])
  r <- nlevel1 * nlevel2
  q <- 32
  asp_ratio1 <- (r + 2 * nlevel1) / q
  asp_ratio2 <- (r + 2 * nlevel2) / q
  ratios <- c(asp_ratio1, asp_ratio2)
}

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("midfielddata")
library("data.table")
library("ggplot2")

# optional code to control data.table printing
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# load data tables from midfielddata
data(degree)

## -----------------------------------------------------------------------------
# Create a new memory location to avoid updating by reference
DT <- copy(study_student)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Determine whether the timely completion criterion is satisfied
DT <- add_completion_timely(DT, midfield_degree = degree)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Construct one of the grouping variables.
DT[, race_sex := paste(race, sex)]

# Examine the result
DT

## -----------------------------------------------------------------------------
# A reusable vector for grouping, summarizing, and joining.
grouping_variables <- c("program", "race_sex")

## -----------------------------------------------------------------------------
# Create a new memory location to avoid updating by reference
enrolled <- copy(DT)

# Count
enrolled <- enrolled[, .(ever = .N), by = grouping_variables]

# Examine the result
enrolled

## -----------------------------------------------------------------------------
# Create a new memory location to avoid updating by reference
completed <- copy(DT)

# Limit the graduate count to those with timely completion
completed <- completed[completion_timely == TRUE]

# Examine the result
completed

## -----------------------------------------------------------------------------
# Obtain count of graduates
completed <- completed[, .(grad = .N), by = grouping_variables]

# Examine the result
completed

## -----------------------------------------------------------------------------
# Join
DT <- merge(enrolled, completed, by = grouping_variables, all.x = TRUE)

# Examine the result
DT

# Merging created a data.table "key" that we delete
setkey(DT, NULL)

## -----------------------------------------------------------------------------
# Checking if any NAs were introduced in the grad column
sum(is.na(DT$grad))

## -----------------------------------------------------------------------------
# NA in this case represents a count of zero
DT[is.na(grad), grad := 0][]

# Examine the result
DT

## -----------------------------------------------------------------------------
# data table printing option
options(datatable.print.topn = 40)

# Reached our goal of computing longitudinal stickiness
DT[, stick := round(100 * grad / ever, 1)]

# Examine the result
DT

## -----------------------------------------------------------------------------
study_stickiness

## -----------------------------------------------------------------------------
all.equal(DT, study_stickiness)

## -----------------------------------------------------------------------------
# Omit before graphing
DT <- DT[ever >= 10]

## -----------------------------------------------------------------------------
# data table printing option
options(datatable.print.topn = 3)

# Omit before graphing
DT <- DT[!race_sex %ilike% c("International|Other|Native")]

# Examine the result
DT

## -----------------------------------------------------------------------------
DT <- condition_multiway(
  dframe = DT, # input data frame
  categ_col = c("program", "race_sex"), # multiway categorical variables
  quant_col = "stick", # multiway quantitative variable
  detail = FALSE, # do not return columns of details
  order_by = "percent", # row and panel ordering method
  param_col = c("grad", "ever") # parameters used for ordering
)

# Examine the result
DT

## ----echo = FALSE-------------------------------------------------------------
mw <- copy(DT[, .(program, race_sex, stick)])
asp_ratio <- asp_ratio_mw(mw, categories = c("program", "race_sex"))

## ----fig1, fig.asp = asp_ratio[1]---------------------------------------------
ggplot(data = DT, aes(x = stick, y = race_sex)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_point(na.rm = TRUE) +
  labs(
    x = "Stickiness (%)",
    y = "",
    title = "Ordered by computed group metric",
    caption = "Source: midfielddata."
  )

## ----eval=FALSE---------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("midfielddata")
#  library("data.table")
#  library("ggplot2")

