## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 8,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-060-")

## -----------------------------------------------------------------------------
library("midfieldr")
library("midfielddata")
library("data.table")
library("ggplot2")
library("mice")

## -----------------------------------------------------------------------------
# Load practice data
data(student, term)

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- prep_fye_mice(midfield_student = student, midfield_term = term)

# Required arguments in order, but not named
y <- prep_fye_mice(student, term)

# Using the implicit defaults
z <- prep_fye_mice()

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## ---- echo=c(4, 5, 6)---------------------------------------------------------
op <- options()
options(datatable.print.class = TRUE)

# Working data frame
DT <- prep_fye_mice(student, term)
DT

options(op)

## -----------------------------------------------------------------------------
N_ever_fye <- length(unique(DT$mcid))
N_to_impute <- sum(is.na(DT$proxy))

## -----------------------------------------------------------------------------
# Number of unique IDs
x <- length(unique(DT$mcid))

# Number of complete cases on four variables
y <- sum(complete.cases(DT[, .(mcid, race, sex, institution)]))

# Demonstrate equivalence
all.equal(x, y)

## -----------------------------------------------------------------------------
# Number NAs in proxy
sum(is.na(DT$proxy))

# Percentage NAs in proxy
100 * round(sum(is.na(DT$proxy)) / nrow(DT), 3)

## -----------------------------------------------------------------------------
# Number of proxies to be imputed
(N_impute <- sum(is.na(DT$proxy)))

# Number of observations with complete predictor information
(N_complete <- sum(complete.cases(DT[, .(mcid, race, sex, institution)])))

# Percent missing proxies
(percent_missing <- round(100 * N_impute / N_complete, 3))

## -----------------------------------------------------------------------------
# For the "m" argument in mice()
(m_imputations <- round(percent_missing, 0))

## -----------------------------------------------------------------------------
# New memory location
x <- copy(DT)

# Convert factors to characters
x <- x[, lapply(.SD, as.character)]

# Overall percentage missing proxies
overall_miss <- 100 * round(nrow(x[is.na(proxy)]) / nrow(x), 3)

# Function for determining percent missing proxies by category
missing_fraction <- function(DT, cat_level) {
  DT[, group := fcase(
    is.na(proxy), "missing",
    default = "not_missing"
  )]
  DT <- DT[, .N, by = c("group", "cat_level")]
  DT <- dcast(DT, cat_level ~ group, value.var = "N")
  DT[, pct_miss := 100 * round(missing / (missing + not_missing), 3)]
  DT <- DT[, .(cat_level, pct_miss)]
}

# Apply to institution category
y <- x[, .(cat_level = institution, proxy)]
inst <- missing_fraction(y, cat_level = "institution")
inst[, category := "institution"]

# Apply to race/ethnicity category
y <- x[, .(cat_level = race, proxy)]
race <- missing_fraction(y, cat_level = "race")
race[, category := "race"]

# Apply to sex category
y <- x[, .(cat_level = sex, proxy)]
sex <- missing_fraction(y, cat_level = "sex")
sex[, category := "sex"]

# Gather results and plot
# Use race and sex only, only one institution
df <- rbindlist(list(race, sex))
ggplot(df, aes(x = pct_miss, y = reorder(cat_level, pct_miss))) +
  geom_vline(xintercept = overall_miss, linetype = 2, color = "gray35") +
  geom_point(size = 1.5) +
  facet_grid(
    rows = vars(reorder(category, pct_miss)),
    as.table = TRUE,
    scales = "free_y",
    space = "free_y"
  ) +
  labs(x = "FYE proxy missing values (%)", y = "") +
  scale_x_continuous(breaks = seq(0, 100, 5), limits = c(30, 55)) +
  theme(panel.grid.minor.x = element_blank())

## -----------------------------------------------------------------------------
# Imputation framework
framework <- mice(DT, maxit = 0)
framework

## -----------------------------------------------------------------------------
# Examine the warning
framework$loggedEvents

## -----------------------------------------------------------------------------
# Imputation method
method_vector <- framework[["method"]]
method_vector

## -----------------------------------------------------------------------------
# Manually assign the variable(s) being imputed
method_vector[c("proxy")] <- "polyreg"

# Manually assign the variable(s) not being imputed
method_vector[c("mcid", "institution", "race", "sex")] <- ""
method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
predictor_matrix <- framework[["predictorMatrix"]]
predictor_matrix

## -----------------------------------------------------------------------------
# Predictor row for this example
predictor_matrix["proxy", ]

## -----------------------------------------------------------------------------
# Manually assign zero columns
predictor_matrix[, c("mcid", "proxy", "institution")] <- 0

# Manually assign predictor columns
predictor_matrix[, c("race", "sex")] <- c(0, 0, 0, 0, 1)
predictor_matrix

## -----------------------------------------------------------------------------
#  # Not run
#  predictor_matrix[, c("mcid", "proxy")] <- 0
#  predictor_matrix[, c("race", "sex", "institution")] <- c(0, 0, 0, 0, 1)

## -----------------------------------------------------------------------------
# Data frame to illustrate optional predictors
opt_DT <- copy(DT)

# Factor to character
cols_to_edit <- c("race", "sex")
opt_DT[, (cols_to_edit) := lapply(.SD, as.character), .SDcols = cols_to_edit]

# Filter unknown race and sex
opt_DT <- opt_DT[sex != "Unknown"]
opt_DT <- opt_DT[race != "Other/Unknown"]

# Create origin variable
opt_DT[, origin := fcase(
  race != "International", "Domestic",
  race == "International", "International",
  default = NA_character_
)]
opt_DT <- opt_DT[!is.na(origin)]

# Create people variable
opt_DT[, people := paste(origin, sex)]
opt_DT[, people := as.factor(people)]
opt_DT[, c("race", "sex", "origin") := NULL]

# Display result
setcolorder(opt_DT, c("mcid", "people", "institution", "proxy"))
opt_DT

## -----------------------------------------------------------------------------
# Display unique people
sort(unique(opt_DT$people))

## -----------------------------------------------------------------------------
# Add all term variables by ID
cols_to_join <- term[, .(mcid, term)]
opt_DT <- cols_to_join[opt_DT, on = c("mcid")]

# Filter for first term
setkeyv(opt_DT, c("mcid", "term"))
opt_DT <- opt_DT[, .SD[1], by = c("mcid")]

# Create year variable
opt_DT[, year := substr(term, 1, 4)]
opt_DT[, year := as.factor(year)]
opt_DT[, term := NULL]

# Display result
setcolorder(opt_DT, c("mcid", "people", "institution", "year", "proxy"))
opt_DT

## -----------------------------------------------------------------------------
# Identify complete cases in predictor variables
rows_we_want <- complete.cases(opt_DT[, .(mcid, people, institution, year)])

# Filter for complete predictors
opt_DT <- opt_DT[rows_we_want]
opt_DT

## -----------------------------------------------------------------------------
# Imputation framework
opt_framework <- mice(opt_DT, maxit = 0)
opt_framework

## -----------------------------------------------------------------------------
# Imputation framework
opt_method_vector <- opt_framework[["method"]]
opt_method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
opt_predictor_matrix <- opt_framework[["predictorMatrix"]]
opt_predictor_matrix

## -----------------------------------------------------------------------------
N_impute <- sum(is.na(opt_DT$proxy))
N_fye <- nrow(opt_DT)

# Percent missing data
round(100 * N_impute / N_fye, 0)

## -----------------------------------------------------------------------------
# load DT_mids, don't have to repeatedly run mice()
load(here::here("R", "sysdata.rda"))

## -----------------------------------------------------------------------------
#  # Impute missing proxy data
#  DT_mids <- mice(
#    data = DT,
#    m = m_imputations,
#    maxit = 5, # default
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )

## -----------------------------------------------------------------------------
# output in console with printFlag = TRUE
# >  iter imp variable
# >   1   1  proxy
# >   1   2  proxy
# >   1   3  proxy
# >   1   4  proxy
# >   1   5  proxy
# >   ---
# >   5  33  proxy
# >   5  34  proxy
# >   5  35  proxy
# >   5  36  proxy
# >   5  37  proxy

## -----------------------------------------------------------------------------
# Revert to default random number generation
set.seed(NULL)

# Extract data from the mids object
DT <- mice::complete(DT_mids)

# Convert to data.table structure
setDT(DT)
DT <- DT[order(mcid)]
DT

## -----------------------------------------------------------------------------
# Subset the data
DT <- DT[, .(mcid, proxy)]
DT

## -----------------------------------------------------------------------------
# Convert factors
DT[, proxy := as.character(proxy)]
DT

## -----------------------------------------------------------------------------
# Order term data by ID and term
ordered_term <- term[, .(mcid, term, cip6)]
setorderv(ordered_term, cols = c("mcid", "term"))

# Obtain first term of all students
first_term <- ordered_term[, .SD[1], by = c("mcid")]

# Reduce to first term in FYE
first_term_fye_mcid <- first_term[cip6 == "140102", .(mcid)]

# Inner join to remove migrators from working data frame
DT <- first_term_fye_mcid[DT, on = c("mcid"), nomatch = NULL]
setkey(DT, NULL)
DT

## -----------------------------------------------------------------------------
# Demonstrate equivalence
same_content(DT, fye_proxy)

## -----------------------------------------------------------------------------
#  # Run manually if necessary for reproducibility
#  # Writing internal file sysdata.rda to save DT_mids
#  # Writing external file fye_proxy
#  
#  # Internal files
#  usethis::use_data(
#    DT_mids,
#    subset_student,
#    subset_course,
#    subset_term,
#    subset_degree,
#    internal  = TRUE,
#    overwrite = TRUE
#  )
#  
#  # External file
#  fye_proxy <- copy(DT)
#  usethis::use_data(fye_proxy, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Identify unique CIP codes in the proxy data
proxy_cips <- sort(unique(fye_proxy$proxy))
proxy_cips

## ---- echo=c(-1, -2)----------------------------------------------------------
op <- options()
options(datatable.print.topn = 13)
# Obtain the 4-digit program names corresponding to these codes
proxy_program_names <- filter_cip(keep_text = proxy_cips)
proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
proxy_program_names

## ---- echo=c(1:7)-------------------------------------------------------------
# Join these program names to the proxy data
proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]

# Count by program and order rows in descending magnitude
proxy_programs <- proxy_programs[, .N, by = c("program")]
setorderv(proxy_programs, order = -1, cols = c("N"))
proxy_programs

options(op)

## -----------------------------------------------------------------------------
x <- copy(proxy_programs)
x$nsf <- c("1", "2", "3", "", "6", "5", "4", "", "", "7", "", "", "")
setcolorder(x, c("program", "nsf", "N"))
setnames(x,
  old = c("program", "nsf"),
  new = c("Program", "NSF ranking")
)
x |>
  kableExtra::kbl(align = "lrr", caption = "Table 1: Frequency of FYE proxies using the practice data") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:2, color = "black", background = "white") |>
  kableExtra::row_spec(c(1, 2, 3, 5, 6, 7, 10))

## -----------------------------------------------------------------------------
# First term of all students
first_term

## -----------------------------------------------------------------------------
# Join proxies by ID (left join) to first-term data
start <- fye_proxy[first_term, .(mcid, cip6, proxy), on = c("mcid")]

# Distinguish FYE from direct matriculants
start[, matric := fcase(
  is.na(proxy), "direct",
  !is.na(proxy), "fye"
)]

# Create start variable
start[, start := fcase(
  matric == "fye", proxy,
  matric == "direct", cip6
)]

# Filter to retain case study program starters
join_labels <- copy(study_programs)
setnames(join_labels, old = "cip6", new = "start")
start <- join_labels[start, on = c("start")]
start <- start[!is.na(program)]

# Display result
start[order(matric, start)]

## -----------------------------------------------------------------------------
# Summarize
start <- start[, .N, by = c("matric", "program")]

# Transform to row-record form
start <- dcast(start, program ~ matric, value.var = "N")

# Compute FYE as fraction of total
start[, N_starters := direct + fye]
start[, fye_pct := round(100 * fye / N_starters, 1)]
start

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

