## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 7,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-003-")

## -----------------------------------------------------------------------------
library(midfieldr)
library(data.table)
library(ggplot2)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(study_observations)
DT

## -----------------------------------------------------------------------------
# Group and summarize
DT <- DT[, .N, by = c("bloc", "program", "race", "sex")]
DT

## -----------------------------------------------------------------------------
# Prepare to compute metric
DT <- dcast(DT, program + sex + race ~ bloc, value.var = "N", fill = 0)
DT

## -----------------------------------------------------------------------------
# Compute the metric
DT[, stickiness := round(100 * graduates / ever_enrolled, 1)]
setkey(DT, NULL)
DT

## -----------------------------------------------------------------------------
# Demonstrate equivalence
same_content(DT, study_results)

## -----------------------------------------------------------------------------
# Preserve anonymity
DT <- DT[graduates >= 10]

# Display the result
DT

## -----------------------------------------------------------------------------
# Filter by study design
DT <- DT[!race %chin% c("International", "Other/Unknown")]

# Display the result
DT

## -----------------------------------------------------------------------------
# Create a variable
DT[, people := paste(race, sex)]
DT[, c("race", "sex") := NULL]
setcolorder(DT, c("program", "people"))

# Display the result
DT

## -----------------------------------------------------------------------------
# Recode values for charts and tables
DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]

# Display the result
DT

## -----------------------------------------------------------------------------
# Convert categorical variables to factors
DT <- order_multiway(DT,
  quantity = "stickiness",
  categories = c("program", "people"),
  method = "percent",
  ratio_of = c("graduates", "ever_enrolled")
)

# Display the result
DT

## -----------------------------------------------------------------------------
ggplot(DT, aes(x = stickiness, y = program)) +
  facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
  geom_point() +
  labs(x = "Stickiness (%)", y = "")

## -----------------------------------------------------------------------------
ggplot(DT, aes(x = stickiness, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_point() +
  labs(x = "Stickiness (%)", y = "")

## -----------------------------------------------------------------------------
# Select the columns I want for the table
tbl <- DT[, .(program, people, stickiness)]

# Change factors to characters so rows/columns can be alphabetized
tbl[, people := as.character(people)]
tbl[, program := as.character(program)]

# Transform from block records to row records
tbl <- dcast(tbl, people ~ program, value.var = "stickiness")

# Edit one column header
setnames(tbl, old = "people", new = "People", skip_absent = TRUE)

## -----------------------------------------------------------------------------
tbl |>
  kableExtra::kbl(
    align = "lrrrr",
    caption = "Table 1: Program stickiness (%)"
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:5, color = "black", background = "white")

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

