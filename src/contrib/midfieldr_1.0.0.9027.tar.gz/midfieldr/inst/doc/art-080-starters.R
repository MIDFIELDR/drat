## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-080-starters-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# Starters
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, package = "midfielddata")

## -----------------------------------------------------------------------------
# Select required midfieldr variables
student <- select_required(student)
term <- select_required(term)

# View top few rows of the result
head(student, n = 3L)
head(term, n = 3L)

## -----------------------------------------------------------------------------
# Display prepared data
study_programs

## -----------------------------------------------------------------------------
# Display prepared data
fye_proxy

## -----------------------------------------------------------------------------
# Institutions with FYE
fye_inst <- term[cip6 == "140102", .(institution)]
fye_inst <- unique(fye_inst)

# Display the result
fye_inst[order(institution)]

## -----------------------------------------------------------------------------
# Drop all Engineering (CIP 14) that requires FYE
rows_to_drop <- term$institution %chin% fye_inst$institution & term$cip6 %like% "^14"
term_no_fye <- term[!rows_to_drop, .(mcid, institution, term, cip6, level)]

# Display the result
term_no_fye

## -----------------------------------------------------------------------------
# Extract column of unique IDs
mcid_no_fye <- term_no_fye[, .(mcid = unique(mcid))]

# Inner join with student to filter for matching IDs
student_no_fye <- mcid_no_fye[student, .(mcid, institution, race, sex), on = c("mcid"), nomatch = NULL]

# Display the result
student_no_fye[]

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

## -----------------------------------------------------------------------------
# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Left-outer join, term into IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Remove undecided/unspecified
DT <- DT[!cip6 %like% "999999"]

# Retain initial term data
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[which.min(term)], by = "mcid"]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Student 1. Procedure yields:
setkeyv(term, c("mcid", "term"))
DT[mcid == "MID25783178"]

## -----------------------------------------------------------------------------
# Student 1. First several terms observed CIPs:
term[mcid == "MID25783178", .(mcid, term, cip6)][1:7]

## -----------------------------------------------------------------------------
# Student 2. Procedure yields:
DT[mcid == "MID25783162"]

## -----------------------------------------------------------------------------
# Student 2. First four terms observed CIPs:
term[mcid == "MID25783162", .(mcid, term, cip6)][1:4]

## -----------------------------------------------------------------------------
# Copy and rename the variable for matching
join_labels <- copy(study_programs)

# Left-outer join, match by start
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, on = c("start")]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Keep the programs in the study
DT <- DT[!is.na(program)]
setcolorder(DT, c("mcid", "start"))

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Reset the assignment of student and term
student <- student_no_fye
term <- term_no_fye

# Display the results
student[]
term[]

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

## -----------------------------------------------------------------------------
# Left-outer join, term into IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]

# Remove undecided/unspecified
DT <- DT[!cip6 %like% "999999"]

# Retain initial term.
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[which.min(term)], by = "mcid"]
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Start is the CIP
DT <- DT[, .(mcid, start = cip6)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Student 1. Procedure yields:
DT[mcid == "MID25785305"]

## -----------------------------------------------------------------------------
# Student 1. First four terms observed CIPs:
setkeyv(term, c("mcid", "term"))
term[mcid == "MID25785305", .(mcid, term, cip6)][1:4]

## -----------------------------------------------------------------------------
# Student 2. Procedure yields:
DT[mcid == "MID25788338"]

## -----------------------------------------------------------------------------
# Student 2. First four terms observed CIPs:
term[mcid == "MID25788338", .(mcid, term, cip6)][1:4]

## -----------------------------------------------------------------------------
# Student 3. Procedure yields:
DT[mcid == "MID25929928"]

## -----------------------------------------------------------------------------
# First four terms observed CIPs:
term[mcid == "MID25929928", .(mcid, term, cip6)][1:4]

## -----------------------------------------------------------------------------
# New memory location for labels
join_labels <- copy(study_programs)

# Left-outer join, match by the CIPs in start
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, on = c("start")]

# Keep the programs in the study
DT <- DT[!is.na(program)]

# Retain required columns
DT <- DT[, .(mcid, start, program)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 17,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Load practice data
#  data(student, term, package = "midfielddata")
#  
#  # Prepare alternate data tables
#  fye_inst <- term[cip6 == "140102", .(institution)]
#  fye_inst <- unique(fye_inst)
#  rows_to_drop <- term$institution %chin% fye_inst$institution & term$cip6 %like% "^14"
#  term_no_fye <- term[!rows_to_drop, .(mcid, institution, term, cip6, level)]
#  mcid_no_fye <- term_no_fye[, .(mcid = unique(mcid))]
#  student_no_fye <- mcid_no_fye[student, .(mcid, institution, race, sex), on = c("mcid"), nomatch = NULL]
#  
#  # Starters with FYE
#  DT <- copy(term)
#  
#  # Filter for data sufficiency
#  DT <- add_timely_term(DT, term)
#  DT <- add_data_sufficiency(DT, term)
#  DT <- DT[data_sufficiency == "include"]
#  
#  # Filter for degree seeking
#  DT <- DT[, .(mcid)]
#  DT <- unique(DT)
#  DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
#  
#  # Isolate starting term
#  DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
#  DT <- DT[!cip6 %like% "999999"]
#  setorderv(DT, cols = c("mcid", "term"))
#  DT <- DT[, .SD[1], by = c("mcid")]
#  
#  # Create start variable
#  DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
#  DT[, start := fcase(
#    cip6 == "140102", proxy,
#    cip6 != "140102", cip6
#  )]
#  
#  # Closer look
#  setkeyv(term, c("mcid", "term"))
#  
#  DT[mcid == "MID25783178"]
#  term[mcid == "MID25783178", .(mcid, term, cip6)][1:7]
#  
#  DT[mcid == "MID25783162"]
#  term[mcid == "MID25783162", .(mcid, term, cip6)][1:4]
#  
#  # Filter by program
#  join_labels <- copy(study_programs)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, on = c("start")]
#  DT <- DT[!is.na(program)]
#  setcolorder(DT, c("mcid", "start"))
#  
#  # Starters without FYE
#  student <- student_no_fye
#  term <- term_no_fye
#  
#  # Filter for data sufficiency
#  DT <- copy(term)
#  DT <- add_timely_term(DT, term)
#  DT <- add_data_sufficiency(DT, term)
#  DT <- DT[data_sufficiency == "include"]
#  
#  # Filter for degree seeking
#  DT <- DT[, .(mcid)]
#  DT <- unique(DT)
#  DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
#  
#  # Isolate starting term
#  DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
#  DT <- DT[!cip6 %like% "999999"]
#  setorderv(DT, cols = c("mcid", "term"))
#  DT <- DT[, .SD[1], by = c("mcid")]
#  
#  # Create start variable
#  DT <- DT[, .(mcid, start = cip6)]
#  
#  # Closer look
#  setkeyv(term, c("mcid", "term"))
#  
#  DT[mcid == "MID25785305"]
#  term[mcid == "MID25785305", .(mcid, term, cip6)][1:4]
#  
#  DT[mcid == "MID25788338"]
#  term[mcid == "MID25788338", .(mcid, term, cip6)][1:4]
#  
#  DT[mcid == "MID25929928"]
#  term[mcid == "MID25929928", .(mcid, term, cip6)][1:4]
#  
#  # Filter by program
#  join_labels <- copy(study_programs)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, on = c("start")]
#  DT <- DT[!is.na(program)]
#  DT <- DT[, .(mcid, start, program)]

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

