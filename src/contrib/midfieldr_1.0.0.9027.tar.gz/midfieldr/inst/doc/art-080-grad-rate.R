## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-080-graduation-rate-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## ----echo = FALSE-------------------------------------------------------------
suppressPackageStartupMessages(library("data.table"))
DT <- wrapr::build_frame(
  "Item", "IPEDS", "MIDFIELD", "MIDFIELD notes" |
    "completion span:", "4, 6, or 8 years", "4, 6, or 8 years", "Typical usage is 6 years" |
    "students admitted in:", "Summer/Fall only", "any term", "" |
    "part-time students are:", "excluded", "included", "Timely completion same as full-time students" |
    "transfer students are:", "excluded", "included", "Timely completion span adjusted for level at entry" 
)

DT |>
  kableExtra::kbl(align = "llll") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::column_spec(1:2, color = "black", background = "white") |>
  kableExtra::row_spec(c(0), background = "#c7eae5")

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Printing options for data.table
options(
  datatable.print.nrows = 21,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load data sets from midfielddata
data(student, term, degree)

## -----------------------------------------------------------------------------
# Create a working data frame, IDs only
DT <- term[, .(mcid)]

# Minimize the dimension
DT <- unique(DT)

# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Obtain CIP codes and names
four_programs <- filter_search(
    cip, 
    keep_text = c("140102", "^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"), 
    select = c("cip6")
    )

# Assign custom program names
four_programs[, program := fcase(
  cip6 %chin% "140102", "FYE", 
  cip6 %like% "^1408", "CE",
  cip6 %like% "^1410", "EE",
  cip6 %like% "^1419", "ME",
  cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE" 
)]

# Display the result
four_programs[]

## -----------------------------------------------------------------------------
# Inner join for all terms for these IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid"), nomatch = NULL]

# Retain initial term
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = c("mcid")]
DT <- DT[, .(mcid, cip6)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
fye <- DT[cip6 == "140102"]
fye[]

fye <- fye_proxy[fye, .(mcid, proxy), on = c("mcid")]
fye[]

# rejoin
DT <- fye[DT, on = c("mcid")]
DT[]

# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
setnames(four_programs, old = "cip6", new = "start")
DT[]

DT <- four_programs[DT, .(mcid, program), on = c("start")]
DT[]


DT <- DT[!is.na(program)]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------
# Case study starters
study_starters

## -----------------------------------------------------------------------------
# Case study graduates
study_observations

## -----------------------------------------------------------------------------
# Create a working data frame
DT <- study_starters[, .(mcid, program)]

# Rename the program variable
setnames(DT, old = "program", new = "program_start")

# Create a group variable
DT[, group := "start"]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter for graduates only
grad <- study_observations[group == "grad", .(mcid, program, group)]

# Rename the program variable
setnames(grad, old = "program", new = "program_grad")

# Display the result
grad[]

## -----------------------------------------------------------------------------
join_cols <- DT[, .(mcid, program_start)]
grad <- join_cols[grad, on = "mcid"]

# Display the result
grad[]

## -----------------------------------------------------------------------------
grad <- grad[program_start == program_grad]

# Display the result
grad[]

## -----------------------------------------------------------------------------
# Drop an unnecessary variable 
grad[, program_start := NULL]

# Display the result
grad[]

## -----------------------------------------------------------------------------
# Rename the program variables to match before binding
setnames(DT, old = "program_start", new = "program")
setnames(grad, old = "program_grad", new = "program")

# Combine data tables
DT <- rbindlist(list(DT, grad))

# Display the result
DT[]

## -----------------------------------------------------------------------------
DT <- student[DT, .(mcid, program, group, race, sex), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Count by the grouping variables 
DT <- DT[, .N, by = c("group", "program", "race", "sex")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Transform to row-record form
DT <- dcast(DT, program + sex + race ~ group, value.var = "N", fill = 0)

# Display the result
DT[]

DT[, rate := round(100 * grad / start, 1)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Preserve anonymity
DT <- DT[grad >= 10]

# Display the result
DT[]

# Filter by study design
DT <- DT[!race %chin% c("International", "Other/Unknown")]

# Display the result
DT[]

DT[, people := paste(race, sex)]
DT[, c("race", "sex") := NULL]
setcolorder(DT, c("program", "people"))

# Display the result
DT[]

DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]

# Display the result
DT[]

# Convert categorical variables to factors
DT <- order_multiway(DT,
  quantity = "rate",
  categories = c("program", "people"),
  method = "percent",
  ratio_of = c("grad", "start")
)

# Display the result
DT[]

## ----grad-rate-people---------------------------------------------------------
ggplot(DT, aes(x = rate, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = program_rate), linetype = 2) +
  geom_point() +
  labs(x = "Graduation rate (%)", y = "") 

## -----------------------------------------------------------------------------
# Script

## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

