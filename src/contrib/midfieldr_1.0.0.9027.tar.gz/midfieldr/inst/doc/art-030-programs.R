## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-030-programs-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
library("midfieldr")
df <- filter_search(cip, "^41")
n41 <- nrow(df)
n4102 <- nrow(filter_search(df, "^4102"))
n4103 <- nrow(filter_search(df, "^4103"))
name41 <- unique(df[, cip2name])

df24 <- filter_search(cip, "^24")
n24 <- nrow(df24)
name24 <- unique(df24[, cip2name])

df51 <- filter_search(cip, "^51")
n51 <- nrow(df51)
name51 <- unique(df51[, cip2name])

df1313 <- filter_search(cip, "^1313")
n1313 <- nrow(df1313)
name1313 <- unique(df1313[, cip2name])

## -----------------------------------------------------------------------------
x <- filter_search(cip, "^41")
x[2:9, cip2name := "\U2003\U02193"]
x[c(4, 5, 7, 8), cip4name := "\U2003\U02193"]

x |>
  kableExtra::kbl(align = "rlrlrl", 
                  caption = "Table 1: CIP taxonomy") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
# Programs
# midfieldr vignette

# Packages
library("midfieldr")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 55,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# View cip
cip

## -----------------------------------------------------------------------------
# Names and class of the CIP variables
cip[, lapply(.SD, class)]

## -----------------------------------------------------------------------------
# 2-digit level
sort(unique(cip$cip2))

# 4-digit level
length(unique(cip$cip4))

# 6-digit level
length(unique(cip$cip6))

## -----------------------------------------------------------------------------
set.seed(20210613)

## -----------------------------------------------------------------------------
# 2-digit name sample
sample(cip[, cip2name], 10)

# 4-digit name sample
sample(cip[, cip4name], 10)

# 6-digit name sample
sample(cip[, cip6name], 10)

## -----------------------------------------------------------------------------
set.seed(NULL)

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- filter_search(dframe = cip, keep_text = c("engineering"))

# Required arguments in order, but not named
y <- filter_search(cip, c("engineering"))

# Dropping vector notation when one element only 
z <- filter_search(cip, "engineering")

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Filter basics
filter_search(cip, "engineering")

## -----------------------------------------------------------------------------
# Optional arguments drop_text and select
filter_search(cip,
  "engineering",
  drop_text = c("related", "technology", "technologies"),
  select = c("cip6", "cip6name")
)

## -----------------------------------------------------------------------------
#  # Example 1 filter using keywords
#  filter_search(cip, "civil")

## -----------------------------------------------------------------------------
filter_search(cip, "civil") |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 2. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
# First search
first_pass <- filter_search(cip, "civil")

# Refine the search
second_pass <- filter_search(first_pass, "engineering")

# Refine further
third_pass <- filter_search(second_pass, drop_text = "technology")

## -----------------------------------------------------------------------------
third_pass |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 3. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
filter_search(cip, "civil engineering", drop_text = "technology")

## -----------------------------------------------------------------------------
#  # Search on text
#  filter_search(cip, "german")

## -----------------------------------------------------------------------------
filter_search(cip, "german") |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 4. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
#  # Search on codes
#  filter_search(cip, c("050125", "160501"))

## -----------------------------------------------------------------------------
filter_search(cip, c("050125", "160501")) |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 5. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
# partial solution to exercise
pass01 <- filter_search(cip, "history")
pass02 <- filter_search(pass01, "^54")
cols_we_want <- c("cip6", "cip6name")
exercise_cip <- pass02[, ..cols_we_want]
exercise_cip

## -----------------------------------------------------------------------------
#  # example 3 filter using regular expressions
#  filter_search(cip, c("^1410", "^1419"))

## -----------------------------------------------------------------------------
filter_search(cip, c("^1410", "^1419")) |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 6. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
#  # Search on 2-digit code
#  filter_search(cip, "^54")

## -----------------------------------------------------------------------------
filter_search(cip, "^54") |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 7. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
#  # Search on vector of codes
#  codes_we_want <- c("^24", "^4102", "^450202")
#  filter_search(cip, codes_we_want)

## -----------------------------------------------------------------------------
codes_we_want <- c("^24", "^4102", "^450202")
filter_search(cip, codes_we_want) |>
  kableExtra::kbl(align = "rlrlrl", caption = "Table 8. Search results.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:6, color = "black", background = "white")

## -----------------------------------------------------------------------------
# Unsuccessful terms produce a message
sub_cip <- filter_search(cip, c("050125", "111111", "160501", "Bogus", "^55"))

# But the successful terms are returned
sub_cip

## -----------------------------------------------------------------------------
# Name and class of variables (columns) in cip
unlist(lapply(cip, FUN = class))

## -----------------------------------------------------------------------------
# Changing the number of rows to print
options(datatable.print.nrows = 15)

# Four engineering programs
four_programs <- filter_search(cip, c("^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"))

# Retain the needed columns
four_programs <- four_programs[, .(cip6, cip4name)]

# Examine the result
four_programs[]

## -----------------------------------------------------------------------------
# Assign a new column
four_programs[, program := NA_character_]

# Examine the result
four_programs[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? `%like%`

## -----------------------------------------------------------------------------
# Recode program using the 4-digit name
four_programs[cip4name %ilike% "electrical", program := "EE"]

# Examine the result
four_programs[]

## -----------------------------------------------------------------------------
# Recode program using the 4-digit code
four_programs[cip6 %like% "^1408", program := "CE"]

# Examine the result
four_programs[]

## -----------------------------------------------------------------------------
# Recode all program values
four_programs[, program := fcase(
  cip6 %like% "^1408", "CE",
  cip6 %like% "^1410", "EE",
  cip6 %like% "^1419", "ME",
  cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE"
)]

# Examine the result
four_programs[]

## ----echo = FALSE-------------------------------------------------------------
# exercise solution
exercise_program <- copy(exercise_cip)
exercise_program[, program := cip6name]
exercise_program[
  cip6name %ilike% "General",
  program := "General History"
]
exercise_program[
  cip6name %ilike% "Other",
  program := "General History"
]
exercise_program[
  cip6name %ilike% "Philosophy",
  program := "Sci/Tech History"
]
exercise_program[
  cip6name %ilike% "Public",
  program := "Public/Applied History"
]
exercise_program[
  cip6name %ilike% "United States",
  program := "US History"
]
exercise_program[, cip6name := NULL]
exercise_program[]

## -----------------------------------------------------------------------------
# Four engineering programs
case_study_programs <- filter_search(cip, c("^1408", "^1410", "^1419", "^1427", "^1435", "^1436", "^1437"))

# Recode the names
case_study_programs[, program := fcase(
  cip6 %like% "^1408", "CE",
  cip6 %like% "^1410", "EE",
  cip6 %like% "^1419", "ME",
  cip6 %chin% c("142701", "143501", "143601", "143701"), "ISE"
)]

# Retain required columns
case_study_programs <- case_study_programs[, .(cip6, program)]

# Examine the result
case_study_programs[]

## -----------------------------------------------------------------------------
# Verify built-in data
all.equal(case_study_programs, study_programs)

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

