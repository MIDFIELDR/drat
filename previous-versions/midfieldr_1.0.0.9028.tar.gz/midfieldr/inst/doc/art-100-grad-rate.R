## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-100-graduation-rate-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "80%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# data.table printout
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# accented text
accent <- function(text_string) {
  kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
library("data.table")
wrapr::build_frame(
  "Item", "IPEDS", "MIDFIELD", "MIDFIELD notes" |
    "completion span:", "4, 6, or 8 years", "4, 6, or 8 years", "Typical usage is 6 years" |
    "students admitted in:", "Summer/Fall only", "any term", "" |
    "part-time students are:", "excluded", "included", "Timely completion same as full-time students" |
    "transfer students are:", "excluded", "included", "Timely completion span adjusted for level at entry"
) |>
  kableExtra::kbl(align = "llll", caption = "Table 1: Comparing graduation rate definitions") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::column_spec(1:2, color = "black", background = "white") |>
  kableExtra::row_spec(c(0), background = "#c7eae5")

## -----------------------------------------------------------------------------
# midfieldr: Graduation rate

# Packages
library("midfieldr")
library("midfielddata")
library("data.table")
library("ggplot2")

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

## -----------------------------------------------------------------------------
# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
DT[]

## -----------------------------------------------------------------------------
baseline <- copy(DT)

## -----------------------------------------------------------------------------
# Reset the working data frame
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Isolate starting term
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
DT <- DT[!cip6 %like% "999999"]
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[which.min(term)], by = "mcid"]
DT <- DT[, .(mcid, cip6)]
DT <- unique(DT)

# Continue for starters with FYE
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]
DT <- DT[, .(mcid, start)]

# Filter by program on start
join_labels <- copy(study_programs)
join_labels <- join_labels[, .(program, start = cip6)]
DT <- join_labels[DT, on = c("start"), nomatch = NULL]
DT[, start := NULL]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid"))
starters <- copy(DT)
starters[]

## -----------------------------------------------------------------------------
# Reset the working data frame
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Gather graduates and their degree CIPs
DT <- add_timely_term(DT, term)
DT <- add_completion_status(DT, degree)
DT <- DT[completion_status == "timely"]
DT <- degree[DT, .(mcid, cip6), on = c("mcid")]

# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Starter-graduates
DT <- starters[DT, on = c("mcid", "program"), nomatch = NULL]

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid"))
graduates <- copy(DT)

## -----------------------------------------------------------------------------
# Same ID in different blocs
mcid_we_want <- "MID25783912"
starters[mcid == mcid_we_want]

graduates[mcid == mcid_we_want]

## -----------------------------------------------------------------------------
# Same ID in different blocs
mcid_we_want <- "MID25784893"
starters[mcid == mcid_we_want]

graduates[mcid == mcid_we_want]

degree[mcid == mcid_we_want, .(mcid, cip6)]

## -----------------------------------------------------------------------------
# Same ID in different blocs
mcid_we_want <- "MID25783162"
starters[mcid == mcid_we_want]

graduates[mcid == mcid_we_want]

degree[mcid == mcid_we_want, .(mcid, cip6)]

## -----------------------------------------------------------------------------
# For grouping by bloc
starters[, bloc := "starters"]
graduates[, bloc := "graduates"]

## -----------------------------------------------------------------------------
# Prepare for summarizing
DT <- rbindlist(list(starters, graduates))
DT[]

## -----------------------------------------------------------------------------
# Join race/ethnicity and sex
cols_we_want <- student[, .(mcid, race, sex)]
DT <- cols_we_want[DT, on = c("mcid")]
DT[]

## -----------------------------------------------------------------------------
options(datatable.print.topn = 7)

## -----------------------------------------------------------------------------
# Count observations by group
grouping_variables <- c("bloc", "program", "sex", "race")
DT <- DT[, .N, by = grouping_variables]
setorderv(DT, grouping_variables)
DT[]

## -----------------------------------------------------------------------------
# Prepare to compute metric
DT <- dcast(DT, program + sex + race ~ bloc, value.var = "N", fill = 0)
DT[]

## -----------------------------------------------------------------------------
# Compute metric
DT[, rate := round(100 * graduates / starters, 1)]
DT[]

## -----------------------------------------------------------------------------
options(datatable.print.topn = 3)

## -----------------------------------------------------------------------------
# Study design assumption
DT <- DT[!race %chin% c("International", "Other/Unknown")]
DT[]

## -----------------------------------------------------------------------------
# Preserve anonymity
N_threshold <- 5
DT <- DT[graduates >= N_threshold]
DT[]

## -----------------------------------------------------------------------------
# Create a combined category
DT[, people := paste(race, sex)]
DT[, `:=`(race = NULL, sex = NULL)]
setcolorder(DT, c("program", "people"))
DT[]

## -----------------------------------------------------------------------------
# Recode values for chart and table readability
DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]
DT[]

## -----------------------------------------------------------------------------
# Order the categories
DT <- order_multiway(DT,
  quantity   = "rate",
  categories = c("program", "people"),
  method     = "percent",
  ratio_of   = c("graduates", "starters")
)
DT[]

## ----fig2---------------------------------------------------------------------
ggplot(DT, aes(x = rate, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = program_rate), linetype = 2, linewidth = 0.5) +
  geom_point() +
  labs(x = "Graduation rate (%)", y = "") +
  scale_x_continuous(limits = c(20, 65))

## -----------------------------------------------------------------------------
options(datatable.print.topn = 10)

## -----------------------------------------------------------------------------
# Select variables and remove factors
display_table <- copy(DT)
display_table <- display_table[, .(program, people, rate)]
display_table[, people := as.character(people)]
display_table[, program := as.character(program)]

# Construct table
display_table <- dcast(display_table, people ~ program, value.var = "rate")
setnames(display_table,
  old = c("people"),
  new = c("People"),
  skip_absent = TRUE
)
display_table[]

## -----------------------------------------------------------------------------
knitr::kable(display_table,
  align = "lrrrr",
  caption = "Table 2: Graduation rates (%) of four Engineering majors."
)

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

