
2021-06-17  
RAL  

In writing the "defensive programming" unit tests for midfieldr, I used the packages:

- checkmate, to write the runtime assertions to check function arguments. These assertions are in the `function_name.R` files in the directory `./R`.  
- tinytest, to write the unit tests that check function arguments before the function executes. The test files are in the directory `./inst/tinytest`. 




