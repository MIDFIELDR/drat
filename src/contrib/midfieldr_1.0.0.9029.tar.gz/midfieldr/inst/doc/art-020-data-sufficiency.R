## ----child-common-setup-------------------------------------------------------
# code chunks
knitr::opts_chunk$set(fig.width = 7,
                      out.width = "100%",
                      collapse  = TRUE, 
                      comment   = "#>",
                      message   = FALSE, 
                      cache     = FALSE, 
                      error     = FALSE,
                      tidy      = FALSE, 
                      echo      = TRUE)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
    if (!is.numeric(x)) {
        x
    } else if (x >= 10000) {
        prettyNum(round(x, 2), big.mark = ",")
    } else {
        prettyNum(round(x, 2))
    }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

# Backup user options (load packages to capture default options)
suppressPackageStartupMessages(library(data.table))
backup_options <- options()

# Backup user random number seed
oldseed <- NULL
if (exists(".Random.seed")) oldseed <- .Random.seed

# data.table printout
options(datatable.print.nrows = 10,
        datatable.print.topn = 3,
        datatable.print.class = FALSE)

## -----------------------------------------------------------------------------
knitr::opts_chunk$set(fig.path = "../man/figures/art-020-")

## -----------------------------------------------------------------------------
library(midfieldr)
library(midfielddata)
library(data.table)

## -----------------------------------------------------------------------------
# Load data
data(term)

## -----------------------------------------------------------------------------
# Copy of source files with all variables
source_term <- copy(term)

# Select variables required by midfieldr functions
term <- select_required(source_term)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)
DT

## -----------------------------------------------------------------------------
# Retain the minimum number of columns
DT <- DT[, .(mcid, institution)]

## -----------------------------------------------------------------------------
# Filter for unique IDs
DT <- unique(DT)
DT

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- add_timely_term(dframe = DT, midfield_term = term)

# Required arguments in order, but not named
y <- add_timely_term(DT, term)

# Using the implicit default for the midfield_term argument
z <- add_timely_term(DT)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Add timely term column and supporting variables
DT <- add_timely_term(DT, term)
DT

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112785480"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3111860641"]

## -----------------------------------------------------------------------------
# A toy set of IDs
toy_mcid <- toy_student[, .(mcid)]

# Source data table names that differ from the defaults
toy_DT <- add_timely_term(dframe = toy_mcid, midfield_term = toy_term)

# Equivalently
toy_DT <- add_timely_term(toy_mcid, toy_term)
toy_DT

## -----------------------------------------------------------------------------
# Drop three columns
toy_DT <- toy_DT[, c("term_i", "level_i", "timely_term") := NULL]
toy_DT

## -----------------------------------------------------------------------------
# Demonstrate overwriting
toy_DT <- add_timely_term(toy_DT, toy_term)
toy_DT

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- add_data_sufficiency(dframe = DT, midfield_term = term)

# Required arguments in order, but not named
y <- add_data_sufficiency(DT, term)

# Using the implicit default for the midfield_term argument
z <- add_data_sufficiency(DT)

# Demonstrate equivalence
same_content(x, y)
same_content(x, z)

## -----------------------------------------------------------------------------
# Un-clutter the printout
DT <- DT[, .(mcid, institution, timely_term)]

# Add data sufficiency column and supporting variables
DT <- add_data_sufficiency(DT, term)
DT

## -----------------------------------------------------------------------------
# Find the closer look IDs

x <- copy(DT)
x[data_sufficiency == "exclude-lower"]



DT[mcid == "MCID3111142689"]


x <- add_timely_term(x)
x[adj_span == 4]

## -----------------------------------------------------------------------------
# Data range by institution
term[order(institution), .(min_term = min(term), max_term = max(term)), by = "institution"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112785480"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3111170322"]

## -----------------------------------------------------------------------------
# Display one student by ID
DT[mcid == "MCID3112056754"]

## -----------------------------------------------------------------------------
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency, output unique IDs
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include", .(mcid)]
DT <- unique(DT)

## -----------------------------------------------------------------------------
# Restore the user options (saved in common-setup.Rmd)
options(backup_options)

# Restore user random number seed if any
if (!is.null(oldseed)) {.Random.seed <- oldseed}

# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

