## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-004-case-study-students-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("midfielddata")
library("data.table")

# optional code to control data.table printing
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# load data tables from midfielddata
data(student, term)

## -----------------------------------------------------------------------------
# Loaded with midfieldr
study_program

## -----------------------------------------------------------------------------
# All terms for all students in the study programs
DT <- filter_match(term,
  match_to = study_program,
  by_col = "cip6",
  select = c("mcid", "institution", "cip6")
)

# Examine the result
DT

## -----------------------------------------------------------------------------
DT <- unique(DT)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Limit the study to degree-seeking students
DT <- filter_match(DT,
  match_to = student,
  by_col = "mcid"
)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Program name is a commonly used grouping variable
DT <- merge(DT, study_program, by = "cip6", all.x = TRUE)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Race/ethnicity and sex are commonly used grouping variables
DT <- add_race_sex(DT, midfield_student = student)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Timely completion term is required for determining data sufficiency
DT <- add_timely_term(DT, midfield_term = term)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Establish the criterion
DT <- add_data_sufficiency(DT, midfield_term = term)

# Examine the result
DT

## -----------------------------------------------------------------------------
# Apply the criterion
DT <- DT[data_sufficiency == TRUE]

# Examine the result
DT

## -----------------------------------------------------------------------------
# Optional step to order the rows
setcolorder(DT, c("mcid", "institution"))

## -----------------------------------------------------------------------------
study_student

## -----------------------------------------------------------------------------
all.equal(DT, study_student)

## ----eval = FALSE-------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("midfielddata")
#  library("data.table")
#  
#  # load data tables from midfielddata
#  data(student, term)
#  
#  # Gather students
#  DT <- filter_match(term,
#    match_to = study_program,
#    by_col = "cip6",
#    select = c("mcid", "institution", "cip6")
#  )
#  DT <- unique(DT)
#  DT <- filter_match(DT,
#    match_to = student,
#    by_col = "mcid"
#  )
#  
#  # Join grouping variables
#  DT <- merge(DT, study_program, by = "cip6", all.x = TRUE)
#  DT <- add_race_sex(DT, midfield_student = student)
#  
#  # Filter for data sufficiency
#  DT <- add_timely_term(DT, midfield_term = term)
#  DT <- add_data_sufficiency(DT, midfield_term = term)
#  DT <- DT[data_sufficiency == TRUE]
#  
#  # Save results
#  setcolorder(DT, c("mcid", "institution"))
#  fwrite(DT, file = "results/case_student.csv")

