## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = FALSE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
    fig.path = "../man/figures/art-010-data-sufficiency-", 
    fig.width = 6,
    fig.asp = 1 / 1.6,
    out.width = "70%",
    fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# set echo for example
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 15,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load data set from midfielddata
data(term)

# Create a working data frame
DT <- copy(term)
str(DT)

## -----------------------------------------------------------------------------
# Retain the minimum number of columns
DT <- DT[, .(mcid, cip6)]

## -----------------------------------------------------------------------------
DT <- unique(DT)
DT[]

# Count unique IDs
length(unique(DT$mcid))

## -----------------------------------------------------------------------------
# Display timely term and supporting variables 
add_timely_term(DT, midfield_term = term)

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named 
x <- add_timely_term(dframe = DT, midfield_term = term)

# Required arguments in order, but not named   
y <- add_timely_term(DT, term)

# Using the implicit default for the midfield_term argument
z <- add_timely_term(DT)

# Equality test between two data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
add_timely_term(toy_student[, .(mcid)], toy_term)

## -----------------------------------------------------------------------------
DT <- add_timely_term(DT, term)

