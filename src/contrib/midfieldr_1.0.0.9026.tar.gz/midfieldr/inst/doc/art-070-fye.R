## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-060-multiway-charts-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Only if creating your own FYE proxies
library("mice")

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Case study IDs of ever enrolled
study_mcid

## -----------------------------------------------------------------------------
study_program_labels

## -----------------------------------------------------------------------------
# Predicted starting programs for practice data
fye_proxy

## -----------------------------------------------------------------------------
# Load data from midfielddata
data(term)

# Display selected columns
term[, .(mcid, term, cip6)]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_mcid
#  ? study_program_labels
#  ? fye_proxy
#  ? term

## -----------------------------------------------------------------------------
# Create working data frame
DT <- copy(study_mcid)

# Left-outer join, term into IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Retain initial term
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Create an intermediate data set for later analysis
direct_start <- DT[cip6 != "140102", .(mcid, cip6)]

## -----------------------------------------------------------------------------
# Create an FYE subset of first-term students
first_term_fye_mcid <- DT[cip6 == "140102", .(mcid)]

# Display the result
first_term_fye_mcid[]

## -----------------------------------------------------------------------------
# Join FYE proxies to first-term-FYE subset
fye <- fye_proxy[first_term_fye_mcid, .(mcid, proxy), on = c("mcid")]

# Display the result
fye[]

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye[DT, .(mcid, cip6, proxy), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# New memory location for labels
join_labels <- copy(study_program_labels)

# Left-outer join, match by the CIPs in start
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, .(mcid, start, program), on = c("start")]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Keep the four programs only
DT <- DT[!is.na(program)]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Create an intermediate data set for later analysis
predicted_start <- copy(DT)

## -----------------------------------------------------------------------------
# Load data sets from midfielddata
data(student, term)

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? student
#  ? term

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? prep_fye_mice

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- prep_fye_mice(midfield_student = student, midfield_term = term)

# Required arguments in order, but not named
y <- prep_fye_mice(student, term)

# Using the implicit defaults
z <- prep_fye_mice()

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Create the working data frame
fye <- prep_fye_mice(student, term)

# Display the result
fye[]

## -----------------------------------------------------------------------------
# Number of students ever enrolled in an FYE program
length(unique(fye$mcid))

# Number of missing values to be imputed
sum(is.na(fye$cip6))

## -----------------------------------------------------------------------------
# Create an intermediate data set for later analysis
post_fye_start <- fye[, .(mcid, cip6)]
post_fye_start <- post_fye_start[!is.na(cip6)]

## -----------------------------------------------------------------------------
# Imputation framework
framework <- mice(fye, maxit = 0)

# Display the results
framework

## -----------------------------------------------------------------------------
# Imputation method
method_vector <- framework[["method"]]

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Manually assign the variable(s) being imputed
method_vector[c("cip6")] <- "polyreg"

# Manually assign the variable(s) not being imputed
method_vector[c("mcid", "institution", "race", "sex")] <- ""

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
predictor_matrix <- framework[["predictorMatrix"]]

# Display the results
predictor_matrix

## -----------------------------------------------------------------------------
# Predictor row for this example
predictor_matrix["cip6", ]

## -----------------------------------------------------------------------------
# Manually assign zero columns
predictor_matrix[, c("mcid", "cip6")] <- c(0, 0, 0, 0, 0)

# Manually assign predictor columns
predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)

# Display the result
predictor_matrix

## -----------------------------------------------------------------------------
# load the saved fye_mids to avoid running mice() repeatedly
load(here::here("R", "sysdata.rda"))

## -----------------------------------------------------------------------------
#  # imputation
#  fye_mids <- mice(
#    data = fye,
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )

## -----------------------------------------------------------------------------
# output in console with printFlag = TRUE
# >  iter imp variable
# >   1   1  cip6
# >   1   2  cip6
# >   1   3  cip6
# >   1   4  cip6
# >   1   5  cip6
# >   ---
# >   5   1  cip6
# >   5   2  cip6
# >   5   3  cip6
# >   5   4  cip6
# >   5   5  cip6

## -----------------------------------------------------------------------------
# Extract data from the mids object
fye <- mice::complete(fye_mids)

# Convert to data.table structure
setDT(fye)

# Display the result
fye <- fye[order(mcid)]
fye[]

## -----------------------------------------------------------------------------
detach("package:mice", unload = TRUE)
set.seed(NULL)

## -----------------------------------------------------------------------------
# Subset the data
fye <- fye[, .(mcid, cip6)]

# Display the result
fye

## -----------------------------------------------------------------------------
# Convert factors
fye[, cip6 := as.character(cip6)]

# Identify the results as FYE proxies
setnames(fye, old = "cip6", new = "proxy")

# Display the result
fye

## -----------------------------------------------------------------------------
# fye_proxy <- copy(fye)
# usethis::use_data(fye_proxy, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Verify that result matches the built-in data set
all.equal(fye, fye_proxy)

## -----------------------------------------------------------------------------
#  # Write data to file
#  fwrite(fye, file = "data/my_fye_proxy.csv")

## -----------------------------------------------------------------------------
# Identify unique CIP codes in the proxy data
proxy_cips <- sort(unique(fye_proxy$proxy))

# Display the results
proxy_cips

## -----------------------------------------------------------------------------
# Obtain the 4-digit program names corresponding to these codes
proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
proxy_program_names[]

## -----------------------------------------------------------------------------
# Join these program names to the proxy data
proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]

# Count by program and order rows in descending magnitude
proxy_programs <- proxy_programs[, .N, by = c("program")]
setorderv(proxy_programs, order = -1, cols = c("N"))

# Display the result
proxy_programs[]

## -----------------------------------------------------------------------------
# Combine Electrical and Computer Engineering
new_row <- data.table(
  program = "Electrical/Computer Engineering",
  N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
)

# New location in memory
rev_proxy_programs <- copy(proxy_programs)

# Drop the separate Electrical and Computer rows
rev_proxy_programs <- rev_proxy_programs[!program %ilike% "Electrical|Computer"]

# Bind the new row and order
rev_proxy_programs <- rbindlist(list(rev_proxy_programs, new_row))
setorderv(rev_proxy_programs, c("N"), -1)

# Display the result
rev_proxy_programs[1:6]

## -----------------------------------------------------------------------------
# Join the program abbreviations
direct <- study_program_labels[direct_start, .(cip6, program), on = "cip6"]

# Retain the case study programs
direct <- direct[!is.na(program)]

# Count by program
direct <- direct[, .(direct = .N), by = "program"]

# Display the result
direct[]

## -----------------------------------------------------------------------------
# Inner join between post-FYE and first-term FYE IDs
post_fye <- first_term_fye_mcid[post_fye_start, .(mcid, cip6), on = c("mcid"), nomatch = NULL]

# Repeat the program abbreviation and filter steps
post_fye <- study_program_labels[post_fye, .(mcid, cip6, program), on = c("cip6")]
post_fye <- post_fye[!is.na(program)]
post_fye <- post_fye[, .(add_post_fye = .N), by = "program"]
post_fye[]

## -----------------------------------------------------------------------------
# Join the two results
DT <- merge(direct, post_fye, by = "program", all.x = TRUE)

# Add the direct admissions to the post-FYE starters
DT[, add_post_fye := add_post_fye + direct]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Count by program
predicted <- predicted_start[, .(add_imputed = .N), by = "program"]

# Join
DT <- merge(DT, predicted, by = "program", all.x = TRUE)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Fraction of starters from FYE
DT[, pct_fye := round(100 * (add_imputed - direct) / add_imputed, 1)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Only if creating your own FYE proxies
#  library("mice")
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 17,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Using prepared FYE proxies
#  data(term)
#  
#  # Start with IDs
#  DT <- copy(study_mcid)
#  DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
#  setorderv(DT, cols = c("mcid", "term"))
#  DT <- DT[, .SD[1], by = c("mcid")]
#  direct_start <- DT[cip6 != "140102", .(mcid, cip6)]
#  
#  # Process the proxies
#  first_term_fye_mcid <- DT[cip6 == "140102", .(mcid)]
#  fye <- fye_proxy[first_term_fye_mcid, .(mcid, proxy), on = c("mcid")]
#  DT <- fye[DT, .(mcid, cip6, proxy), on = c("mcid")]
#  
#  # Identify starters
#  DT[, start := fcase(
#    cip6 == "140102", proxy,
#    cip6 != "140102", cip6
#  )]
#  join_labels <- copy(study_program_labels)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, .(mcid, start, program), on = c("start")]
#  DT <- DT[!is.na(program)]
#  predicted_start <- copy(DT)
#  
#  # Creating FYE proxies
#  data(student, term)
#  
#  # prep_fye_mice()
#  fye <- prep_fye_mice(student, term)
#  post_fye_start <- fye[, .(mcid, cip6)]
#  post_fye_start <- post_fye_start[!is.na(cip6)]
#  
#  # mice() method
#  framework <- mice(fye, maxit = 0)
#  method_vector <- framework[["method"]]
#  method_vector[c("cip6")] <- "polyreg"
#  method_vector[c("mcid", "institution", "race", "sex")] <- ""
#  
#  # mice() predictor
#  predictor_matrix <- framework[["predictorMatrix"]]
#  predictor_matrix[, c("mcid", "cip6")] <- c(0, 0, 0, 0, 0)
#  predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)
#  
#  # mice()
#  fye_mids <- mice(
#    data = fye,
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )
#  fye <- mice::complete(fye_mids)
#  setDT(fye)
#  detach("package:mice", unload = TRUE)
#  set.seed(NULL)
#  
#  # Post-processing
#  fye <- fye[, .(mcid, cip6)]
#  fye[, cip6 := as.character(cip6)]
#  setnames(fye, old = "cip6", new = "proxy")
#  fwrite(fye, file = "data/my_fye_proxy.csv")
#  
#  # Summarizing the FYE proxies
#  proxy_cips <- sort(unique(fye_proxy$proxy))
#  proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
#  proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
#  proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]
#  proxy_programs <- proxy_programs[, .N, by = c("program")]
#  setorderv(proxy_programs, order = -1, cols = c("N"))
#  
#  # Compare to NSF report
#  new_row <- data.table(
#    program = "Electrical/Computer Engineering",
#    N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
#  )
#  rev_proxy_programs <- copy(proxy_programs)
#  rev_proxy_programs <- rev_proxy_programs[!program %ilike% "Electrical|Computer"]
#  rev_proxy_programs <- rbindlist(list(rev_proxy_programs, new_row))
#  setorderv(rev_proxy_programs, c("N"), -1)
#  
#  # Quantifying starter miscounts
#  direct <- study_program_labels[direct_start, .(cip6, program), on = "cip6"]
#  direct <- direct[!is.na(program)]
#  direct <- direct[, .(direct = .N), by = "program"]
#  post_fye <- first_term_fye_mcid[post_fye_start, .(mcid, cip6), on = c("mcid"), nomatch = NULL]
#  post_fye <- study_program_labels[post_fye, .(mcid, cip6, program), on = c("cip6")]
#  post_fye <- post_fye[!is.na(program)]
#  post_fye <- post_fye[, .(add_post_fye = .N), by = "program"]
#  predicted <- predicted_start[, .(add_imputed = .N), by = "program"]
#  
#  DT <- merge(direct, post_fye, by = "program", all.x = TRUE)
#  DT[, add_post_fye := add_post_fye + direct]
#  DT <- merge(DT, predicted, by = "program", all.x = TRUE)
#  DT[, pct_fye := round(100 * (add_imputed - direct) / add_imputed, 1)]

