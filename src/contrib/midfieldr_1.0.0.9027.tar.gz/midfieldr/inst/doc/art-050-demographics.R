## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-050-demographics-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# Programs
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Printing options for data.table
options(
  datatable.print.nrows = 15,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Display prepared data
study_mcid

## -----------------------------------------------------------------------------
# Optional. Set aside the source files in case they are needed
source_student <- copy(student)
source_term    <- copy(term)
source_degree  <- copy(degree)

# Work with required midfieldr variables only
student <- select_required(source_student)
term    <- select_required(source_term)
degree  <- select_required(source_degree)

# View top few rows of the result
head(student, n = 3L)

head(term, n = 3L)

head(degree, n = 3L)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(study_mcid)

# Display results
DT[]

## -----------------------------------------------------------------------------
# Subset of student data frame to join
cols_to_join <- student[, .(mcid, race, sex)]
merge(DT, cols_to_join, by = c("mcid"), all.x = TRUE)

## -----------------------------------------------------------------------------
merge(DT, student[, .(mcid, race, sex)], by = c("mcid"), all.x = TRUE)

## -----------------------------------------------------------------------------
# Fresh start
DT <- copy(study_mcid)

# Left-outer join student to DT
DT <- student[DT, .(mcid, race, sex), on = c("mcid")]

# Display results
DT[]

## -----------------------------------------------------------------------------
# Fresh start
DT <- copy(study_mcid)
x <- merge(DT, student[, .(mcid, race, sex)], by = c("mcid"), all.x = TRUE)
setkey(x, NULL)
y <- student[DT, .(mcid, race, sex), on = c("mcid")]
all.equal(x, y)

## -----------------------------------------------------------------------------
# What we want
x <- student[DT, .(mcid, race, sex), on = c("mcid")]

# Not what we want
y <- DT[student, .(mcid, race, sex), on = c("mcid")]

# Equal?
all.equal(x, y)

# Compare N rows
nrow(x)

nrow(y)

## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_student)

## -----------------------------------------------------------------------------
# Fresh start
DT <- copy(study_mcid)

# Add variables from student to DT
source_student[DT, .(mcid, transfer, hours_transfer), on = c("mcid")]

## -----------------------------------------------------------------------------
# Add variables from student to DT
source_student[DT, .(mcid, sat_math, sat_verbal), on = c("mcid")]

## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_term)

## -----------------------------------------------------------------------------
# Fresh start
DT <- copy(study_mcid)

# Add variables from term to DT
DT <- source_term[DT, .(mcid, institution, term, hours_term, gpa_term), on = c("mcid")]
setkeyv(DT, c("mcid", "term"))

# Display results
DT[]

## -----------------------------------------------------------------------------

options(datatable.print.nrows = 20)
setkeyv(source_term, c("mcid", "term"))

source_term[mcid == "MID25988779"][1:5]

## -----------------------------------------------------------------------------
source_term[mcid == "MID26292075"][1:5]

## -----------------------------------------------------------------------------
source_term[mcid == "MID26437765"][1:5]

## -----------------------------------------------------------------------------



DT[duplicated(DT)][institution == "Institution G"]



## -----------------------------------------------------------------------------
# Variables in the practice data set
names(source_degree)

## -----------------------------------------------------------------------------
# Add variables from degree to DT
source_degree[DT, .(mcid, term_degree, cip6), on = c("mcid")]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 15,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Load data sets from midfielddata
#  data(student, term, degree, package = "midfielddata")
#  
#  # Using merge
#  DT <- copy(study_mcid)
#  cols_to_join <- student[, .(mcid, race, sex)]
#  merge(DT, cols_to_join, by = c("mcid"), all.x = TRUE)
#  merge(DT, student[, .(mcid, race, sex)], by = c("mcid"), all.x = TRUE)
#  
#  # Using Y[X, j]
#  DT <- copy(study_mcid)
#  student[DT, .(mcid, race, sex), on = c("mcid")]
#  
#  # Compare
#  x <- merge(DT, student[, .(mcid, race, sex)], by = c("mcid"), all.x = TRUE)
#  setkey(x, NULL)
#  y <- student[DT, .(mcid, race, sex), on = c("mcid")]
#  all.equal(x, y)
#  
#  # Order matters
#  x <- student[DT, .(mcid, race, sex), on = c("mcid")]
#  y <- DT[student, .(mcid, race, sex), on = c("mcid")]
#  all.equal(x, y)
#  nrow(x)
#  nrow(y)
#  
#  # Columns from student
#  names(student)
#  DT <- copy(study_mcid)
#  student[DT, .(mcid, transfer, hours_transfer), on = c("mcid")]
#  student[DT, .(mcid, sat_math, sat_verbal), on = c("mcid")]
#  
#  # Columns from term
#  names(term)
#  DT <- copy(study_mcid)
#  unique(term[DT, .(mcid, institution), on = c("mcid")])
#  unique(term[DT, .(mcid, cip6), on = c("mcid")])
#  
#  # Columns from degree
#  names(degree)
#  degree[DT, .(mcid, term_degree, cip6), on = c("mcid")]

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

