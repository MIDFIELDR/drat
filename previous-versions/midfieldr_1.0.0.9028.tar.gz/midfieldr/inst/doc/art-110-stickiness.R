## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-110-stickiness-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "80%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# data.table printout
options(
  datatable.print.nrows = 6,
  datatable.print.topn = 3,
  datatable.print.class = TRUE
)

# accented text
accent <- function(text_string) {
  kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# midfieldr: Stickiness

# Packages
library("midfieldr")
library("midfielddata")
library("data.table")
library("ggplot2")

## -----------------------------------------------------------------------------
# Load practice data
data(student, term, degree, package = "midfielddata")

## -----------------------------------------------------------------------------
# Optional. Copy of source files with all variables
source_student <- copy(student)
source_term <- copy(term)
source_degree <- copy(degree)

# Optional. Select variables required by midfieldr functions
student <- select_required(source_student)
term <- select_required(source_term)
degree <- select_required(source_degree)

## -----------------------------------------------------------------------------
# Working data frame
DT <- copy(term)

## -----------------------------------------------------------------------------
# Filter for data sufficiency
DT <- add_timely_term(DT, term)
DT <- add_data_sufficiency(DT, term)
DT <- DT[data_sufficiency == "include"]

## -----------------------------------------------------------------------------
# Filter for degree seeking
DT <- DT[, .(mcid)]
DT <- unique(DT)
DT <- student[DT, .(mcid), on = c("mcid"), nomatch = NULL]
DT[]

## -----------------------------------------------------------------------------
baseline <- copy(DT)

## -----------------------------------------------------------------------------
# Reset the working data frame
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Ever-enrolled bloc
DT <- term[DT, .(mcid, cip6), on = c("mcid")]
DT <- unique(DT)

# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid"))
ever_enrolled <- copy(DT)
ever_enrolled[]

## -----------------------------------------------------------------------------
# Reset the working data frame
DT <- copy(baseline)

## -----------------------------------------------------------------------------
# Gather graduates and their degree CIPs
DT <- add_timely_term(DT, term)
DT <- add_completion_status(DT, degree)
DT <- DT[completion_status == "timely"]
DT <- degree[DT, .(mcid, cip6), on = c("mcid")]

# Filter by program
DT <- study_programs[DT, on = c("cip6"), nomatch = NULL]
DT[, cip6 := NULL]
DT <- unique(DT)
DT[]

## -----------------------------------------------------------------------------
# Prepare for joining
setcolorder(DT, c("mcid"))
graduates <- copy(DT)
graduates[]

## -----------------------------------------------------------------------------
# For grouping by bloc
ever_enrolled[, bloc := "ever_enrolled"]
graduates[, bloc := "graduates"]

## -----------------------------------------------------------------------------
# Prepare for summarizing
DT <- rbindlist(list(ever_enrolled, graduates))
DT[]

## -----------------------------------------------------------------------------
# Join race/ethnicity and sex
cols_we_want <- student[, .(mcid, race, sex)]
DT <- cols_we_want[DT, on = c("mcid")]
DT[]

## -----------------------------------------------------------------------------
options(datatable.print.topn = 7)

## -----------------------------------------------------------------------------
# Count observations by group
grouping_variables <- c("bloc", "program", "sex", "race")
DT <- DT[, .N, by = grouping_variables]
setorderv(DT, grouping_variables)
DT[]

## -----------------------------------------------------------------------------
# Prepare to compute metric
DT <- dcast(DT, program + sex + race ~ bloc, value.var = "N", fill = 0)
DT[]

## -----------------------------------------------------------------------------
# Compute metric
DT[, stickiness := round(100 * graduates / ever_enrolled, 1)]
DT[]

## -----------------------------------------------------------------------------
options(datatable.print.topn = 3)

## -----------------------------------------------------------------------------
# Study design assumption
DT <- DT[!race %chin% c("International", "Other/Unknown")]
DT[]

## -----------------------------------------------------------------------------
# Preserve anonymity
N_threshold <- 5
DT <- DT[graduates >= N_threshold]
DT[]

## -----------------------------------------------------------------------------
# Create a combined category
DT[, people := paste(race, sex)]
DT[, `:=`(race = NULL, sex = NULL)]
setcolorder(DT, c("program", "people"))
DT[]

## -----------------------------------------------------------------------------
# Recode values for chart and table readability
DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]
DT[]

## -----------------------------------------------------------------------------
# Order the categories
DT <- order_multiway(DT,
  quantity   = "stickiness",
  categories = c("program", "people"),
  method     = "percent",
  ratio_of   = c("graduates", "ever_enrolled")
)
DT[]

## ----fig2---------------------------------------------------------------------
ggplot(DT, aes(x = stickiness, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = program_stickiness), linetype = 2, linewidth = 0.5) +
  geom_point() +
  labs(x = "Stickiness (%)", y = "") +
  scale_x_continuous(limits = c(20, 65))

## -----------------------------------------------------------------------------
options(datatable.print.topn = 10)

## -----------------------------------------------------------------------------
# Select variables and remove factors
display_table <- copy(DT)
display_table <- display_table[, .(program, people, stickiness)]
display_table[, people := as.character(people)]
display_table[, program := as.character(program)]

# Construct table
display_table <- dcast(display_table, people ~ program, value.var = "stickiness")
setnames(display_table,
  old = c("people"),
  new = c("People"),
  skip_absent = TRUE
)
display_table[]

## -----------------------------------------------------------------------------
knitr::kable(display_table,
  align = "lrrrr",
  caption = "Table 2: Stickiness (%) of four Engineering majors."
)

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

