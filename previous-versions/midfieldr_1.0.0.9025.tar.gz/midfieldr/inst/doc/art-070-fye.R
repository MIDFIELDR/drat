## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-060-multiway-charts-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? fye_predicted_start

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? preprocess_fye()

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Only if performing your own imputation
library("mice")

# Printing options for data.table
options(
  datatable.print.nrows = 10,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# View the prepared predictions
fye_predicted_start

## -----------------------------------------------------------------------------
# Load two data tables
data(student, term)

## -----------------------------------------------------------------------------
# Case study program codes and labels
study_program_labels

## -----------------------------------------------------------------------------
# Case study ever enrolled IDs
study_mcid

## -----------------------------------------------------------------------------
#  
#  

