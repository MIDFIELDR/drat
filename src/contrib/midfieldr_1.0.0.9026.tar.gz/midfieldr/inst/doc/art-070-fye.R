## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-070-fye-programs-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))

# Only if creating your own FYE proxies
library("mice")

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
study_mcid

## -----------------------------------------------------------------------------
study_programs

## -----------------------------------------------------------------------------
fye_proxy

## -----------------------------------------------------------------------------
# Load data from midfielddata
data(term)

# Display selected columns
term[, .(mcid, term, cip6)]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_mcid
#  ? study_programs
#  ? fye_proxy
#  ? term

## -----------------------------------------------------------------------------
# Create working data frame
DT <- copy(study_mcid)

# Left-outer join, term into IDs
DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Retain initial term
setorderv(DT, cols = c("mcid", "term"))
DT <- DT[, .SD[1], by = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Create an intermediate data set for later analysis
direct_start <- DT[cip6 != "140102", .(mcid, cip6)]

# Join the program abbreviations
direct_start <- study_programs[direct_start, .(cip6, program), on = "cip6"]

# Retain the case study programs
direct_start <- direct_start[!is.na(program)]
setorderv(direct_start, c("program"))

# Display the result
direct_start

## -----------------------------------------------------------------------------
# Join the proxies to the working data frame
DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Combine all starting CIPs
DT[, start := fcase(
  cip6 == "140102", proxy,
  cip6 != "140102", cip6
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# New memory location for labels
join_labels <- copy(study_programs)

# Left-outer join, match by the CIPs in start
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, .(mcid, start, program), on = c("start")]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
# Keep the four programs only
DT <- DT[!is.na(program)]

# Display the result
DT[order(program)]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_starters

## -----------------------------------------------------------------------------
# Verify results
all.equal(DT, study_starters)

## -----------------------------------------------------------------------------
#  # This is where the data set is created.
#  
#  # study_starters <- copy(DT)
#  # usethis::use_data(study_starters, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Load data sets from midfielddata
data(student, term)

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? student
#  ? term

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? prep_fye_mice

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- prep_fye_mice(midfield_student = student, midfield_term = term)

# Required arguments in order, but not named
y <- prep_fye_mice(student, term)

# Using the implicit defaults
z <- prep_fye_mice()

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Create the working data frame
fye <- prep_fye_mice(student, term)

# Display the result
fye[]

## -----------------------------------------------------------------------------
# Number of students ever enrolled in an FYE program
(ever_FYE <- length(unique(fye$mcid)))

# Count number of CIPs to be imputed
logical_col <- is.na(fye$proxy)
(to_impute <- sum(logical_col))

# Number of imputed as percent of total
round(100 * to_impute / ever_FYE, 1)

## -----------------------------------------------------------------------------
# Imputation framework
framework <- mice(fye, maxit = 0)

# Display the results
framework

## -----------------------------------------------------------------------------
# Imputation method
method_vector <- framework[["method"]]

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Manually assign the variable(s) being imputed
method_vector[c("proxy")] <- "polyreg"

# Manually assign the variable(s) not being imputed
method_vector[c("mcid", "institution", "race", "sex")] <- ""

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
predictor_matrix <- framework[["predictorMatrix"]]

# Display the results
predictor_matrix

## -----------------------------------------------------------------------------
# Predictor row for this example
predictor_matrix["proxy", ]

## -----------------------------------------------------------------------------
# Manually assign zero columns
predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)

# Manually assign predictor columns
predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)

# Display the result
predictor_matrix

## -----------------------------------------------------------------------------
# load the saved fye_mids to avoid running mice() repeatedly
load(here::here("R", "sysdata.rda"))

## -----------------------------------------------------------------------------
#  # imputation
#  fye_mids <- mice(
#    data = fye,
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )

## -----------------------------------------------------------------------------
# output in console with printFlag = TRUE
# >  iter imp variable
# >   1   1  proxy
# >   1   2  proxy
# >   1   3  proxy
# >   1   4  proxy
# >   1   5  proxy
# >   ---
# >   5   1  proxy
# >   5   2  proxy
# >   5   3  proxy
# >   5   4  proxy
# >   5   5  proxy

## -----------------------------------------------------------------------------
# Revert to default random number generation
set.seed(NULL)

# Extract data from the mids object
fye <- mice::complete(fye_mids)

# Convert to data.table structure
setDT(fye)

# Display the result
fye <- fye[order(mcid)]
fye[]

## -----------------------------------------------------------------------------
# Subset the data
fye <- fye[, .(mcid, proxy)]

# Display the result
fye

## -----------------------------------------------------------------------------
# Convert factors
fye[, proxy := as.character(proxy)]

# Display the result
fye

## -----------------------------------------------------------------------------
# Obtain first term of all students in term data
all_start <- term[, .(mcid, term, cip6)]
setorderv(all_start, cols = c("mcid", "term"))
all_start <- all_start[, .SD[1], by = c("mcid")]

# Subset for FYE only
fye_start <- all_start[cip6 == "140102", .(mcid)]
fye_start

# Inner join to retain the FYE starters
fye <- fye_start[fye, .(mcid, proxy), on = c("mcid"), nomatch = NULL]

# Display the result
fye

## -----------------------------------------------------------------------------
# fye_proxy <- copy(fye)
# usethis::use_data(fye_proxy, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Verify that result matches the built-in data set
all.equal(fye, fye_proxy)

## -----------------------------------------------------------------------------
# Display the data set
direct_start[]

## -----------------------------------------------------------------------------
# Count by program
direct <- direct_start[, .(direct_start = .N), by = "program"]

# Display the result
direct[]

## -----------------------------------------------------------------------------
# Display the data set
study_starters[]

## -----------------------------------------------------------------------------
# Count by program
predicted <- study_starters[, .(all_start = .N), by = "program"]

# Display the result
predicted[]

## -----------------------------------------------------------------------------
# Join
starter_subsets <- merge(direct, predicted, by = "program", all.x = TRUE)

# Display the result
starter_subsets[]

## -----------------------------------------------------------------------------
# FYE percentage of all starters
starter_subsets[, FYE_pct := round(100 * (all_start - direct_start) / all_start, 1)]

# Display the result
starter_subsets[]

## -----------------------------------------------------------------------------
# Identify unique CIP codes in the proxy data
proxy_cips <- sort(unique(fye_proxy$proxy))

# Display the results
proxy_cips

## -----------------------------------------------------------------------------
# Obtain the 4-digit program names corresponding to these codes
proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
proxy_program_names[]

## -----------------------------------------------------------------------------
# Join these program names to the proxy data
proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]

# Count by program and order rows in descending magnitude
proxy_programs <- proxy_programs[, .N, by = c("program")]
setorderv(proxy_programs, order = -1, cols = c("N"))

# Display the result
proxy_programs[]

## -----------------------------------------------------------------------------
# Combine Electrical and Computer Engineering
new_row <- data.table(
  program = "Electrical/Computer Engineering",
  N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
)

# New location in memory
rev_proxy <- copy(proxy_programs)

# Drop the separate Electrical and Computer rows
rev_proxy <- rev_proxy[!program %ilike% "Electrical|Computer"]

# Bind the new row and order
rev_proxy <- rbindlist(list(rev_proxy, new_row))
setorderv(rev_proxy, c("N"), -1)

# Display the top 6 rows
rev_proxy[1:6]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  
#  # Only if creating your own FYE proxies
#  library("mice")
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 17,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Using FYE proxies
#  data(term)
#  
#  # Obtain first-term records
#  DT <- copy(study_mcid)
#  DT <- term[DT, .(mcid, term, cip6), on = c("mcid")]
#  setorderv(DT, cols = c("mcid", "term"))
#  DT <- DT[, .SD[1], by = c("mcid")]
#  
#  # Data set-aside
#  direct_start <- DT[cip6 != "140102", .(mcid, cip6)]
#  direct_start <- study_programs[direct_start, .(cip6, program), on = "cip6"]
#  direct_start <- direct_start[!is.na(program)]
#  setorderv(direct_start, c("program"))
#  
#  # Identify starters
#  DT <- fye_proxy[DT, .(mcid, cip6, proxy), on = c("mcid")]
#  DT[, start := fcase(
#    cip6 == "140102", proxy,
#    cip6 != "140102", cip6
#  )]
#  join_labels <- copy(study_programs)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, .(mcid, start, program), on = c("start")]
#  DT <- DT[!is.na(program)]
#  
#  # Creating FYE proxies
#  data(student, term)
#  
#  # prep_fye_mice()
#  fye <- prep_fye_mice(student, term)
#  
#  # mice() method
#  framework <- mice(fye, maxit = 0)
#  method_vector <- framework[["method"]]
#  method_vector[c("proxy")] <- "polyreg"
#  method_vector[c("mcid", "institution", "race", "sex")] <- ""
#  
#  # mice() predictor
#  predictor_matrix <- framework[["predictorMatrix"]]
#  predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)
#  predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)
#  
#  # mice()
#  fye_mids <- mice(
#    data = fye,
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )
#  set.seed(NULL)
#  fye <- mice::complete(fye_mids)
#  setDT(fye)
#  
#  # Post-processing
#  fye <- fye[, .(mcid, proxy)]
#  fye[, proxy := as.character(proxy)]
#  all_start <- term[, .(mcid, term, cip6)]
#  setorderv(all_start, cols = c("mcid", "term"))
#  all_start <- all_start[, .SD[1], by = c("mcid")]
#  fye_start <- all_start[cip6 == "140102", .(mcid)]
#  fye <- fye_start[fye, .(mcid, proxy), on = c("mcid"), nomatch = NULL]
#  
#  # Quantifying starter miscounts
#  direct <- direct_start[, .(direct_start = .N), by = "program"]
#  predicted <- study_starters[, .(all_start = .N), by = "program"]
#  starter_subsets <- merge(direct, predicted, by = "program", all.x = TRUE)
#  starter_subsets[, FYE_pct := round(100 * (all_start - direct_start) / all_start, 1)]
#  
#  # Credibility of the proxies
#  proxy_cips <- sort(unique(fye_proxy$proxy))
#  proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
#  proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
#  proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]
#  proxy_programs <- proxy_programs[, .N, by = c("program")]
#  setorderv(proxy_programs, order = -1, cols = c("N"))
#  
#  # Compare to NSF report
#  new_row <- data.table(
#    program = "Electrical/Computer Engineering",
#    N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
#  )
#  rev_proxy <- copy(proxy_programs)
#  rev_proxy <- rev_proxy[!program %ilike% "Electrical|Computer"]
#  rev_proxy <- rbindlist(list(rev_proxy, new_row))
#  setorderv(rev_proxy, c("N"), -1)

## -----------------------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

