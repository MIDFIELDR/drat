## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-003-case-results-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

## -----------------------------------------------------------------------------
# Packages
library("midfieldr")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))

# Printing options for data.table
options(
  datatable.print.nrows = 15,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Copy the case study observations
DT <- copy(study_observations)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_observations

## -----------------------------------------------------------------------------
# Group and summarize
DT <- DT[, .N, by = c("group", "program", "race", "sex")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Transform to row-record form
DT <- dcast(DT, program + sex + race ~ group, value.var = "N", fill = 0)

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Compute the metric
DT[, stick := round(100 * grad / ever, 1)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? study_results

## -----------------------------------------------------------------------------
# Preserve anonymity
DT <- DT[grad >= 10]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Filter by study design
DT <- DT[!race %chin% c("International", "Other/Unknown")]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Create a variable 
DT[, people := paste(race, sex)]
DT[, c("race", "sex") := NULL]
setcolorder(DT, c("program", "people"))

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Recode values for charts and tables
DT[, program := fcase(
  program %like% "CE", "Civil",
  program %like% "EE", "Electrical",
  program %like% "ME", "Mechanical",
  program %like% "ISE", "Industrial/Systems"
)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Convert categorical variables to factors
DT <- order_multiway(DT,
  quantity = "stick",
  categories = c("program", "people"),
  method = "percent",
  ratio_of = c("grad", "ever")
)

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run in Console
#  ? order_multiway

## -----------------------------------------------------------------------------
ggplot(DT, aes(x = stick, y = program)) +
  facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
  geom_point() +
  labs(x = "Stickiness (%)", y = "")

## -----------------------------------------------------------------------------
ggplot(DT, aes(x = stick, y = people)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_point() +
  labs(x = "Stickiness (%)", y = "")

## -----------------------------------------------------------------------------
# Select the columns I want for the table
tbl <- DT[, .(program, people, stick)]

# Change factors to characters so rows/columns can be alphabetized
tbl[, people := as.character(people)]
tbl[, program := as.character(program)]

# Transform from block records to row records
tbl <- dcast(tbl, people ~ program, value.var = "stick")

# Edit one column header
setnames(tbl, old = "people", new = "People", skip_absent = TRUE)

## -----------------------------------------------------------------------------
tbl |>
  kableExtra::kbl(
    align = "lrrrr",
    caption = "Table 1: Program stickiness (%)"
  ) |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  kableExtra::column_spec(1:5, color = "black", background = "white")

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  suppressPackageStartupMessages(library("data.table"))
#  suppressPackageStartupMessages(library("ggplot2"))
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 15,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Copy the case study observations
#  DT <- copy(study_observations)
#  
#  # Group and summarize
#  DT <- DT[, .N, by = c("group", "program", "race", "sex")]
#  
#  # Compute the metric
#  DT <- dcast(DT, program + sex + race ~ group, value.var = "N", fill = 0)
#  DT[, stick := round(100 * grad / ever, 1)]
#  
#  # Prepare for dissemination
#  DT <- DT[grad >= 10]
#  DT <- DT[!race %chin% c("International", "Other/Unknown")]
#  DT[, people := paste(race, sex)]
#  DT[, c("race", "sex") := NULL]
#  setcolorder(DT, c("program", "people"))
#  DT[, program := fcase(
#    program %like% "CE", "Civil",
#    program %like% "EE", "Electrical",
#    program %like% "ME", "Mechanical",
#    program %like% "ISE", "Industrial/Systems"
#  )]
#  
#  # Convert categorical variables to factors
#  DT <- order_multiway(DT,
#    quantity = "stick",
#    categories = c("program", "people"),
#    method = "percent",
#    ratio_of = c("grad", "ever")
#  )
#  
#  # Chart 1
#  ggplot(DT, aes(x = stick, y = program)) +
#    facet_wrap(vars(people), ncol = 1, as.table = FALSE) +
#    geom_point() +
#    labs(x = "Stickiness (%)", y = "")
#  
#  # Chart 2
#  ggplot(DT, aes(x = stick, y = people)) +
#    facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
#    geom_point() +
#    labs(x = "Stickiness (%)", y = "")
#  
#  # Table
#  tbl <- DT[, .(program, people, stick)]
#  tbl[, people := as.character(people)]
#  tbl[, program := as.character(program)]
#  tbl <- dcast(tbl, people ~ program, value.var = "stick")
#  setnames(tbl, old = "people", new = "People", skip_absent = TRUE)

## ----echo = FALSE-------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

