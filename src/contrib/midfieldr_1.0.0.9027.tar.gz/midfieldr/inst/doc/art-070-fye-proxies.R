## ----setup--------------------------------------------------------------------
# code chunks
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = FALSE,
  comment = "#>",
  error = FALSE
)

# figures
knitr::opts_chunk$set(
  fig.path = "../man/figures/art-070-fye-proxies-",
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)

# inline numbers
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})

# accented text
accent <- function (text_string){
    kableExtra::text_spec(text_string, color = "#b35806", bold = TRUE)
}

## -----------------------------------------------------------------------------
# FYE proxies
# midfieldr vignette

# Packages
library("midfieldr")
library("midfielddata")
suppressPackageStartupMessages(library("data.table"))
suppressPackageStartupMessages(library("ggplot2"))
library("mice")

# Printing options for data.table
options(
  datatable.print.nrows = 17,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# Load practice data sets
data(student, term, package = "midfielddata")

## -----------------------------------------------------------------------------
# Select required midfieldr variables
student <- select_required(student)
term <- select_required(term)

# View top few rows of the result
head(student, n = 3L)
head(term, n = 3L)

## -----------------------------------------------------------------------------
# Display prepared data
study_programs

## -----------------------------------------------------------------------------
# Required arguments in order and explicitly named
x <- prep_fye_mice(midfield_student = student, midfield_term = term)

# Required arguments in order, but not named
y <- prep_fye_mice(student, term)

# Using the implicit defaults
z <- prep_fye_mice()

# Equality test between the data tables
all.equal(x, y)
all.equal(x, z)

## -----------------------------------------------------------------------------
# Working data frame
DT <- prep_fye_mice(student, term)

# Display the result
DT[]

## -----------------------------------------------------------------------------
N_ever_fye <- length(unique(DT$mcid))
N_to_impute <- sum(is.na(DT$proxy))

## -----------------------------------------------------------------------------
# Number of unique IDs
(N_mcid <- length(unique(DT$mcid)))

# Number of complete cases on four variables
(N_complete <- sum(complete.cases(DT[, .(mcid, race, sex, institution)])))

# Confirm equality
all.equal(N_mcid, N_complete)

## -----------------------------------------------------------------------------
# Number NAs in proxy
(N_impute <- sum(is.na(DT$proxy)))

## -----------------------------------------------------------------------------
pct_missing <- round(100 * N_impute / N_complete, 0)

## -----------------------------------------------------------------------------
# Percent missing proxies
round(100 * N_impute / N_complete, 3)

## -----------------------------------------------------------------------------
# Set aside for the chart
NA_proxies <- copy(DT)

## -----------------------------------------------------------------------------
# Imputation framework
framework <- mice(DT, maxit = 0)

# Display the results
framework

## -----------------------------------------------------------------------------
# Imputation method
method_vector <- framework[["method"]]

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Manually assign the variable(s) being imputed
method_vector[c("proxy")] <- "polyreg"

# Manually assign the variable(s) not being imputed
method_vector[c("mcid", "institution", "race", "sex")] <- ""

# Display the results
method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
predictor_matrix <- framework[["predictorMatrix"]]

# Display the results
predictor_matrix

## -----------------------------------------------------------------------------
# Predictor row for this example
predictor_matrix["proxy", ]

## -----------------------------------------------------------------------------
# Manually assign zero columns
predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)

# Manually assign predictor columns
predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)

# Display the result
predictor_matrix

## -----------------------------------------------------------------------------
# Data frame to illustrate optional predictors
opt_DT <- copy(DT)

# Factor to character
cols_to_edit <- c("race", "sex")
opt_DT[, (cols_to_edit) := lapply(.SD, as.character), .SDcols = cols_to_edit]

# Filter unknown race and sex
opt_DT <- opt_DT[sex != "Unknown"]
opt_DT <- opt_DT[race != "Other/Unknown"]

# Create origin variable
opt_DT[, origin := fcase(
    race != "International", "Domestic", 
    race == "International", "International", 
    default = NA_character_
)]
opt_DT <- opt_DT[!is.na(origin)]

# Create people variable
opt_DT[, people := paste(origin, sex)]
opt_DT[, people := as.factor(people)]
opt_DT[, c("race", "sex", "origin") := NULL]

# Display result
setcolorder(opt_DT, c("mcid", "people", "institution", "proxy"))
opt_DT[]

## -----------------------------------------------------------------------------
# Display unique people
sort(unique(opt_DT$people))

## -----------------------------------------------------------------------------
# Add all term variables by ID
cols_to_join <- term[, .(mcid, term)]
opt_DT <- cols_to_join[opt_DT, on = c("mcid")]

# Filter for first term
setkeyv(opt_DT, c("mcid", "term"))
opt_DT <- opt_DT[, .SD[1], by = c("mcid")]

# Create year variable
opt_DT[, year := substr(term, 1, 4)]
opt_DT[, year := as.factor(year)]
opt_DT[, term := NULL]

# Display result
setcolorder(opt_DT, c("mcid", "people", "institution", "year", "proxy"))
opt_DT[]

## -----------------------------------------------------------------------------
# Identify complete cases in predictor variables 
rows_we_want <- complete.cases(opt_DT[, .(mcid, people, institution, year)])

# Filter for complete predictors
opt_DT <- opt_DT[rows_we_want]

# Display the result
opt_DT[]

## -----------------------------------------------------------------------------
# Imputation framework
opt_framework <- mice(opt_DT, maxit = 0)

# Display the results
opt_framework

## -----------------------------------------------------------------------------
# Imputation framework
opt_method_vector <- opt_framework[["method"]]

# Display the results
opt_method_vector

## -----------------------------------------------------------------------------
# Imputation predictor matrix
opt_predictor_matrix <- opt_framework[["predictorMatrix"]]

# Display the results
opt_predictor_matrix

## -----------------------------------------------------------------------------
N_impute <- sum(is.na(opt_DT$proxy))
N_fye <- nrow(opt_DT)

# Percent missing data
round(100 * N_impute / N_fye, 0)

## -----------------------------------------------------------------------------
# load DT_mids, don't have to repeatedly run mice() 
load(here::here("R", "sysdata.rda"))

## -----------------------------------------------------------------------------
#  # Impute missing proxy data
#  DT_mids <- mice(
#    data = DT,
#    m = 38,
#    maxit = 5, # default
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )

## -----------------------------------------------------------------------------
# output in console with printFlag = TRUE
# >  iter imp variable
# >   1   1  proxy
# >   1   2  proxy
# >   1   3  proxy
# >   1   4  proxy
# >   1   5  proxy
# >   ---
# >   5  34  proxy
# >   5  35  proxy
# >   5  36  proxy
# >   5  37  proxy
# >   5  38  proxy

## -----------------------------------------------------------------------------
# Revert to default random number generation
set.seed(NULL)

# Extract data from the mids object
DT <- mice::complete(DT_mids)

# Convert to data.table structure
setDT(DT)

# Display the result
DT <- DT[order(mcid)]
DT[]

## -----------------------------------------------------------------------------
# Subset the data
DT <- DT[, .(mcid, proxy)]

# Display the result
DT

## -----------------------------------------------------------------------------
# Convert factors
DT[, proxy := as.character(proxy)]

# Display the result
DT[]

## -----------------------------------------------------------------------------
# Order term data by ID and term
ordered_term <- term[, .(mcid, term, cip6)]
setorderv(ordered_term, cols = c("mcid", "term"))

# Obtain first term of all students
first_term <- ordered_term[, .SD[1], by = c("mcid")]

# Reduce to first term in FYE
first_term_fye_mcid <- first_term[cip6 == "140102", .(mcid)]

# Inner join to remove migrators from working data frame
DT <- first_term_fye_mcid[DT, on = c("mcid"), nomatch = NULL]

# Display the result
DT[]

## -----------------------------------------------------------------------------
#  # Run manually if necessary for reproducibility
#  # Writing internal file sysdata.rda to save DT_mids
#  # Writing external file fye_proxy
#  
#  # Internal files
#  usethis::use_data(
#    DT_mids,
#    subset_student,
#    subset_course,
#    subset_term,
#    subset_degree,
#    internal  = TRUE,
#    overwrite = TRUE
#  )
#  
#  # External file
#  fye_proxy <- copy(DT)
#  usethis::use_data(fye_proxy, overwrite = TRUE)

## -----------------------------------------------------------------------------
# Verify built-in data
all.equal(DT, fye_proxy)

## -----------------------------------------------------------------------------
# Identify unique CIP codes in the proxy data
proxy_cips <- sort(unique(fye_proxy$proxy))

# Display the results
proxy_cips

## -----------------------------------------------------------------------------
# Obtain the 4-digit program names corresponding to these codes
proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
proxy_program_names[]

## -----------------------------------------------------------------------------
# Join these program names to the proxy data
proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]

# Count by program and order rows in descending magnitude
proxy_programs <- proxy_programs[, .N, by = c("program")]
setorderv(proxy_programs, order = -1, cols = c("N"))

# Display the result
proxy_programs[]

## -----------------------------------------------------------------------------
# Combine Electrical and Computer Engineering
new_row <- data.table(
  program = "Electrical/Computer Engineering",
  N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
)

# Drop the separate Electrical and Computer rows
proxy_programs <- proxy_programs[!program %ilike% "Electrical|Computer"]

# Bind the new row and order
proxy_programs <- rbindlist(list(proxy_programs, new_row))
setorderv(proxy_programs, c("N"), -1)

## -----------------------------------------------------------------------------
proxy_programs[1:7] |>
  kableExtra::kbl(align = "lr", caption = "Table 1: Top seven FYE proxies ranked by the number of students assigned to major.") |>
  kableExtra::kable_paper(lightable_options = "basic", full_width = TRUE) |>
  kableExtra::row_spec(0, background = "#c7eae5") |>
  # kableExtra::column_spec(1, monospace = TRUE) |>
  kableExtra::column_spec(1:2, color = "black", background = "white")

## -----------------------------------------------------------------------------
# First term of all students
first_term[]

## -----------------------------------------------------------------------------
# Join proxies by ID (left-outer join) to first-term data
DT <- fye_proxy[first_term, .(mcid, cip6, proxy), on = c("mcid")]

# Distinguish FYE from direct matriculants
DT[, matric := fcase(
    is.na(proxy), "direct",
    !is.na(proxy), "fye"
)]

# Create start variable
DT[, start := fcase(
 matric == "fye", proxy, 
 matric == "direct", cip6
)]

# Filter to retain case study program starters
join_labels <- copy(study_programs)
setnames(join_labels, old = "cip6", new = "start")
DT <- join_labels[DT, on = c("start")]
DT <- DT[!is.na(program)]

# Display result
DT[order(matric, start)]

## -----------------------------------------------------------------------------
# Summarize
DT <- DT[, .N, by = c("matric", "program")]

# Transform to row-record form
DT <- dcast(DT, program ~ matric, value.var = "N")

# Compute FYE as fraction of total
DT[, N_starters := direct + fye]
DT[, fye_pct := round(100 * fye / N_starters, 1)]

# Display result
DT[]

## -----------------------------------------------------------------------------
#  # Packages
#  library("midfieldr")
#  library("midfielddata")
#  suppressPackageStartupMessages(library("data.table"))
#  suppressPackageStartupMessages(library("ggplot2"))
#  library("mice")
#  
#  # Printing options for data.table
#  options(
#    datatable.print.nrows = 17,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  # Load data
#  data(student, term, package = "midfielddata")
#  
#  # Working data frame
#  DT <- prep_fye_mice(student, term)
#  
#  # Missing data
#  N_mcid <- length(unique(DT$mcid))
#  N_complete <- sum(complete.cases(DT[, .(mcid, race, sex, institution)]))
#  all.equal(N_mcid, N_complete)
#  N_impute <- sum(is.na(DT$proxy))
#  round(100 * N_impute / N_complete, 3)
#  NA_proxies <- copy(DT)
#  
#  # Using mice()
#  framework <- mice(DT, maxit = 0)
#  
#  method_vector <- framework[["method"]]
#  method_vector[c("proxy")] <- "polyreg"
#  method_vector[c("mcid", "institution", "race", "sex")] <- ""
#  
#  predictor_matrix <- framework[["predictorMatrix"]]
#  predictor_matrix[, c("mcid", "proxy")] <- c(0, 0, 0, 0, 0)
#  predictor_matrix[, c("institution", "race", "sex")] <- c(0, 0, 0, 0, 1)
#  
#  # Optional predictors
#  opt_DT <- copy(DT)
#  cols_to_edit <- c("race", "sex")
#  opt_DT[, (cols_to_edit) := lapply(.SD, as.character), .SDcols = cols_to_edit]
#  
#  opt_DT <- opt_DT[sex != "Unknown"]
#  opt_DT <- opt_DT[race != "Other/Unknown"]
#  opt_DT[, origin := fcase(
#      race != "International", "Domestic",
#      race == "International", "International",
#      default = NA_character_
#  )]
#  opt_DT <- opt_DT[!is.na(origin)]
#  
#  opt_DT[, people := paste(origin, sex)]
#  opt_DT[, people := as.factor(people)]
#  opt_DT[, c("race", "sex", "origin") := NULL]
#  setcolorder(opt_DT, c("mcid", "people", "institution", "proxy"))
#  
#  sort(unique(opt_DT$people))
#  
#  cols_to_join <- term[, .(mcid, term)]
#  opt_DT <- cols_to_join[opt_DT, on = c("mcid")]
#  
#  setkeyv(opt_DT, c("mcid", "term"))
#  opt_DT <- opt_DT[, .SD[1], by = c("mcid")]
#  
#  opt_DT[, year := substr(term, 1, 4)]
#  opt_DT[, year := as.factor(year)]
#  opt_DT[, term := NULL]
#  setcolorder(opt_DT, c("mcid", "people", "institution", "year", "proxy"))
#  
#  rows_we_want <- complete.cases(opt_DT[, .(mcid, people, institution, year)])
#  opt_DT <- opt_DT[rows_we_want]
#  
#  opt_framework <- mice(opt_DT, maxit = 0)
#  opt_method_vector <- opt_framework[["method"]]
#  opt_predictor_matrix <- opt_framework[["predictorMatrix"]]
#  
#  N_impute <- sum(is.na(opt_DT$proxy))
#  N_fye <- nrow(opt_DT)
#  round(100 * N_impute / N_fye, 0)
#  
#  # Imputing missing values
#  DT_mids <- mice(
#    data = DT,
#    m = 38,
#    maxit = 5, # default
#    method = method_vector,
#    predictorMatrix = predictor_matrix,
#    seed = 20180624,
#    printFlag = TRUE
#  )
#  
#  # Post-processing
#  set.seed(NULL)
#  DT <- mice::complete(DT_mids)
#  setDT(DT)
#  DT <- DT[order(mcid)]
#  DT <- DT[, .(mcid, proxy)]
#  DT[, proxy := as.character(proxy)]
#  ordered_term <- term[, .(mcid, term, cip6)]
#  setorderv(ordered_term, cols = c("mcid", "term"))
#  
#  first_term <- ordered_term[, .SD[1], by = c("mcid")]
#  first_term_fye_mcid <- first_term[cip6 == "140102", .(mcid)]
#  DT <- first_term_fye_mcid[DT, on = c("mcid"), nomatch = NULL]
#  
#  all.equal(DT, fye_proxy)
#  
#  # Credibility
#  proxy_cips <- sort(unique(fye_proxy$proxy))
#  proxy_program_names <- filter_search(cip, keep_text = proxy_cips)
#  proxy_program_names <- proxy_program_names[, .(cip6, program = cip4name)]
#  proxy_programs <- proxy_program_names[fye_proxy[, .(cip6 = proxy)], .(program), on = c("cip6")]
#  proxy_programs <- proxy_programs[, .N, by = c("program")]
#  setorderv(proxy_programs, order = -1, cols = c("N"))
#  new_row <- data.table(
#    program = "Electrical/Computer Engineering",
#    N = sum(proxy_programs[program %ilike% "Electrical|Computer", N])
#  )
#  proxy_programs <- proxy_programs[!program %ilike% "Electrical|Computer"]
#  proxy_programs <- rbindlist(list(proxy_programs, new_row))
#  setorderv(proxy_programs, c("N"), -1)
#  proxy_programs[1:7]
#  
#  # Quantifying potential miscounts
#  DT <- fye_proxy[first_term, .(mcid, cip6, proxy), on = c("mcid")]
#  DT[, matric := fcase(
#      is.na(proxy), "direct",
#      !is.na(proxy), "fye"
#  )]
#  
#  DT[, start := fcase(
#   matric == "fye", proxy,
#   matric == "direct", cip6
#  )]
#  
#  join_labels <- copy(study_programs)
#  setnames(join_labels, old = "cip6", new = "start")
#  DT <- join_labels[DT, on = c("start")]
#  DT <- DT[!is.na(program)]
#  
#  DT <- DT[, .N, by = c("matric", "program")]
#  DT <- dcast(DT, program ~ matric, value.var = "N")
#  DT[, N_starters := direct + fye]
#  DT[, fye_pct := round(100 * fye / N_starters, 1)]

## -----------------------------------------------------------------------------
#  # New memory location
#  x <- copy(NA_proxies)
#  
#  # Convert factors to characters
#  x <- x[, lapply(.SD, as.character)]
#  
#  # Overall percentage missing proxies
#  overall_miss <- 100 * round(nrow(x[is.na(proxy)]) / nrow(x), 3)
#  
#  # Function for determining percent missing proxies by category
#  missing_fraction <- function(DT, cat_level) {
#    DT[, group := fcase(
#        is.na(proxy), "missing",
#        default = "not_missing"
#    )]
#    DT <- DT[, .N, by = c("group", "cat_level")]
#    DT <- dcast(DT, cat_level ~ group, value.var = "N")
#    DT[, pct_miss := 100 * round(missing / (missing + not_missing), 3)]
#    DT <- DT[, .(cat_level, pct_miss)]
#  }
#  
#  # Apply to institution category
#  y <- x[, .(cat_level = institution, proxy)]
#  inst <- missing_fraction(y, cat_level = "institution")
#  inst[, category := "institution"]
#  
#  # Apply to race/ethnicity category
#  y <- x[, .(cat_level = race, proxy)]
#  race <- missing_fraction(y, cat_level = "race")
#  race[, category := "race"]
#  
#  # Apply to sex category
#  y <- x[, .(cat_level = sex, proxy)]
#  sex <- missing_fraction(y, cat_level = "sex")
#  sex[, category := "sex"]
#  
#  # Gather results and plot
#  DT <- rbindlist(list(inst, race, sex))
#  p <- ggplot(DT, aes(x = pct_miss, y = reorder(cat_level, pct_miss))) +
#      geom_vline(xintercept = overall_miss, linetype = 2, color = "gray35") +
#      geom_point(size = 2) +
#      facet_grid(rows = vars(reorder(category, pct_miss)),
#                 as.table = TRUE,
#                 scales = "free_y",
#                 space = "free_y") +
#      labs(x = "FYE proxy missing values (%)", y = "") +
#      scale_x_continuous(breaks = seq(0, 100, 5), limits = c(20, 50)) +
#      theme(panel.grid.minor.x = element_blank())

## -----------------------------------------------------------------------------
# # Run manually to save figure
# ggsave(
#   filename = "man/figures/art-070-fye-proxies-pct-missing.png",
#   plot = p,
#   width = 7,
#   height = 0.4 * 7,
#   units = "in"
# )

## -----------------------------------------------------------------------------
# to change the CSS file
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

