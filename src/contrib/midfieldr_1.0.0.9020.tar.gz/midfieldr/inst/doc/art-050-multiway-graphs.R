## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(fig.path = here::here(
  "man/figures",
  "art-050-multiway-graphs-"
))
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE,
  warning = FALSE,
  collapse = TRUE,
  comment = "#>",
  error = FALSE,
  fig.width = 6,
  fig.asp = 1 / 1.6,
  out.width = "70%",
  fig.align = "center"
)
knitr::knit_hooks$set(inline = function(x) {
  if (!is.numeric(x)) {
    x
  } else if (x >= 10000) {
    prettyNum(round(x, 2), big.mark = ",")
  } else {
    prettyNum(round(x, 2))
  }
})
kable2html <- function(x, font_size = NULL, caption = NULL) {
  font_size <- ifelse(is.null(font_size), 11, font_size)
  kable_in <- knitr::kable(x, format = "html", caption = caption)
  kableExtra::kable_styling(kable_input = kable_in, font_size = font_size)
}
asp_ratio_mw <- function(data, categories) {
  cat1 <- categories[1] # panels
  cat2 <- categories[2] # rows
  nlevel1 <- nlevels(data[, get(cat1)])
  nlevel2 <- nlevels(data[, get(cat2)])
  r <- nlevel1 * nlevel2
  q <- 32
  asp_ratio1 <- (r + 2 * nlevel1) / q
  asp_ratio2 <- (r + 2 * nlevel2) / q
  ratios <- c(asp_ratio1, asp_ratio2)
}

## -----------------------------------------------------------------------------
# packages used
library("midfieldr")
library("midfielddata")
library("data.table")
library("ggplot2")

## -----------------------------------------------------------------------------
# optional code to control data.table printing
options(
  datatable.print.nrows = 10,
  datatable.print.topn = 5,
  datatable.print.class = TRUE
)

## -----------------------------------------------------------------------------
# examine the built-in data
study_stickiness

## -----------------------------------------------------------------------------
# create a new memory location
DT <- copy(study_stickiness)

# first category is a character
class(DT$program)

# second category is a character
class(DT$race_sex)

## -----------------------------------------------------------------------------
# Omit before graphing
DT <- DT[ever >= 10]

## -----------------------------------------------------------------------------
# data table printing option
options(datatable.print.topn = 3)

# Omit before graphing
DT <- DT[!race_sex %ilike% c("International|Other|Native")]

# Examine the result
DT

temp <- copy(DT)

## -----------------------------------------------------------------------------
# condition as multiway data
DT <- condition_multiway(
  dframe = DT, # input data frame
  categ_col = c("program", "race_sex"), # multiway categorical variables
  quant_col = "stick", # multiway quantitative variable
  detail = FALSE, # do not return columns of details
  order_by = "percent", # row and panel ordering method
  param_col = c("grad", "ever") # parameters used for ordering
)

## -----------------------------------------------------------------------------
DT

## -----------------------------------------------------------------------------
# first category is now a factor
levels(DT$program)

# second category is now a factor
levels(DT$race_sex)

## -----------------------------------------------------------------------------
# return stickiness by category
DT <- condition_multiway(
  dframe = DT, # input data frame
  categ_col = c("program", "race_sex"), # multiway categorical variables
  quant_col = "stick", # multiway quantitative variable
  detail = TRUE, # return columns of details
  order_by = "percent", # row and panel ordering method
  param_col = c("grad", "ever") # parameters used for ordering
)

## -----------------------------------------------------------------------------
# optional code to control data.table printing
options(datatable.print.topn = 10)

# programs have a median stickiness across race-sex groups
DT[order(program)]

## -----------------------------------------------------------------------------
# race_sex groupings have a median stickiness across programs
DT[order(race_sex)]

## ----include = FALSE----------------------------------------------------------
asp_ratio <- asp_ratio_mw(DT, categories = c("program", "race_sex"))

## ----fig1, fig.asp = asp_ratio[1]---------------------------------------------
# create one multiway graph
ggplot(data = DT, aes(x = stick, y = race_sex)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = program_stick),
    linetype = 2,
    color = "gray70"
  ) +
  geom_point(na.rm = TRUE) +
  labs(
    x = "Stickiness (%)",
    y = "",
    title = "Practice data (not for research)",
    caption = "Source: midfielddata"
  )

## ----fig2, fig.asp = asp_ratio[2]---------------------------------------------
# create the dual multiway graph
ggplot(data = DT, aes(x = stick, y = program)) +
  facet_wrap(vars(race_sex), ncol = 1, as.table = FALSE) +
  geom_vline(aes(xintercept = race_sex_stick),
    linetype = 2,
    color = "gray70"
  ) +
  geom_point(na.rm = TRUE) +
  labs(
    x = "Stickiness (%)",
    y = "",
    title = "Practice data (not for research)",
    caption = "Source: midfielddata"
  )

## -----------------------------------------------------------------------------
# create a common graph framework to use in the example below
p <- ggplot(data = temp, aes(x = stick, y = race_sex)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_point(na.rm = TRUE) +
  labs(
    x = "Longitudinal stickiness (%)",
    y = "",
    caption = "Source: midfielddata"
  )

## ----fig3, fig.asp = asp_ratio[1]---------------------------------------------
dtf <- condition_multiway(
  dframe = temp,
  categ_col = c("program", "race_sex"),
  quant_col = "stick",
  detail = TRUE
)
p %+% dtf +
  labs(title = "Levels ordered by median values") +
  geom_vline(aes(xintercept = program_stick),
    linetype = 2,
    col = "gray50"
  )

## ----fig4, fig.asp = asp_ratio[1]---------------------------------------------
dtf <- condition_multiway(
  dframe = temp,
  categ_col = c("program", "race_sex"),
  quant_col = "stick",
  order_by = "mean",
  detail = TRUE
)
p %+% dtf +
  labs(title = "Levels ordered by mean values") +
  geom_vline(aes(xintercept = program_stick),
    linetype = 2,
    col = "gray50"
  )

## ----fig5, fig.asp = asp_ratio[1]---------------------------------------------
dtf <- condition_multiway(
  dframe = temp,
  categ_col = c("program", "race_sex"),
  quant_col = "ever",
  order_by = "sum",
  detail = TRUE
)
ggplot(data = dtf, aes(x = ever, y = race_sex)) +
  facet_wrap(vars(program), ncol = 1, as.table = FALSE) +
  geom_point(na.rm = TRUE) +
  scale_x_continuous(trans = "log2") +
  geom_vline(aes(xintercept = program_ever),
    linetype = 2,
    col = "gray50"
  ) +
  labs(
    x = "Number of students ever enrolled (log-2 scale)",
    y = "",
    title = "Levels ordered by count totals",
    caption = "Source: midfielddata"
  )

## ----fig6, fig.asp = asp_ratio[1]---------------------------------------------
dtf <- condition_multiway(
  dframe = temp,
  categ_col = c("program", "race_sex"),
  quant_col = "stick",
  order_by = "alphabet"
)
p %+% dtf +
  labs(title = "Levels ordered alphbetically")

## ----eval = FALSE-------------------------------------------------------------
#  # packages used
#  library("midfieldr")
#  library("data.table")
#  library("ggplot2")
#  
#  # optional code to control data.table printing
#  options(
#    datatable.print.nrows = 10,
#    datatable.print.topn = 5,
#    datatable.print.class = TRUE
#  )
#  
#  

## ----echo = FALSE-------------------------------------------------------------
# to change the CSS file for block quotes
# per https://github.com/rstudio/rmarkdown/issues/732
knitr::opts_chunk$set(echo = FALSE)

